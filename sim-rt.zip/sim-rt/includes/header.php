<?php require_once __DIR__ . '/auth.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIM-RT | Sistem Informasi Manajemen RT</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { 
            background-color: #f4f6f9; 
            overflow: hidden; /* Mencegah scroll di body utama */
        }

        /* === SIDEBAR FIXED === */
        .sidebar { 
            height: 100vh; 
            background-color: #212529; 
            position: fixed; 
            top: 0; 
            left: 0;
            width: 250px;
            overflow-y: auto; /* Sidebar bisa scroll jika menu panjang */
            z-index: 1040;
            transition: transform 0.3s ease-in-out;
        }
        .sidebar .nav-link { color: #adb5bd; padding: 12px 20px; margin-bottom: 2px; border-radius: 5px; }
        .sidebar .nav-link.active, .sidebar .nav-link:hover { color: #fff; background-color: #0d6efd; }
        .sidebar h4 { border-bottom: 1px solid #495057; padding-bottom: 15px; }

        /* === MAIN CONTENT SCROLL === */
        .main-wrapper {
            margin-left: 250px;
            height: 100vh;
            overflow-y: auto; /* HANYA KONTEN INI YANG SCROLL */
            display: flex;
            flex-direction: column;
        }
        .top-navbar {
            background-color: #fff;
            padding: 15px 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            position: sticky;
            top: 0;
            z-index: 1020;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        /* === MODE MOBILE (APP-LIKE) === */
        .mobile-top-bar {
            display: none;
            position: fixed;
            top: 0; left: 0; width: 100%;
            height: 56px;
            background-color: #212529;
            color: white;
            align-items: center;
            justify-content: space-between;
            padding: 0 15px;
            z-index: 1050;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
        .overlay-mobile {
            display: none;
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.6);
            z-index: 1035;
        }
        .overlay-mobile.show {
            display: block;
        }

        @media (max-width: 991.98px) {
            .sidebar {
                transform: translateX(-100%); /* Sembunyikan di HP */
                width: 280px;
            }
            .sidebar.show {
                transform: translateX(0); /* Munculkan saat tombol diklik */
            }
            .main-wrapper {
                margin-left: 0; /* Full width di HP */
                padding-top: 56px; /* Ruang untuk top bar mobile */
            }
            .top-navbar {
                display: none; /* Sembunyikan navbar desktop di HP */
            }
            .mobile-top-bar {
                display: flex; /* Munculkan top bar mobile */
            }
        }

        /* CSS Running Text Pengumuman */
        .scroll-text-container { overflow: hidden; white-space: nowrap; flex-grow: 1; }
        .scroll-text { display: inline-block; animation: scroll-left 20s linear infinite; }
        @keyframes scroll-left { 0% { transform: translate(100%, 0); } 100% { transform: translate(-100%, 0); } }
        @keyframes blinker { 50% { opacity: 0.7; } }
    </style>
</head>
<body>

    <!-- TOP BAR MOBILE (Hanya muncul di HP) -->
    <div class="mobile-top-bar">
        <button class="btn btn-link text-white p-0" id="btnToggleSidebar">
            <i class="bi bi-list fs-2"></i>
        </button>
        <h5 class="mb-0">SIM-RT</h5>
        <a href="../auth/logout.php" class="btn btn-sm btn-outline-light"><i class="bi bi-box-arrow-right"></i></a>
    </div>

    <!-- OVERLAY MOBILE (Layar gelap saat sidebar keluar) -->
    <div class="overlay-mobile" id="overlayMobile"></div>

    <!-- SIDEBAR -->
    <div class="sidebar p-3" id="sidebar">
        <h4 class="text-white text-center"><i class="bi bi-houses-fill"></i> SIM-RT</h4>
        <ul class="nav flex-column mt-4">
            <?php if(hasRole('admin')): ?>
                <li class="nav-item"><a class="nav-link" href="../admin/data_warga.php"><i class="bi bi-people me-2"></i> Data Warga</a></li>
                <li class="nav-item"><a class="nav-link" href="../admin/users.php"><i class="bi bi-shield-lock me-2"></i> Manajemen User</a></li>
                <li class="nav-item"><a class="nav-link" href="../admin/pengaduan.php"><i class="bi bi-chat-dots me-2"></i> Pengaduan Masuk</a></li>
                <hr class="bg-secondary">
                <li class="nav-item"><a class="nav-link" href="../rt/dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard RT</a></li>
                <li class="nav-item"><a class="nav-link" href="../rt/validasi_surat.php"><i class="bi bi-envelope-paper me-2"></i> Validasi Surat</a></li>
                <li class="nav-item"><a class="nav-link" href="../rt/pengumuman.php"><i class="bi bi-megaphone-fill me-2"></i> Pengumuman</a></li>
                <li class="nav-item"><a class="nav-link" href="../rt/data_sosial.php"><i class="bi bi-bar-chart-fill me-2"></i> Data Sosial</a></li>
            
            <?php elseif(hasRole('ketua_rt')): ?>
                <li class="nav-item"><a class="nav-link" href="../rt/dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="../rt/validasi_surat.php"><i class="bi bi-envelope-paper-fill me-2"></i> Validasi Surat</a></li>
                <li class="nav-item"><a class="nav-link" href="../rt/pengumuman.php"><i class="bi bi-megaphone-fill me-2"></i> Pengumuman</a></li>
                <li class="nav-item"><a class="nav-link" href="../rt/pengaduan.php"><i class="bi bi-chat-dots me-2"></i> Pengaduan Masuk</a></li>
                <li class="nav-item"><a class="nav-link" href="../rt/data_sosial.php"><i class="bi bi-bar-chart-fill me-2"></i> Data Sosial</a></li>
                <hr class="bg-secondary">
                <li class="nav-item"><a class="nav-link" href="../rt/tentang_sistem.php"><i class="bi bi-info-circle me-2"></i> Tentang Sistem</a></li>
            
            <?php elseif(hasRole('bendahara')): ?>
                <li class="nav-item"><a class="nav-link" href="../bendahara/kas.php"><i class="bi bi-cash-stack me-2"></i> Dashboard Kas</a></li>
                <li class="nav-item"><a class="nav-link" href="../bendahara/iuran.php"><i class="bi bi-wallet2 me-2"></i> Manajemen Iuran</a></li>
                <li class="nav-item"><a class="nav-link" href="../bendahara/laporan.php"><i class="bi bi-file-earmark-bar-graph me-2"></i> Laporan Keuangan</a></li>
            
            <?php elseif(hasRole('warga')): ?>
                <li class="nav-item"><a class="nav-link" href="../warga/dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="../warga/ajukan_surat.php"><i class="bi bi-file-earmark-plus me-2"></i> Ajukan Surat</a></li>
                <li class="nav-item"><a class="nav-link" href="../warga/pengaduan.php"><i class="bi bi-chat-dots me-2"></i> Pengaduan</a></li>
                <li class="nav-item"><a class="nav-link" href="../warga/riwayat_iuran.php"><i class="bi bi-cash-coin me-2"></i> Riwayat Iuran</a></li>
                <hr class="bg-secondary">
                <li class="nav-item"><a class="nav-link" href="../warga/tentang_sistem.php"><i class="bi bi-info-circle me-2"></i> Tentang Sistem</a></li>
            <?php endif; ?>
        </ul>
    </div>

    <!-- MAIN CONTENT WRAPPER (Yang akan bergulir) -->
    <div class="main-wrapper">
        
        <!-- Top Navbar (Desktop) -->
        <nav class="top-navbar">
            <span class="navbar-text fw-bold text-secondary">
                <i class="bi bi-person-circle"></i> <?= htmlspecialchars($_SESSION['nama_lengkap'] ?? 'User'); ?> 
                <span class="badge bg-primary ms-2"><?= ucfirst($_SESSION['role'] ?? 'Guest'); ?></span>
            </span>
            <a href="../auth/logout.php" class="btn btn-outline-danger btn-sm"><i class="bi bi-box-arrow-right"></i> Logout</a>
        </nav>

        <!-- Running Text Pengumuman Global -->
        <?php
        if (isset($pdo)) {
            $stmt_banner = $pdo->query("SELECT judul, isi FROM pengumuman WHERE status='aktif' ORDER BY tanggal_post DESC");
            $banner_data = $stmt_banner->fetchAll();
            
            if (count($banner_data) > 0) {
                echo '<div class="bg-warning text-dark py-2 shadow-sm" style="border-bottom: 3px solid #dc3545;">
                        <div class="container-fluid d-flex align-items-center">
                            <span class="badge bg-danger me-3 shadow-sm fw-bold" style="animation: blinker 1s linear infinite;">📢 PENGUMUMAN</span>
                            <div class="scroll-text-container">
                                <div class="scroll-text">';
                                
                $texts = [];
                foreach ($banner_data as $bd) {
                    $texts[] = "<b>" . htmlspecialchars($bd['judul']) . "</b>: " . htmlspecialchars($bd['isi']);
                }
                echo implode(" &nbsp;&nbsp;&nbsp;///&nbsp;&nbsp;&nbsp; ", $texts);
                
                echo '       </div>
                            </div>
                        </div>
                      </div>';
            }
        }
        ?>

        <!-- Area Konten Halaman -->
        <div class="container-fluid p-4">

        <!-- KONTEN HALAMAN ANDA AKAN MASUK KE SINI -->

<script>
    // Javascript untuk Sidebar Mobile
    const btnToggle = document.getElementById('btnToggleSidebar');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlayMobile');

    if(btnToggle) {
        btnToggle.addEventListener('click', function() {
            sidebar.classList.toggle('show');
            overlay.classList.toggle('show');
        });
    }
    if(overlay) {
        overlay.addEventListener('click', function() {
            sidebar.classList.remove('show');
            overlay.classList.remove('show');
        });
    }
</script>