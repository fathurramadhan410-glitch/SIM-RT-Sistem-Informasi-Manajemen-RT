<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole(['ketua_rt', 'admin']);
require_once __DIR__ . '/../../config/database.php';

// ==========================================
// LOGIC: Proses Kirim Tanggapan
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_pengaduan = $_POST['id_pengaduan'];
    $tanggapan = trim($_POST['tanggapan']);
    $status = $_POST['status'];

    $stmt = $pdo->prepare("UPDATE pengaduan SET tanggapan = ?, status = ? WHERE id_pengaduan = ?");
    $stmt->execute([$tanggapan, $status, $id_pengaduan]);

    // Redirect kembali ke halaman daftar pengaduan dengan pesan sukses
    header("Location: pengaduan.php?msg=" . urlencode("Tanggapan berhasil disimpan & status diperbarui!"));
    exit;
}

// ==========================================
// LOGIC: Ambil Data Aduan Berdasarkan ID
// ==========================================
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: pengaduan.php");
    exit;
}

 $id_pengaduan = $_GET['id'];
 $stmt = $pdo->prepare("SELECT p.*, w.nama_lengkap, w.nik, w.alamat, w.no_hp, w.foto_ktp 
                       FROM pengaduan p 
                       JOIN warga w ON p.id_warga = w.id_warga 
                       WHERE p.id_pengaduan = ?");
 $stmt->execute([$id_pengaduan]);
 $aduan = $stmt->fetch();

// Jika ID tidak ditemukan di database
if (!$aduan) {
    header("Location: pengaduan.php");
    exit;
}

require_once __DIR__ . '/../../includes/header.php';
?>

<!-- Custom CSS Modern untuk Halaman Aduan -->
<style>
    body { background-color: #f4f7f6; }
    .card-modern { border: none; border-radius: 15px; box-shadow: 0 5px 25px rgba(0,0,0,0.07); }
    .gradient-indigo { background: linear-gradient(135deg, #6610f2 0%, #520dc2 100%); }
    
    /* Desain Chat Bubble untuk Aduan */
    .aduan-bubble {
        position: relative;
        background: #f8f9fa;
        border-radius: 15px 15px 15px 0;
        padding: 20px;
        border-left: 4px solid #6610f2;
    }
    .aduan-bubble::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 0;
        height: 0;
        border: 15px solid transparent;
        border-top-color: #f8f9fa;
        border-left-color: #f8f9fa;
        border-bottom: 0;
        border-left: 0;
        margin-left: 0;
        margin-bottom: -15px;
    }

    /* Desain Chat Bubble untuk Tanggapan RT */
    .tanggapan-bubble {
        position: relative;
        background: #e8e0ff;
        border-radius: 15px 15px 0 15px;
        padding: 20px;
        border-right: 4px solid #6610f2;
        margin-left: 40px;
    }
    .tanggapan-bubble::after {
        content: '';
        position: absolute;
        bottom: 0;
        right: 0;
        width: 0;
        height: 0;
        border: 15px solid transparent;
        border-top-color: #e8e0ff;
        border-right-color: #e8e0ff;
        border-bottom: 0;
        border-right: 0;
        margin-right: 0;
        margin-bottom: -15px;
    }

    .status-badge-baru { background-color: #ffc107; color: #000; }
    .status-badge-diproses { background-color: #0dcaf0; color: #000; }
    .status-badge-selesai { background-color: #198754; color: #fff; }
    
    .form-control:focus, .form-select:focus { border-color: #6610f2; box-shadow: 0 0 0 0.2rem rgba(102, 16, 242, 0.15); }
</style>

<div class="container-fluid py-4">

    <!-- Header & Breadcrumb -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-1"><i class="bi bi-chat-left-text-fill me-2" style="color: #6610f2;"></i>Detail & Proses Aduan</h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 small">
                    <li class="breadcrumb-item"><a href="pengaduan.php" class="text-decoration-none">Daftar Aduan</a></li>
                    <li class="breadcrumb-item active" aria-current="page">ID Aduan: #<?= $aduan['id_pengaduan'] ?></li>
                </ol>
            </nav>
        </div>
        <a href="pengaduan.php" class="btn btn-outline-secondary shadow-sm rounded-pill px-4">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>

    <div class="row">
        
        <!-- Kolom Kiri: Info Pelapor & Isi Aduan -->
        <div class="col-lg-5 mb-4">
            
            <!-- Kartu Profil Pelapor -->
            <div class="card card-modern mb-4">
                <div class="card-header bg-white border-0 pt-4 pb-0 px-4">
                    <h6 class="fw-bold text-muted text-uppercase mb-3"><i class="bi bi-person-circle me-2"></i>Informasi Pelapor</h6>
                </div>
                <div class="card-body px-4 pb-4">
                    <div class="d-flex align-items-center mb-3">
                        <div class="flex-shrink-0">
                            <div class="rounded-circle gradient-indigo d-flex align-items-center justify-content-center text-white shadow-sm" style="width: 50px; height: 50px; font-size: 1.5rem;">
                                <?= strtoupper(substr($aduan['nama_lengkap'], 0, 1)) ?>
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h5 class="fw-bold mb-0"><?= htmlspecialchars($aduan['nama_lengkap']) ?></h5>
                            <small class="text-muted">NIK: <?= $aduan['nik'] ?></small>
                        </div>
                    </div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item px-0 d-flex justify-content-between"><span class="text-muted">Alamat</span><span class="fw-semibold text-end"><?= htmlspecialchars($aduan['alamat']) ?></span></li>
                        <li class="list-group-item px-0 d-flex justify-content-between"><span class="text-muted">No. HP</span><span class="fw-semibold"><?= htmlspecialchars($aduan['no_hp'] ?? '-') ?></span></li>
                        <li class="list-group-item px-0 d-flex justify-content-between"><span class="text-muted">Kategori</span><span class="badge bg-secondary"><?= $aduan['kategori'] ?></span></li>
                        <li class="list-group-item px-0 d-flex justify-content-between"><span class="text-muted">Tanggal Lapor</span><span class="fw-semibold"><?= date('d M Y, H:i', strtotime($aduan['tanggal_aduan'])) ?></span></li>
                        <li class="list-group-item px-0 d-flex justify-content-between"><span class="text-muted">Status</span><span class="badge status-badge-<?= $aduan['status'] ?> fs-6"><?= ucfirst($aduan['status']) ?></span></li>
                    </ul>
                </div>
            </div>

            <!-- Isi Aduan (Bubble Style) -->
            <div class="card card-modern">
                <div class="card-header bg-white border-0 pt-4 pb-0 px-4">
                    <h6 class="fw-bold text-muted text-uppercase mb-3"><i class="bi bi-chat-left-quote me-2"></i>Isi Laporan Warga</h6>
                </div>
                <div class="card-body px-4 pb-4">
                    <div class="aduan-bubble shadow-sm">
                        <p class="mb-0 text-dark" style="line-height: 1.7; text-align: justify;">
                            <?= nl2br(htmlspecialchars($aduan['isi_aduan'])) ?>
                        </p>
                    </div>
                </div>
            </div>

        </div>

        <!-- Kolom Kanan: Tanggapan RT -->
        <div class="col-lg-7 mb-4">
            <div class="card card-modern h-100">
                <div class="card-header bg-white border-0 pt-4 pb-0 px-4">
                    <h6 class="fw-bold text-uppercase mb-3" style="color: #6610f2;"><i class="bi bi-reply-all-fill me-2"></i>Tanggapan & Aksi Pengurus RT</h6>
                </div>
                <div class="card-body px-4 pb-4 d-flex flex-column">
                    
                    <!-- Jika sudah ada tanggapan, tampilkan di bubble atas -->
                    <?php if(!empty($aduan['tanggapan'])): ?>
                    <div class="mb-4">
                        <div class="d-flex align-items-center mb-2">
                            <div class="rounded-circle bg-primary d-flex align-items-center justify-content-center text-white me-2" style="width: 30px; height: 30px; font-size: 0.8rem;">
                                RT
                            </div>
                            <span class="fw-bold small">Tanggapan Terkini</span>
                        </div>
                        <div class="tanggapan-bubble shadow-sm">
                            <p class="mb-0" style="line-height: 1.7; text-align: justify;">
                                <?= nl2br(htmlspecialchars($aduan['tanggapan'])) ?>
                            </p>
                        </div>
                    </div>
                    <hr class="mt-0 mb-4">
                    <?php endif; ?>

                    <!-- Form Tanggapan Baru / Update -->
                    <form method="POST" class="mt-auto">
                        <input type="hidden" name="id_pengaduan" value="<?= $aduan['id_pengaduan'] ?>">
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold small">Tulis / Perbarui Tanggapan</label>
                            <textarea name="tanggapan" class="form-control" rows="6" placeholder="Tuliskan tanggapan, progres, atau alasan penyelesaian di sini..." required><?= htmlspecialchars($aduan['tanggapan'] ?? '') ?></textarea>
                            <div class="form-text">Tanggapan ini akan terlihat oleh warga di dashboard mereka.</div>
                        </div>

                        <div class="row mb-4">
                            <div class="col-md-6">
                                <label class="form-label fw-bold small">Ubah Status Aduan</label>
                                <select name="status" class="form-select" required>
                                    <option value="baru" <?= $aduan['status'] == 'baru' ? 'selected' : '' ?>>🆕 Baru (Belum Ditangani)</option>
                                    <option value="diproses" <?= $aduan['status'] == 'diproses' ? 'selected' : '' ?>>⏳ Diproses (Sedang Ditangani)</option>
                                    <option value="selesai" <?= $aduan['status'] == 'selesai' ? 'selected' : '' ?>>✅ Selesai (Terselesaikan)</option>
                                </select>
                            </div>
                        </div>

                        <button type="submit" class="btn w-100 text-white shadow-sm rounded-pill py-2 fw-bold" style="background-color: #6610f2;">
                            <i class="bi bi-send-fill me-2"></i> Simpan Tanggapan & Update Status
                        </button>
                    </form>
                </div>
            </div>
        </div>

    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>