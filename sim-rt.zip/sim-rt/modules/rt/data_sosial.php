<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole(['ketua_rt', 'admin']);
require_once __DIR__ . '/../../config/database.php';

// ==========================================
// LOGIC: Update Profil Sosial Warga
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_sosial'])) {
    $id_warga = $_POST['id_warga'];
    $status_ekonomi = $_POST['status_ekonomi'];
    $status_disabilitas = $_POST['status_disabilitas'];
    $penerima_bansos = isset($_POST['penerima_bansos']) ? 1 : 0;
    $jenis_bansos = $penerima_bansos ? $_POST['jenis_bansos'] : NULL;
    $penerima_beasiswa = isset($_POST['penerima_beasiswa']) ? 1 : 0;
    $jenis_beasiswa = $penerima_beasiswa ? $_POST['jenis_beasiswa'] : NULL;
    $terdampak_ekonomi = isset($_POST['terdampak_ekonomi']) ? 1 : 0;
    $keterangan_tambahan = $_POST['keterangan_tambahan'];

    // Gunakan INSERT ... ON DUPLICATE KEY UPDATE untuk aman
    $stmt = $pdo->prepare("
        INSERT INTO profil_sosial_warga (id_warga, status_ekonomi, status_disabilitas, penerima_bansos, jenis_bansos, penerima_beasiswa, jenis_beasiswa, terdampak_ekonomi, keterangan_tambahan) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
        status_ekonomi=VALUES(status_ekonomi), 
        status_disabilitas=VALUES(status_disabilitas), 
        penerima_bansos=VALUES(penerima_bansos), 
        jenis_bansos=VALUES(jenis_bansos), 
        penerima_beasiswa=VALUES(penerima_beasiswa), 
        jenis_beasiswa=VALUES(jenis_beasiswa), 
        terdampak_ekonomi=VALUES(terdampak_ekonomi), 
        keterangan_tambahan=VALUES(keterangan_tambahan)
    ");
    
    if ($stmt->execute([$id_warga, $status_ekonomi, $status_disabilitas, $penerima_bansos, $jenis_bansos, $penerima_beasiswa, $jenis_beasiswa, $terdampak_ekonomi, $keterangan_tambahan])) {
        header("Location: data_sosial.php?msg=Profil sosial warga berhasil diperbarui!");
        exit;
    }
}

// ==========================================
// LOGIC: Statistik Data Sosial
// ==========================================
 $total_warga = $pdo->query("SELECT COUNT(*) FROM warga")->fetchColumn();
 $mampu = $pdo->query("SELECT COUNT(*) FROM profil_sosial_warga WHERE status_ekonomi='Mampu'")->fetchColumn();
 $kurang_mampu = $pdo->query("SELECT COUNT(*) FROM profil_sosial_warga WHERE status_ekonomi='Kurang Mampu'")->fetchColumn();
 $sangat_km = $pdo->query("SELECT COUNT(*) FROM profil_sosial_warga WHERE status_ekonomi='Sangat Kurang Mampu'")->fetchColumn();
 $penerima_bansos = $pdo->query("SELECT COUNT(*) FROM profil_sosial_warga WHERE penerima_bansos=1")->fetchColumn();
 $disabilitas = $pdo->query("SELECT COUNT(*) FROM profil_sosial_warga WHERE status_disabilitas != 'Tidak Ada'")->fetchColumn();

// LOGIC: Ambil Data Detail & Pencarian
 $search = $_GET['search'] ?? '';
 $query_str = "SELECT w.id_warga, w.nama_lengkap, w.nik, w.alamat, ps.status_ekonomi, ps.status_disabilitas, ps.penerima_bansos, ps.jenis_bansos, ps.penerima_beasiswa, ps.jenis_beasiswa, ps.terdampak_ekonomi, ps.keterangan_tambahan 
              FROM warga w 
              LEFT JOIN profil_sosial_warga ps ON w.id_warga = ps.id_warga";

if (!empty($search)) {
    $stmt = $pdo->prepare($query_str . " WHERE w.nama_lengkap LIKE ? OR w.nik LIKE ?");
    $stmt->execute(["%$search%", "%$search%"]);
} else {
    $stmt = $pdo->query($query_str);
}
 $data_sosial = $stmt->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<style>
    .gradient-blue   { background: linear-gradient(135deg, #4e73df 0%, #224abe 100%); }
    .gradient-green  { background: linear-gradient(135deg, #1cc88a 0%, #17a673 100%); }
    .gradient-orange { background: linear-gradient(135deg, #f6c23e 0%, #dda20a 100%); }
    .gradient-red    { background: linear-gradient(135deg, #e74a3b 0%, #be2617 100%); }
    .gradient-purple { background: linear-gradient(135deg, #6f42c1 0%, #520dc2 100%); }
    .card-stat { border: none; border-radius: 15px; color: white; transition: transform 0.2s; }
    .card-stat:hover { transform: translateY(-3px); }
</style>

<div class="container-fluid">
    <h3 class="mt-4 mb-4"><i class="bi bi-bar-chart-fill me-2"></i>Data Sosial Ekonomi Warga</h3>

    <?php if(isset($_GET['msg'])): ?>
        <div class="alert alert-success alert-dismissible fade show rounded-3 border-0 shadow-sm" role="alert">
            <i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($_GET['msg']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Summary Cards -->
    <div class="row mb-4">
        <div class="col-lg-2 col-md-4 mb-3">
            <div class="card card-stat gradient-blue shadow py-3">
                <div class="card-body text-center">
                    <h1 class="mb-0 fw-bold"><?= $total_warga ?></h1>
                    <span class="small">Total Warga</span>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 mb-3">
            <div class="card card-stat gradient-green shadow py-3">
                <div class="card-body text-center">
                    <h1 class="mb-0 fw-bold"><?= $mampu ?></h1>
                    <span class="small">Mampu</span>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 mb-3">
            <div class="card card-stat gradient-orange shadow py-3">
                <div class="card-body text-center">
                    <h1 class="mb-0 fw-bold"><?= $kurang_mampu ?></h1>
                    <span class="small">Kurang Mampu</span>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 mb-3">
            <div class="card card-stat gradient-red shadow py-3">
                <div class="card-body text-center">
                    <h1 class="mb-0 fw-bold"><?= $sangat_km ?></h1>
                    <span class="small">Sangat Kurang Mampu</span>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 mb-3">
            <div class="card card-stat gradient-purple shadow py-3">
                <div class="card-body text-center">
                    <h1 class="mb-0 fw-bold"><?= $penerima_bansos ?></h1>
                    <span class="small">Penerima Bansos</span>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 mb-3">
            <div class="card card-stat gradient-blue shadow py-3">
                <div class="card-body text-center">
                    <h1 class="mb-0 fw-bold"><?= $disabilitas ?></h1>
                    <span class="small">Disabilitas</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Search & Table Detail -->
    <div class="card shadow border-0 rounded-3">
        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 fw-bold text-primary">Detail Profil Sosial Warga</h6>
            <form method="GET" class="d-flex">
                <input type="text" name="search" class="form-control form-control-sm me-2" placeholder="Cari Nama/NIK..." value="<?= htmlspecialchars($search) ?>">
                <button type="submit" class="btn btn-sm btn-primary"><i class="bi bi-search"></i></button>
            </form>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>No</th>
                            <th>Nama Lengkap</th>
                            <th>NIK</th>
                            <th>Alamat</th>
                            <th>Status Ekonomi</th>
                            <th>Disabilitas</th>
                            <th>Bansos</th>
                            <th width="10%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($data_sosial) > 0): ?>
                            <?php $no = 1; foreach($data_sosial as $ds): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td class="fw-bold"><?= htmlspecialchars($ds['nama_lengkap']) ?></td>
                                <td><?= $ds['nik'] ?></td>
                                <td class="small"><?= htmlspecialchars($ds['alamat']) ?></td>
                                <td>
                                    <?php 
                                        $ekonomi_badge = 'bg-success';
                                        if($ds['status_ekonomi'] == 'Kurang Mampu') $ekonomi_badge = 'bg-warning text-dark';
                                        if($ds['status_ekonomi'] == 'Sangat Kurang Mampu') $ekonomi_badge = 'bg-danger';
                                    ?>
                                    <span class="badge <?= $ekonomi_badge ?>"><?= $ds['status_ekonomi'] ?? 'Belum Diisi' ?></span>
                                </td>
                                <td><?= $ds['status_disabilitas'] ?? 'Belum Diisi' ?></td>
                                <td>
                                    <?php if($ds['penerima_bansos'] == 1): ?>
                                        <span class="badge bg-info text-dark"><i class="bi bi-check-circle me-1"></i><?= htmlspecialchars($ds['jenis_bansos']) ?></span>
                                    <?php else: ?>
                                        <span class="text-muted small">Tidak</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#editSosialModal" 
                                        data-id="<?= $ds['id_warga'] ?>" 
                                    >
                                        <i class="bi bi-pencil-square"></i>
                                    </button>
                                </td>
                            </tr>

                            <!-- Modal Edit Sosial -->
                            <div class="modal fade" id="editSosialModal" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form method="POST">
                                            <input type="hidden" name="id_warga" id="edit_id_warga">
                                            <div class="modal-header bg-primary text-white">
                                                <h5 class="modal-title">Edit Profil Sosial: <span id="edit_nama_warga"></span></h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label class="form-label fw-semibold">Status Ekonomi</label>
                                                    <select name="status_ekonomi" id="edit_status_ekonomi" class="form-select" required>
                                                        <option value="Mampu">Mampu</option>
                                                        <option value="Kurang Mampu">Kurang Mampu</option>
                                                        <option value="Sangat Kurang Mampu">Sangat Kurang Mampu</option>
                                                    </select>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label fw-semibold">Status Disabilitas</label>
                                                    <select name="status_disabilitas" id="edit_status_disabilitas" class="form-select" required>
                                                        <option value="Tidak Ada">Tidak Ada</option>
                                                        <option value="Fisik">Fisik</option>
                                                        <option value="Netra">Netra</option>
                                                        <option value="Rungu/Wicara">Rungu/Wicara</option>
                                                        <option value="Mental">Mental</option>
                                                        <option value="Ganda">Ganda</option>
                                                    </select>
                                                </div>
                                                <div class="form-check mb-3">
                                                    <input class="form-check-input" type="checkbox" name="penerima_bansos" id="edit_penerima_bansos" value="1">
                                                    <label class="form-check-label fw-semibold" for="edit_penerima_bansos">Penerima Bansos</label>
                                                </div>
                                                
                                                <!-- Dropdown Jenis Bansos (SEBELUMNYA INPUT TEXT) -->
                                                <div class="mb-3" id="wrap_jenis_bansos" style="display: none;">
                                                    <label class="form-label">Jenis Bansos</label>
                                                    <select name="jenis_bansos" id="edit_jenis_bansos" class="form-select">
                                                        <option value="">-- Pilih Jenis Bansos --</option>
                                                        <option value="PKH">PKH (Program Keluarga Harapan)</option>
                                                        <option value="BPNT">BPNT (Bantuan Pangan Non-Tunai)</option>
                                                        <option value="ATENSI">ATENSI (Asistensi Rehabilitasi Sosial)</option>
                                                        <option value="PBI-JK">PBI-JK (Penerima Bantuan Iuran Jaminan Kesehatan)</option>
                                                        <option value="YAPI">YAPI (Yatim Piatu)</option>
                                                        <option value="PKH Anak Sekolah">PKH Anak Sekolah (PKH Komponen Pendidikan)</option>
                                                        <option value="SR">SR (Sekolah Rakyat)</option>
                                                        <option value="PIP">PIP (Program Indonesia Pintar)</option>
                                                        <option value="KIP">KIP (Kartu Indonesia Pintar)</option>
                                                        <option value="Lainnya">Lainnya</option>
                                                    </select>
                                                </div>

                                                <div class="form-check mb-3">
                                                    <input class="form-check-input" type="checkbox" name="terdampak_ekonomi" id="edit_terdampak_ekonomi" value="1">
                                                    <label class="form-check-label fw-semibold" for="edit_terdampak_ekonomi">Terdampak Ekonomi (PHK / Covid / Bencana)</label>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Keterangan Tambahan</label>
                                                    <textarea name="keterangan_tambahan" id="edit_keterangan" class="form-control" rows="2"></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                <button type="submit" name="update_sosial" class="btn btn-primary">Simpan Perubahan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="8" class="text-center py-4 text-muted">Data tidak ditemukan.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
// Script untuk Modal Edit Sosial
var editModal = document.getElementById('editSosialModal');
editModal.addEventListener('show.bs.modal', function (event) {
    var button = event.relatedTarget;
    
    // Ambil id warga
    var idWarga = button.getAttribute('data-id');
    document.getElementById('edit_id_warga').value = idWarga;
    
    // Ambil data dari tabel baris tersebut
    var row = button.closest('tr');
    var cells = row.querySelectorAll('td');
    
    var namaWarga = cells[1].innerText;
    var statusEko = cells[4].innerText.trim();
    var statusDis = cells[5].innerText.trim();
    var bansosStatus = cells[6].querySelector('.badge') ? true : false;
    var jenisBansos = bansosStatus ? cells[6].innerText.trim() : ''; // Ambil teks jenis bansos

    document.getElementById('edit_nama_warga').innerText = namaWarga;
    
    // Set Select Ekonomi
    var selEko = document.getElementById('edit_status_ekonomi');
    for(var i=0; i<selEko.options.length; i++){ if(selEko.options[i].text == statusEko) selEko.selectedIndex = i; }

    // Set Select Disabilitas
    var selDis = document.getElementById('edit_status_disabilitas');
    for(var i=0; i<selDis.options.length; i++){ if(selDis.options[i].text == statusDis) selDis.selectedIndex = i; }

    // Set Checkbox & Dropdown Bansos
    document.getElementById('edit_penerima_bansos').checked = bansosStatus;
    
    // Set value dropdown jenis bansos
    document.getElementById('edit_jenis_bansos').value = jenisBansos;
    
    // Tampilkan/sembunyikan dropdown jenis bansos
    document.getElementById('wrap_jenis_bansos').style.display = bansosStatus ? 'block' : 'none';
});

// Toggle tampilan dropdown jenis bansos saat checkbox diklik
document.getElementById('edit_penerima_bansos').addEventListener('change', function(e) {
    document.getElementById('wrap_jenis_bansos').style.display = e.target.checked ? 'block' : 'none';
    if(!e.target.checked) {
        document.getElementById('edit_jenis_bansos').value = ''; // Reset dropdown jika checkbox dicentang off
    }
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>