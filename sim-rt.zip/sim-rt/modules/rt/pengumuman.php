<?php
require_once __DIR__ . '/../../includes/auth.php';
// Wewenang ganda: Admin dan Ketua RT boleh akses
requireRole(['ketua_rt', 'admin']);
require_once __DIR__ . '/../../config/database.php';

// ==========================================
// LOGIC: Proses Tambah, Edit, Hapus
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'];

    if ($aksi === 'tambah') {
        $stmt = $pdo->prepare("INSERT INTO pengumuman (judul, isi, penulis, status) VALUES (?, ?, ?, ?)");
        $stmt->execute([$_POST['judul'], $_POST['isi'], $_SESSION['id_user'], $_POST['status']]);
        $msg = "Pengumuman berhasil ditambahkan!";
    } 
    elseif ($aksi === 'edit') {
        $stmt = $pdo->prepare("UPDATE pengumuman SET judul=?, isi=?, status=? WHERE id_pengumuman=?");
        $stmt->execute([$_POST['judul'], $_POST['isi'], $_POST['status'], $_POST['id_pengumuman']]);
        $msg = "Pengumuman berhasil diperbarui!";
    } 
    elseif ($aksi === 'hapus') {
        $stmt = $pdo->prepare("DELETE FROM pengumuman WHERE id_pengumuman=?");
        $stmt->execute([$_POST['id_pengumuman']]);
        $msg = "Pengumuman berhasil dihapus!";
    }

    header("Location: pengumuman.php?msg=" . urlencode($msg));
    exit;
}

// Ambil data pengumuman
 $stmt = $pdo->query("SELECT p.*, u.username FROM pengumuman p JOIN users u ON p.penulis=u.id_user ORDER BY p.tanggal_post DESC");
 $pengumuman = $stmt->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="container-fluid">
    <h3 class="mt-4 mb-4"><i class="bi bi-megaphone-fill me-2"></i>Kelola Papan Pengumuman</h3>

    <!-- Notifikasi -->
    <?php if(isset($_GET['msg'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle me-2"></i> <?= htmlspecialchars($_GET['msg']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="modal" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="d-flex justify-content-end mb-3">
        <button class="btn btn-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#modalTambah">
            <i class="bi bi-plus-circle me-1"></i> Tambah Pengumuman
        </button>
    </div>

    <div class="card shadow border-0 rounded-3">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th width="5%">No</th>
                            <th>Judul</th>
                            <th>Isi Singkat</th>
                            <th>Penulis</th>
                            <th>Tanggal</th>
                            <th>Status</th>
                            <th width="15%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($pengumuman) > 0): ?>
                            <?php $no=1; foreach($pengumuman as $p): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td class="fw-bold"><?= htmlspecialchars($p['judul']) ?></td>
                                <td class="small text-muted" style="max-width: 300px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                    <?= htmlspecialchars($p['isi']) ?>
                                </td>
                                <td><span class="badge bg-secondary"><?= ucfirst($p['username']) ?></span></td>
                                <td class="small"><?= date('d M Y, H:i', strtotime($p['tanggal_post'])) ?></td>
                                <td>
                                    <?php if($p['status'] == 'aktif'): ?>
                                        <span class="badge bg-success">Aktif</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Nonaktif</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-warning" data-bs-toggle="modal" data-bs-target="#modalEdit<?= $p['id_pengumuman'] ?>">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#modalHapus<?= $p['id_pengumuman'] ?>">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </td>
                            </tr>

                            <!-- Modal Edit -->
                            <div class="modal fade" id="modalEdit<?= $p['id_pengumuman'] ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form method="POST">
                                            <input type="hidden" name="aksi" value="edit">
                                            <input type="hidden" name="id_pengumuman" value="<?= $p['id_pengumuman'] ?>">
                                            <div class="modal-header bg-warning text-white">
                                                <h5 class="modal-title">Edit Pengumuman</h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label class="fw-bold">Judul</label>
                                                    <input type="text" name="judul" class="form-control" value="<?= htmlspecialchars($p['judul']) ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="fw-bold">Isi Pengumuman</label>
                                                    <textarea name="isi" class="form-control" rows="5" required><?= htmlspecialchars($p['isi']) ?></textarea>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="fw-bold">Status</label>
                                                    <select name="status" class="form-select">
                                                        <option value="aktif" <?= $p['status']=='aktif'?'selected':'' ?>>Aktif (Tampil di banner)</option>
                                                        <option value="nonaktif" <?= $p['status']=='nonaktif'?'selected':'' ?>>Nonaktif (Disembunyikan)</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                <button type="submit" class="btn btn-warning text-white">Simpan Perubahan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Modal Hapus -->
                            <div class="modal fade" id="modalHapus<?= $p['id_pengumuman'] ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form method="POST">
                                            <input type="hidden" name="aksi" value="hapus">
                                            <input type="hidden" name="id_pengumuman" value="<?= $p['id_pengumuman'] ?>">
                                            <div class="modal-header bg-danger text-white">
                                                <h5 class="modal-title">Hapus Pengumuman?</h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p>Anda yakin ingin menghapus pengumuman <b>"<?= htmlspecialchars($p['judul']) ?>"</b>?</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                <button type="submit" class="btn btn-danger">Ya, Hapus</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="7" class="text-center py-4 text-muted">Belum ada pengumuman.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah -->
<div class="modal fade" id="modalTambah" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="aksi" value="tambah">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">Buat Pengumuman Baru</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="fw-bold">Judul Pengumuman</label>
                        <input type="text" name="judul" class="form-control" placeholder="Contoh: Jadwal Kerja Bakti" required>
                    </div>
                    <div class="mb-3">
                        <label class="fw-bold">Isi Pengumuman</label>
                        <textarea name="isi" class="form-control" rows="5" placeholder="Tuliskan detail pengumuman..." required></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="fw-bold">Status</label>
                        <select name="status" class="form-select">
                            <option value="aktif">Aktif (Langsung tampil)</option>
                            <option value="nonaktif">Nonaktif (Simpan sebagai draft)</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Publikasikan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>