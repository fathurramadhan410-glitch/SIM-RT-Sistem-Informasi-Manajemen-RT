<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole(['ketua_rt', 'admin']);
require_once __DIR__ . '/../../config/database.php';

// Query Statistik
 $pending_surat = $pdo->query("SELECT COUNT(*) FROM pengajuan_surat WHERE status='pending'")->fetchColumn();
 $total_warga = $pdo->query("SELECT COUNT(*) FROM warga")->fetchColumn();
 $kurang_mampu = $pdo->query("SELECT COUNT(*) FROM profil_sosial_warga WHERE status_ekonomi IN ('Kurang Mampu','Sangat Kurang Mampu')")->fetchColumn();
 $aduan_baru = $pdo->query("SELECT COUNT(*) FROM pengaduan WHERE status='baru'")->fetchColumn();

// Query Surat Pending Terbaru
 $stmt_surat = $pdo->query("SELECT ps.*, w.nama_lengkap FROM pengajuan_surat ps JOIN warga w ON ps.id_warga=w.id_warga WHERE ps.status='pending' ORDER BY ps.tanggal_ajuan DESC LIMIT 5");
 $surat_pending = $stmt_surat->fetchAll();

// Query Pengumuman Aktif
 $stmt_pengumuman = $pdo->query("SELECT p.*, u.username FROM pengumuman p JOIN users u ON p.penulis=u.id_user WHERE p.status='aktif' ORDER BY p.tanggal_post DESC LIMIT 3");
 $pengumuman = $stmt_pengumuman->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<!-- Custom CSS Modern -->
<style>
    .gradient-primary { background: linear-gradient(135deg, #4e73df 0%, #224abe 100%); }
    .gradient-warning { background: linear-gradient(135deg, #f6c23e 0%, #f4a300 100%); }
    .gradient-danger  { background: linear-gradient(135deg, #e74a3b 0%, #be2617 100%); }
    .gradient-info    { background: linear-gradient(135deg, #36b9cc 0%, #1a9ea8 100%); }
    .card-stat { border: none; border-radius: 15px; color: white; transition: transform 0.3s; }
    .card-stat:hover { transform: translateY(-5px); }
    .clock-display { font-family: 'Segoe UI', sans-serif; font-weight: 300; letter-spacing: 2px; }
    .announcement-card { border-left: 5px solid #4e73df; }
</style>

<div class="container-fluid">

    <!-- Welcome Banner & Real-Time Clock -->
    <div class="row mb-4 align-items-center bg-white p-4 rounded-3 shadow-sm">
        <div class="col-md-7">
            <h2 class="fw-bold text-dark mb-1">Selamat Datang, <?= htmlspecialchars($_SESSION['nama_lengkap']); ?> 👋</h2>
            <p class="text-muted mb-0">Berikut adalah ringkasan data dan aktivitas lingkungan RT Anda hari ini.</p>
        </div>
        <div class="col-md-5 text-md-end mt-3 mt-md-0">
            <div class="text-muted text-uppercase small" id="day-date-year"></div>
            <h2 class="fw-bold text-primary clock-display" id="realtime-clock" style="font-size: 2.5rem;"></h2>
        </div>
    </div>

    <!-- Statistik Cards -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card card-stat gradient-warning shadow py-3">
                <div class="card-body text-center">
                    <i class="bi bi-envelope-exclamation-fill" style="font-size: 2.5rem; opacity: 0.8;"></i>
                    <h1 class="mt-2 mb-0 fw-bold"><?= $pending_surat ?></h1>
                    <span>Surat Pending</span>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card card-stat gradient-primary shadow py-3">
                <div class="card-body text-center">
                    <i class="bi bi-people-fill" style="font-size: 2.5rem; opacity: 0.8;"></i>
                    <h1 class="mt-2 mb-0 fw-bold"><?= $total_warga ?></h1>
                    <span>Total Warga</span>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card card-stat gradient-danger shadow py-3">
                <div class="card-body text-center">
                    <i class="bi bi-heart-pulse-fill" style="font-size: 2.5rem; opacity: 0.8;"></i>
                    <h1 class="mt-2 mb-0 fw-bold"><?= $kurang_mampu ?></h1>
                    <span>Kurang Mampu</span>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card card-stat gradient-info shadow py-3">
                <div class="card-body text-center">
                    <i class="bi bi-chat-dots-fill" style="font-size: 2.5rem; opacity: 0.8;"></i>
                    <h1 class="mt-2 mb-0 fw-bold"><?= $aduan_baru ?></h1>
                    <span>Aduan Baru</span>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        
        <!-- Kolom Kiri: Papan Pengumuman Digital -->
        <div class="col-lg-5 mb-4">
            <div class="card shadow border-0 rounded-3">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 fw-bold text-primary"><i class="bi bi-megaphone-fill me-2"></i>Pengumuman Terbaru</h6>
                    <a href="pengumuman.php" class="btn btn-sm btn-outline-primary">Kelola</a>
                </div>
                <div class="card-body p-0">
                    <?php if(count($pengumuman) > 0): ?>
                        <ul class="list-group list-group-flush">
                            <?php foreach($pengumuman as $p): ?>
                            <li class="list-group-item announcement-card p-3">
                                <div class="d-flex justify-content-between">
                                    <h6 class="fw-bold text-dark"><?= htmlspecialchars($p['judul']) ?></h6>
                                    <small class="text-muted"><?= date('d M Y', strtotime($p['tanggal_post'])) ?></small>
                                </div>
                                <p class="text-muted small mb-0"><?= nl2br(htmlspecialchars($p['isi'])) ?></p>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <div class="text-center p-4 text-muted"><i class="bi bi-journal-x" style="font-size:2rem;"></i><br>Belum ada pengumuman.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Kolom Kanan: Surat Menunggu Persetujuan -->
        <div class="col-lg-7 mb-4">
            <div class="card shadow border-0 rounded-3">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 fw-bold text-primary"><i class="bi bi-clock-history me-2"></i>Antrian Surat Warga</h6>
                    <a href="validasi_surat.php" class="btn btn-sm btn-outline-primary">Lihat Semua</a>
                </div>
                <div class="card-body p-0">
                    <?php if(count($surat_pending) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0 align-middle">
                            <thead class="table-light">
                                <tr><th>Pemohon</th><th>Jenis Surat</th><th>Waktu Ajuan</th><th>Aksi</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach($surat_pending as $sp): ?>
                                <tr>
                                    <td class="fw-bold"><?= htmlspecialchars($sp['nama_lengkap']) ?></td>
                                    <td><span class="badge bg-info"><?= $sp['jenis_surat'] ?></span></td>
                                    <td class="small text-muted"><?= date('d M Y, H:i', strtotime($sp['tanggal_ajuan'])) ?></td>
                                    <td><a href="validasi_surat.php?id=<?= $sp['id_surat'] ?>" class="btn btn-success btn-sm"><i class="bi bi-check-lg"></i> Proses</a></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                        <div class="text-center p-5 text-muted"><i class="bi bi-inbox" style="font-size:2rem;"></i><br>Semua surat sudah diproses.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- Script Real-Time Clock -->
<script>
    function updateClock() {
        const now = new Date();
        const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
        const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
        
        const dayName = days[now.getDay()];
        const date = now.getDate();
        const monthName = months[now.getMonth()];
        const year = now.getFullYear();
        
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        const seconds = String(now.getSeconds()).padStart(2, '0');

        document.getElementById('day-date-year').textContent = `${dayName}, ${date} ${monthName} ${year}`;
        document.getElementById('realtime-clock').textContent = `${hours}:${minutes}:${seconds} WIB`;
    }
    
    updateClock();
    setInterval(updateClock, 1000);
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>