<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole(['ketua_rt', 'admin']);
require_once __DIR__ . '/../../config/database.php';

 $stmt = $pdo->query("SELECT p.*, w.nama_lengkap FROM pengaduan p JOIN warga w ON p.id_warga=w.id_warga ORDER BY p.tanggal_aduan DESC");
 $aduan = $stmt->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="container-fluid">
    <h3 class="mt-4 mb-4"><i class="bi bi-chat-dots me-2"></i>Layanan Pengaduan Warga</h3>

    <div class="card shadow-sm border-0 rounded-3">
        <div class="card-body p-0">
            <?php if(count($aduan) > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0 align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Pelapor</th>
                            <th>Kategori</th>
                            <th>Isi Aduan</th>
                            <th>Tanggal</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($aduan as $a): ?>
                        <tr>
                            <td class="fw-bold"><?= htmlspecialchars($a['nama_lengkap']) ?></td>
                            <td><span class="badge bg-secondary"><?= $a['kategori'] ?></span></td>
                            <td class="small" style="max-width: 250px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="<?= htmlspecialchars($a['isi_aduan']) ?>">
                                <?= htmlspecialchars($a['isi_aduan']) ?>
                            </td>
                            <td class="small text-muted"><?= date('d M Y', strtotime($a['tanggal_aduan'])) ?></td>
                            <td>
                                <?php 
                                    $badge = 'bg-warning'; 
                                    if($a['status']=='diproses') $badge='bg-info'; 
                                    if($a['status']=='selesai') $badge='bg-success'; 
                                ?>
                                <span class="badge <?= $badge ?>"><?= ucfirst($a['status']) ?></span>
                            </td>
                            <td>
                                <a href="proses_aduan.php?id=<?= $a['id_pengaduan'] ?>" class="btn btn-sm btn-outline-primary">
    <i class="bi bi-eye me-1"></i> Proses
</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
                <div class="text-center p-5 text-muted">Belum ada pengaduan masuk.</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Modal Detail Aduan (Boilerplate for 1 item, you can loop this for all) -->
<?php foreach($aduan as $a): ?>
<div class="modal fade" id="modalAduan<?= $a['id_pengaduan'] ?>" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Detail Aduan - <?= htmlspecialchars($a['nama_lengkap']) ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p><span class="badge bg-secondary"><?= $a['kategori'] ?></span> | <small class="text-muted"><?= date('d M Y H:i', strtotime($a['tanggal_aduan'])) ?></small></p>
                <p class="bg-light p-3 rounded"><?= nl2br(htmlspecialchars($a['isi_aduan'])) ?></p>
                <hr>
                <form action="proses_aduan.php" method="POST">
                    <input type="hidden" name="id_pengaduan" value="<?= $a['id_pengaduan'] ?>">
                    <label class="fw-bold">Tanggapan RT:</label>
                    <textarea name="tanggapan" class="form-control mb-2" rows="3" required><?= htmlspecialchars($a['tanggapan'] ?? '') ?></textarea>
                    <select name="status" class="form-select mb-3" required>
                        <option value="baru" <?= $a['status']=='baru'?'selected':'' ?>>Baru</option>
                        <option value="diproses" <?= $a['status']=='diproses'?'selected':'' ?>>Diproses</option>
                        <option value="selesai" <?= $a['status']=='selesai'?'selected':'' ?>>Selesai</option>
                    </select>
                    <button type="submit" class="btn btn-primary w-100">Simpan Tanggapan</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>