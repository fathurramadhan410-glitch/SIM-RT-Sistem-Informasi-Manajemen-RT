<?php
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();
require_once __DIR__ . '/../../includes/header.php';
?>

<div class="container-fluid">
    <h3 class="mt-4 mb-4"><i class="bi bi-info-circle me-2"></i>Tentang Sistem</h3>

    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-sm border-0 rounded-3">
                <div class="card-body p-5 text-center">
                    <i class="bi bi-houses-fill text-primary" style="font-size: 5rem;"></i>
                    <h2 class="fw-bold mt-3">SIM-RT</h2>
                    <p class="lead text-muted">Sistem Informasi Manajemen Rukun Tetangga</p>
                    <hr>
                    <p class="text-justify">
                        SIM-RT adalah platform digital yang dirancang untuk memudahkan pengelolaan administrasi lingkungan RT. 
                        Sistem ini mengintegrasikan layanan persuratan, keuangan kas, data kependudukan, dan komunikasi warga secara transparan dan efisien.
                    </p>
                    <div class="row mt-4 text-start">
                        <div class="col-md-6">
                            <h5 class="fw-bold"><i class="bi bi-check-circle text-success me-2"></i>Fitur Utama:</h5>
                            <ul class="text-muted">
                                <li>Pengajuan Surat Online</li>
                                <li>Manajemen Kas & Iuran</li>
                                <li>Papan Pengumuman Digital</li>
                                <li>Layanan Pengaduan Warga</li>
                            </ul>
                        </div>
                        <div class="col-md-6">
                            <h5 class="fw-bold"><i class="bi bi-people-fill text-primary me-2"></i>Dioperasikan oleh:</h5>
                            <ul class="text-muted">
                                <li>Pengurus RT / RW</li>
                                <li>Bendahara Lingkungan</li>
                                <li>Warga Terdaftar</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="card-footer bg-light text-center text-muted small">
                    Versi 1.0 &copy; <?= date('Y') ?> SIM-RT Developer
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>