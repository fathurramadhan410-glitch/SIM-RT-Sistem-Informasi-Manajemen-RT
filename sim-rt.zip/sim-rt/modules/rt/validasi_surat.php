<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole(['ketua_rt', 'admin']);
require_once __DIR__ . '/../../config/database.php';

// ==========================================
// LOGIC: Proses Validasi (Setujui/Tolak)
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_surat = $_POST['id_surat'];
    $aksi = $_POST['aksi'];

    if ($aksi === 'setujui') {
    // Generate Nomor Surat Otomatis Berdasarkan Jenis Surat
    $tahun_ini = date('Y');
    
    // Hitung jumlah surat yang sudah disetujui tahun ini untuk urutan nomor
    $stmt_count = $pdo->query("SELECT COUNT(*) FROM pengajuan_surat WHERE status='disetujui' AND YEAR(tanggal_diproses) = $tahun_ini");
    $urutan = $stmt_count->fetchColumn() + 1;
    
    // Mapping Kode Singkatan Jenis Surat
    $kode_jenis = [
        'Pengantar KTP' => 'SPK',
        'Pengantar Pindah' => 'SPP',
        'Keterangan Domisili' => 'SKD',
        'Keterangan Usaha' => 'SKU',
        'Keterangan Tidak Mampu' => 'SKTM',
        'Pengantar SKCK' => 'SPS',
        'Pengantar Kematian' => 'SPKM',
        'Rekomendasi' => 'SR'
    ];
    
    $jenis_surat = $_POST['jenis_surat'];
    $kode = $kode_jenis[$jenis_surat] ?? 'SURAT'; // Fallback jika tidak ada di list
    
    // Format Nomor Surat: 001/SPK/RT17/2024
    $nomor_surat = sprintf("%03d", $urutan) . "/$kode/RT17/$tahun_ini";

    // Update database, masukkan nomor suratnya
    $stmt = $pdo->prepare("UPDATE pengajuan_surat SET status='disetujui', nomor_surat=?, tanggal_diproses=NOW(), diproses_oleh=? WHERE id_surat=?");
    $stmt->execute([$nomor_surat, $_SESSION['id_user'], $id_surat]);
    
    $pesan = "Surat berhasil disetujui! Nomor Surat: $nomor_surat";
    
} else if ($aksi === 'tolak') {
    $catatan = $_POST['catatan_rt'];
    $stmt = $pdo->prepare("UPDATE pengajuan_surat SET status='ditolak', catatan_rt=?, tanggal_diproses=NOW(), diproses_oleh=? WHERE id_surat=?");
    $stmt->execute([$catatan, $_SESSION['id_user'], $id_surat]);
    
    $pesan = "Surat telah ditolak.";
}
    
    // Redirect untuk menghindari resubmit form
    header("Location: validasi_surat.php?msg=" . urlencode($pesan));
    exit;
}

// ==========================================
// LOGIC: Ambil Data Surat & Filter
// ==========================================
 $filter_status = $_GET['status'] ?? 'semua';
 $query = "SELECT ps.*, w.nama_lengkap, w.nik FROM pengajuan_surat ps JOIN warga w ON ps.id_warga=w.id_warga";

if ($filter_status !== 'semua' && in_array($filter_status, ['pending', 'disetujui', 'ditolak'])) {
    $query .= " WHERE ps.status = ?";
    $stmt = $pdo->prepare($query . " ORDER BY ps.tanggal_ajuan DESC");
    $stmt->execute([$filter_status]);
} else {
    $stmt = $pdo->query($query . " ORDER BY ps.tanggal_ajuan DESC");
}
 $surat = $stmt->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<style>
    .gradient-pending { background: linear-gradient(135deg, #f6c23e 0%, #f4a300 100%); }
    .gradient-success { background: linear-gradient(135deg, #1cc88a 0%, #17a673 100%); }
    .gradient-danger  { background: linear-gradient(135deg, #e74a3b 0%, #be2617 100%); }
    .card-stat-sm { border: none; border-radius: 12px; color: white; }
</style>

<div class="container-fluid">
    <h3 class="mt-4 mb-4"><i class="bi bi-envelope-paper me-2"></i>Validasi & Persuratan</h3>

    <!-- Notifikasi Sukses -->
    <?php if(isset($_GET['msg'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle me-2"></i> <?= htmlspecialchars($_GET['msg']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Filter Buttons -->
    <div class="btn-group mb-4 shadow-sm" role="group">
        <a href="?status=semua" class="btn btn-outline-dark <?= $filter_status === 'semua' ? 'active' : '' ?>">Semua</a>
        <a href="?status=pending" class="btn btn-outline-warning <?= $filter_status === 'pending' ? 'active' : '' ?>">Pending</a>
        <a href="?status=disetujui" class="btn btn-outline-success <?= $filter_status === 'disetujui' ? 'active' : '' ?>">Disetujui</a>
        <a href="?status=ditolak" class="btn btn-outline-danger <?= $filter_status === 'ditolak' ? 'active' : '' ?>">Ditolak</a>
    </div>

    <div class="card shadow border-0 rounded-3">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th width="5%">No</th>
                            <th>Pemohon</th>
                            <th>Jenis Surat</th>
                            <th>Keperluan</th>
                            <th>Tanggal Ajuan</th>
                            <th>Nomor Surat</th>
                            <th>Status</th>
                            <th width="15%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($surat) > 0): ?>
                            <?php $no = 1; foreach($surat as $s): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td>
                                    <div class="fw-bold"><?= htmlspecialchars($s['nama_lengkap']) ?></div>
                                    <small class="text-muted">NIK: <?= $s['nik'] ?></small>
                                </td>
                                <td><span class="badge bg-info text-dark"><?= $s['jenis_surat'] ?></span></td>
                                <td class="small"><?= htmlspecialchars($s['keperluan']) ?></td>
                                <td class="small text-muted"><?= date('d M Y, H:i', strtotime($s['tanggal_ajuan'])) ?></td>
                                <td class="fw-bold text-primary"><?= $s['nomor_surat'] ?? '-' ?></td>
                                <td>
                                    <?php 
                                        $badge = 'bg-warning text-dark'; 
                                        if($s['status']=='disetujui') $badge='bg-success'; 
                                        if($s['status']=='ditolak') $badge='bg-danger'; 
                                    ?>
                                    <span class="badge <?= $badge ?>"><?= ucfirst($s['status']) ?></span>
                                </td>
                                <td>
                                    <?php if($s['status'] === 'pending'): ?>
                                        <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#modalSetujui<?= $s['id_surat'] ?>">
                                            <i class="bi bi-check-lg"></i>
                                        </button>
                                        <button class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#modalTolak<?= $s['id_surat'] ?>">
                                            <i class="bi bi-x-lg"></i>
                                        </button>
                                    <?php else: ?>
                                        <small class="text-muted">Selesai</small>
                                    <?php endif; ?>
                                </td>
                            </tr>

                            <!-- Modal Setujui -->
                            <div class="modal fade" id="modalSetujui<?= $s['id_surat'] ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form method="POST">
                                            <input type="hidden" name="id_surat" value="<?= $s['id_surat'] ?>">
                                            <input type="hidden" name="jenis_surat" value="<?= $s['jenis_surat'] ?>">
                                            <input type="hidden" name="aksi" value="setujui">
                                            <div class="modal-header bg-success text-white">
                                                <h5 class="modal-title">Setujui Surat</h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p>Anda akan menyetujui surat <b><?= $s['jenis_surat'] ?></b> atas nama <b><?= htmlspecialchars($s['nama_lengkap']) ?></b>.</p>
                                                <p class="text-muted small">Nomor surat akan digenerate otomatis oleh sistem setelah disetujui.</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                <button type="submit" class="btn btn-success"><i class="bi bi-check-circle me-1"></i> Ya, Setujui</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Modal Tolak -->
                            <div class="modal fade" id="modalTolak<?= $s['id_surat'] ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form method="POST">
                                            <input type="hidden" name="id_surat" value="<?= $s['id_surat'] ?>">
                                            <input type="hidden" name="aksi" value="tolak">
                                            <div class="modal-header bg-danger text-white">
                                                <h5 class="modal-title">Tolak Surat</h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p>Alasan penolakan surat atas nama <b><?= htmlspecialchars($s['nama_lengkap']) ?></b>:</p>
                                                <textarea name="catatan_rt" class="form-control" rows="3" required placeholder="Tuliskan alasan penolakan..."></textarea>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                <button type="submit" class="btn btn-danger"><i class="bi bi-x-circle me-1"></i> Ya, Tolak</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="8" class="text-center py-5 text-muted"><i class="bi bi-inbox" style="font-size:2rem;"></i><br>Tidak ada data surat.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>