<?php
// Mulai session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Jika user sudah login, langsung lempar ke dashboard sesuai role
if (isset($_SESSION['id_user'])) {
    $role = $_SESSION['role'];
    if ($role == 'admin') header("Location: ../admin/users.php");
    elseif ($role == 'ketua_rt') header("Location: ../rt/dashboard.php");
    elseif ($role == 'bendahara') header("Location: ../bendahara/kas.php");
    elseif ($role == 'warga') header("Location: ../warga/dashboard.php");
    exit;
}

require_once __DIR__ . '/../../config/database.php';

 $error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (empty($username) || empty($password)) {
        $error = "Username dan Password wajib diisi!";
    } else {
        $stmt = $pdo->prepare("SELECT u.*, w.nama_lengkap FROM users u LEFT JOIN warga w ON u.id_warga = w.id_warga WHERE u.username = ? AND u.status_aktif = 1");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['id_user'] = $user['id_user'];
            $_SESSION['id_warga'] = $user['id_warga'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['nama_lengkap'] = $user['nama_lengkap'] ?? $user['username'];

            $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id_user = ?")->execute([$user['id_user']]);

            $role = $user['role'];
            if ($role == 'admin') header("Location: ../admin/users.php");
            elseif ($role == 'ketua_rt') header("Location: ../rt/dashboard.php");
            elseif ($role == 'bendahara') header("Location: ../bendahara/kas.php");
            elseif ($role == 'warga') header("Location: ../warga/dashboard.php");
            exit;
        } else {
            $error = "Username atau Password salah, atau akun nonaktif!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SIM RT</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            overflow: hidden;
        }
        
        .login-wrapper {
            display: flex;
            height: 100vh;
        }

        /* Bagian Kiri (Foto Murni tanpa overlay warna) */
        .login-left {
            flex: 1.2;
            background-image: url('https://z-cdn-media.chatglm.cn/files/0d4dbfa0-4ae9-4a82-b44b-0aba45308e7f.jpg?auth_key=1883307652-510a729df83b4276973129e80d614ad0-0-16bf0b45112e9f6b973b43c65ed2d19a');
            background-size: cover;
            background-position: center;
        }

        /* Bagian Kanan (Form Login) */
        .login-right {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 3rem 4rem;
            background-color: #ffffff;
            position: relative;
        }

        /* Kotak Branding di Tengah Atas */
        .brand-box {
            text-align: center;
            border: 2px solid #6610f2;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 2.5rem;
            background-color: #f8f9fa;
            box-shadow: 0 4px 10px rgba(102, 16, 242, 0.1);
        }

        .brand-box i {
            font-size: 2.5rem;
            color: #6610f2;
            margin-bottom: 0.5rem;
        }

        .brand-box h1 {
            font-size: 1.8rem;
            font-weight: 800;
            letter-spacing: 2px;
            color: #6610f2;
            margin: 0;
        }

        .brand-box p {
            font-size: 0.9rem;
            color: #6c757d;
            margin: 5px 0 0 0;
            font-weight: 500;
        }

        /* Copyright di bawah */
        .copyright {
            position: absolute;
            bottom: 20px;
            left: 0;
            right: 0;
            text-align: center;
            font-size: 0.85rem;
            color: #6c757d;
            padding: 0 4rem;
        }

        @media (max-width: 992px) {
            body, html { overflow: auto; }
            .login-left { display: none; }
            .login-right { padding: 2rem; height: 100vh; }
            .copyright { padding: 0 2rem; }
        }

        .form-control, .input-group-text {
            border-radius: 8px;
            padding: 0.85rem 1rem;
        }
        
        .input-group-text {
            background-color: #f8f9fa;
            border: 1px solid #ced4da;
            border-right: 0;
            color: #6c757d;
        }
        
        .form-control:focus {
            box-shadow: none;
            border-color: #6610f2;
        }
        
        .form-control {
            border: 1px solid #ced4da;
            border-left: 0;
        }

        .form-check-input:checked {
            background-color: #6610f2;
            border-color: #6610f2;
        }

        .btn-login {
            border-radius: 8px;
            padding: 0.85rem;
            font-weight: 600;
            letter-spacing: 1px;
            background-color: #6610f2;
            border: none;
            transition: background-color 0.3s;
        }

        .btn-login:hover {
            background-color: #520dc2;
        }
    </style>
</head>
<body>
    <div class="login-wrapper">
        
        <!-- Kolom Kiri: Foto Murni Tanpa Overlay -->
        <div class="login-left"></div>

        <!-- Kolom Kanan: Form Login -->
        <div class="login-right">
            <div class="w-100" style="max-width: 400px; margin: auto;">
                
                <!-- Kotak Branding Tengah Atas -->
                <div class="brand-box">
                    <i class="bi bi-houses-fill"></i>
                    <h1>SIM-RT</h1>
                    <p>Sistem Informasi Manajemen Rukun Tetangga</p>
                </div>

                <h2 class="fw-bold mb-2">Welcome Back!</h2>
                <p class="text-muted mb-4">Please Log in to your account.</p>

                <?php if($error): ?>
                    <div class="alert alert-danger d-flex align-items-center" role="alert">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i>
                        <div><?= htmlspecialchars($error) ?></div>
                    </div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="mb-3">
                        <label class="form-label fw-semibold text-muted small">USERNAME</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-person"></i></span>
                            <input type="text" name="username" class="form-control" placeholder="Masukkan username" required autofocus>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label fw-semibold text-muted small">PASSWORD</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-lock"></i></span>
                            <input type="password" name="password" class="form-control" placeholder="Masukkan password" required>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="rememberMe">
                            <label class="form-check-label text-muted small" for="rememberMe">Remember me</label>
                        </div>
                        <a href="#" class="text-decoration-none small fw-semibold text-dark">Forgot your password?</a>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 btn-lg btn-login shadow-sm">
                        LOGIN
                    </button>
                </form>
            </div>

            <!-- Copyright -->
            <div class="copyright">
                Copyright &copy; 2026 Tim Developer SIKC POLIBAN
            </div>
        </div>

    </div>
</body>
</html>