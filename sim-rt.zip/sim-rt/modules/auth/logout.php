<?php
// Pastikan session dimulai
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 1. Hapus semua variabel session yang diset
 $_SESSION = array();

// 2. Hapus cookie session jika digunakan (Best Practice Keamanan)
// Ini memastikan session benar-benar mati di browser, bukan hanya di server
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// 3. Hancurkan session secara total di server
session_destroy();

// 4. Arahkan (redirect) pengguna kembali ke halaman login
// Karena file ini berada di modules/auth/, maka path-nya langsung login.php
header("Location: login.php");
exit;
?>