<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('bendahara');
require_once __DIR__ . '/../../config/database.php';

 $nama_bulan = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];

// ==========================================
// LOGIC: Verifikasi Pembayaran Warga
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verifikasi_iuran'])) {
    $id_iuran = $_POST['id_iuran'];
    $pdo->beginTransaction();
    try {
        $stmt_get = $pdo->prepare("SELECT pi.*, w.nama_lengkap FROM pembayaran_iuran pi JOIN warga w ON pi.id_warga=w.id_warga WHERE pi.id_iuran=?");
        $stmt_get->execute([$id_iuran]);
        $iuran = $stmt_get->fetch();

        if ($iuran && $iuran['status_bayar'] == 'pending') {
            $pdo->prepare("UPDATE pembayaran_iuran SET status_bayar='lunas', dicatat_oleh=? WHERE id_iuran=?")->execute([$_SESSION['id_user'], $id_iuran]);
            $ket_kas = "Iuran Bulan " . $nama_bulan[($iuran['bulan'] - 1)] . " {$iuran['tahun']} - " . $iuran['nama_lengkap'];
            $stmt_kas = $pdo->prepare("INSERT INTO transaksi_kas (jenis, kategori, keterangan, jumlah, metode_bayar, tanggal, dicatat_oleh) VALUES ('masuk', 'Iuran Warga', ?, ?, ?, ?, ?)");
            $stmt_kas->execute([$ket_kas, $iuran['jumlah_bayar'], $iuran['metode_bayar'], date('Y-m-d'), $_SESSION['id_user']]);
            $pdo->commit();
            header("Location: iuran.php?msg=Verifikasi berhasil! Saldo Kas RT bertambah.");
            exit;
        }
    } catch (Exception $e) { $pdo->rollBack(); }
}

// ==========================================
// LOGIC: Update Nominal Iuran Default
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_nominal'])) {
    $nominal_baru = $_POST['nominal_iuran'];
    $pdo->prepare("UPDATE pengaturan SET nominal_iuran=? WHERE id_setting=1")->execute([$nominal_baru]);
    header("Location: iuran.php?msg=Nominal iuran berhasil diperbarui!");
    exit;
}

// ==========================================
// LOGIC: GENERATE TAGIHAN MASSAL
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_tagihan'])) {
    $bulan = $_POST['bulan'];
    $tahun = $_POST['tahun'];
    $nominal = $_POST['nominal_iuran'];
    $tanggal_input = date('Y-m-d'); // Tanggal tagihan digenerate
    $dicatat_oleh = $_SESSION['id_user']; // ID Bendahara yang generate
    
    $stmt_warga = $pdo->query("SELECT id_warga FROM warga");
    $all_warga = $stmt_warga->fetchAll(PDO::FETCH_COLUMN);
    
    $count_inserted = 0;
    foreach ($all_warga as $id_warga) {
        $cek = $pdo->prepare("SELECT id_iuran FROM pembayaran_iuran WHERE id_warga=? AND bulan=? AND tahun=?");
        $cek->execute([$id_warga, $bulan, $tahun]);
        if (!$cek->fetch()) {
            // Memasukkan tanggal_input dan dicatat_oleh agar tidak melanggar constraint NOT NULL / FK
            $stmt = $pdo->prepare("INSERT INTO pembayaran_iuran (id_warga, bulan, tahun, jumlah_bayar, tanggal_bayar, metode_bayar, status_bayar, dicatat_oleh) VALUES (?, ?, ?, ?, ?, 'Tunai', 'belum_bayar', ?)");
            $stmt->execute([$id_warga, $bulan, $tahun, $nominal, $tanggal_input, $dicatat_oleh]);
            $count_inserted++;
        }
    }
    header("Location: iuran.php?msg=Tagihan berhasil digenerate untuk $count_inserted warga!");
    exit;
}

// ==========================================
// LOGIC: INPUT PEMBAYARAN MASSAL (TUNAI/CEKLEK)
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['input_bayar_massal'])) {
    $bulan = $_POST['bulan'];
    $tahun = $_POST['tahun'];
    $metode_bayar = $_POST['metode_bayar'];
    $tanggal_bayar = date('Y-m-d');
    $warga_bayar = $_POST['warga_bayar'] ?? [];
    
    if (empty($warga_bayar)) {
        header("Location: iuran.php?msg=Tidak ada warga yang dipilih!");
        exit;
    }
    
    $set_iuran = $pdo->query("SELECT nominal_iuran FROM pengaturan WHERE id_setting=1")->fetchColumn();
    $pdo->beginTransaction();
    try {
        $stmt_warga = $pdo->prepare("SELECT nama_lengkap FROM warga WHERE id_warga=?");
        
        foreach ($warga_bayar as $id_warga) {
            $cek = $pdo->prepare("SELECT id_iuran, jumlah_bayar, status_bayar FROM pembayaran_iuran WHERE id_warga=? AND bulan=? AND tahun=?");
            $cek->execute([$id_warga, $bulan, $tahun]);
            $existing = $cek->fetch();
            
            $jumlah_bayar = $set_iuran;
            
            if ($existing) {
                if ($existing['status_bayar'] == 'lunas') continue;
                $jumlah_bayar = $existing['jumlah_bayar'];
                $pdo->prepare("UPDATE pembayaran_iuran SET status_bayar='lunas', metode_bayar=?, tanggal_bayar=?, dicatat_oleh=? WHERE id_iuran=?")
                    ->execute([$metode_bayar, $tanggal_bayar, $_SESSION['id_user'], $existing['id_iuran']]);
            } else {
                $pdo->prepare("INSERT INTO pembayaran_iuran (id_warga, bulan, tahun, jumlah_bayar, tanggal_bayar, metode_bayar, status_bayar, dicatat_oleh) VALUES (?, ?, ?, ?, ?, ?, 'lunas', ?)")
                    ->execute([$id_warga, $bulan, $tahun, $jumlah_bayar, $tanggal_bayar, $metode_bayar, $_SESSION['id_user']]);
            }
            
            $stmt_warga->execute([$id_warga]);
            $nm_warga = $stmt_warga->fetchColumn();
            $ket_kas = "Iuran Bulan " . $nama_bulan[($bulan - 1)] . " $tahun - " . $nm_warga;
            $pdo->prepare("INSERT INTO transaksi_kas (jenis, kategori, keterangan, jumlah, metode_bayar, tanggal, dicatat_oleh) VALUES ('masuk', 'Iuran Warga', ?, ?, ?, ?, ?)")
                ->execute([$ket_kas, $jumlah_bayar, $metode_bayar, $tanggal_bayar, $_SESSION['id_user']]);
        }
        
        $pdo->commit();
        header("Location: iuran.php?msg=Pembayaran berhasil dicatat untuk " . count($warga_bayar) . " warga! Kas bertambah.");
        exit;
    } catch (Exception $e) {
        $pdo->rollBack();
        header("Location: iuran.php?msg=Gagal mencatat pembayaran massal.");
        exit;
    }
}

// Ambil data
 $set_iuran = $pdo->query("SELECT nominal_iuran FROM pengaturan WHERE id_setting=1")->fetchColumn();
 $warga_list = $pdo->query("SELECT id_warga, nama_lengkap, nik FROM warga ORDER BY nama_lengkap ASC")->fetchAll();
 $riwayat_iuran = $pdo->query("SELECT pi.*, w.nama_lengkap, w.nik FROM pembayaran_iuran pi JOIN warga w ON pi.id_warga=w.id_warga ORDER BY pi.tanggal_bayar DESC LIMIT 10")->fetchAll();

// Filter untuk Mass Payment
 $filter_bulan = isset($_GET['bulan_massal']) ? intval($_GET['bulan_massal']) : date('n');
 $filter_tahun = isset($_GET['tahun_massal']) ? intval($_GET['tahun_massal']) : date('Y');

 $stmt_massal = $pdo->prepare("SELECT w.id_warga, w.nama_lengkap, w.nik, pi.status_bayar FROM warga w LEFT JOIN pembayaran_iuran pi ON w.id_warga = pi.id_warga AND pi.bulan = ? AND pi.tahun = ? ORDER BY w.nama_lengkap ASC");
 $stmt_massal->execute([$filter_bulan, $filter_tahun]);
 $massal_list = $stmt_massal->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<style>
    .gradient-green { background: linear-gradient(135deg, #198754 0%, #157347 100%); }
    .card-modern { border: none; border-radius: 15px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); }
    .form-control:focus, .form-select:focus { border-color: #198754; box-shadow: 0 0 0 0.2rem rgba(25, 135, 84, 0.15); }
</style>

<div class="container-fluid">
    <h3 class="mt-4 mb-4"><i class="bi bi-wallet2 me-2 text-success"></i>Manajemen Iuran Warga</h3>

    <?php if(isset($_GET['msg'])): ?>
        <div class="alert alert-success alert-dismissible fade show rounded-3 border-0 shadow-sm" role="alert">
            <i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($_GET['msg']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-lg-5 mb-4">
            
            <!-- Card Pengaturan & Generate Tagihan -->
            <div class="card card-modern mb-4 border-start border-4 border-success">
                <div class="card-body p-4">
                    <h5 class="fw-bold text-success mb-3"><i class="bi bi-gear-fill me-2"></i>Pengaturan & Generate Tagihan</h5>
                    <form method="POST">
                        <label class="form-label fw-semibold small">Nominal Iuran Per Bulan (Rp)</label>
                        <div class="input-group mb-3">
                            <span class="input-group-text bg-light fw-bold">Rp</span>
                            <input type="number" name="nominal_iuran" class="form-control fw-bold" value="<?= $set_iuran ?>" required>
                        </div>
                        <div class="row mb-3">
                            <div class="col-6">
                                <label class="form-label fw-semibold small">Bulan</label>
                                <select name="bulan" class="form-select" required>
                                    <?php for($i=1; $i<=12; $i++): ?>
                                    <option value="<?= $i ?>" <?= ($i == date('n')) ? 'selected' : '' ?>><?= $nama_bulan[($i - 1)] ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="col-6">
                                <label class="form-label fw-semibold small">Tahun</label>
                                <input type="number" name="tahun" class="form-control" value="<?= date('Y') ?>" required>
                            </div>
                        </div>
                        <button type="submit" name="generate_tagihan" class="btn btn-primary w-100 shadow-sm fw-bold">
                            <i class="bi bi-broadcast-pin me-1"></i> Generate Tagihan ke Semua Warga
                        </button>
                        <button type="submit" name="update_nominal" class="btn btn-outline-success w-100 mt-2 fw-bold">
                            <i class="bi bi-save me-1"></i> Simpan Perubahan Nominal
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Input Pembayaran Massal -->
        <div class="col-lg-7 mb-4">
            <div class="card card-modern h-100">
                <div class="card-header bg-white border-0 pt-4 pb-0 px-4">
                    <h5 class="fw-bold text-dark mb-0"><i class="bi bi-check2-square me-2"></i>Input Pembayaran Massal</h5>
                    <small class="text-muted">Pilih bulan/tahun, ceklis warga yang bayar, lalu simpan.</small>
                </div>
                <div class="card-body px-4 pb-4">
                    <form method="GET" class="row g-2 mb-3 align-items-end">
                        <div class="col-5">
                            <select name="bulan_massal" class="form-select form-select-sm">
                                <?php for($i=1; $i<=12; $i++): ?>
                                <option value="<?= $i ?>" <?= ($i == $filter_bulan) ? 'selected' : '' ?>><?= $nama_bulan[($i - 1)] ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="col-4">
                            <input type="number" name="tahun_massal" class="form-control form-control-sm" value="<?= $filter_tahun ?>">
                        </div>
                        <div class="col-3">
                            <button type="submit" class="btn btn-sm btn-primary w-100"><i class="bi bi-search me-1"></i> Tampil</button>
                        </div>
                    </form>

                    <form method="POST">
                        <input type="hidden" name="bulan" value="<?= $filter_bulan ?>">
                        <input type="hidden" name="tahun" value="<?= $filter_tahun ?>">
                        <select name="metode_bayar" class="form-select form-select-sm mb-3" required>
                            <option value="Tunai">💵 Tunai</option>
                            <option value="Transfer Bank">🏦 Transfer Bank</option>
                            <option value="QRIS">📱 QRIS</option>
                        </select>

                        <div class="table-responsive" style="max-height: 300px; overflow-y: auto;">
                            <table class="table table-sm table-hover mb-0">
                                <thead class="table-light sticky-top">
                                    <tr>
                                        <th width="50"><input type="checkbox" id="checkAll"></th>
                                        <th>Nama Warga</th>
                                        <th>Status Saat Ini</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($massal_list as $m): ?>
                                    <tr>
                                        <td>
                                            <?php if($m['status_bayar'] !== 'lunas'): ?>
                                            <input type="checkbox" name="warga_bayar[]" value="<?= $m['id_warga'] ?>" class="check-item">
                                            <?php endif; ?>
                                        </td>
                                        <td class="fw-bold small"><?= htmlspecialchars($m['nama_lengkap']) ?></td>
                                        <td>
                                            <?php if($m['status_bayar']=='lunas'): ?>
                                                <span class="badge bg-success py-1 px-2">LUNAS</span>
                                            <?php elseif($m['status_bayar']=='pending'): ?>
                                                <span class="badge bg-warning text-dark py-1 px-2">PENDING</span>
                                            <?php elseif($m['status_bayar']=='belum_bayar'): ?>
                                                <span class="badge bg-danger py-1 px-2">BELUM BAYAR</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary py-1 px-2">BELUM DITAGIH</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <button type="submit" name="input_bayar_massal" class="btn btn-success w-100 mt-3 fw-bold shadow-sm">
                            <i class="bi bi-check-circle me-1"></i> Simpan Pembayaran Warga Terpilih
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Riwayat Iuran Terbaru -->
    <div class="row mt-2">
        <div class="col-lg-7 mb-4">
            <div class="card card-modern">
                <div class="card-header bg-white border-0 pt-4 pb-0 px-4">
                    <h5 class="fw-bold text-dark mb-0">Riwayat Pembayaran Terbaru</h5>
                </div>
                <div class="card-body px-4 pb-4">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr><th>Warga</th><th>Periode</th><th>Status</th><th>Metode</th><th>Jumlah</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach($riwayat_iuran as $ri): ?>
                                <tr>
                                    <td class="fw-bold"><?= htmlspecialchars($ri['nama_lengkap']) ?></td>
                                    <td><?= $nama_bulan[($ri['bulan'] - 1)] . " " . $ri['tahun'] ?></td>
                                    <td>
                                        <?php if($ri['status_bayar'] == 'lunas'): ?><span class="badge bg-success">LUNAS</span>
                                        <?php elseif($ri['status_bayar'] == 'pending'): ?><span class="badge bg-warning text-dark">PENDING</span>
                                        <?php else: ?><span class="badge bg-danger">BELUM BAYAR</span><?php endif; ?>
                                    </td>
                                    <td><span class="badge bg-light text-dark border"><?= $ri['metode_bayar'] ?? '-' ?></span></td>
                                    <td class="fw-bold text-success">Rp <?= number_format($ri['jumlah_bayar'], 0, ',', '.') ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Kartu Pembayaran Pending (Verifikasi Digital) -->
        <?php
        $pending_iuran = $pdo->query("SELECT pi.*, w.nama_lengkap FROM pembayaran_iuran pi JOIN warga w ON pi.id_warga=w.id_warga WHERE pi.status_bayar='pending' ORDER BY pi.tanggal_bayar DESC")->fetchAll();
        ?>
        <?php if(count($pending_iuran) > 0): ?>
        <div class="col-lg-5 mb-4">
            <div class="card card-modern border-start border-4 border-warning shadow-sm">
                <div class="card-header bg-white border-0 pt-4 pb-0 px-4">
                    <h5 class="fw-bold text-warning mb-0"><i class="bi bi-hourglass-bottom me-2"></i>Konfirmasi Pending</h5>
                </div>
                <div class="card-body p-4">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light"><tr><th>Warga</th><th>Periode</th><th>Aksi</th></tr></thead>
                            <tbody>
                                <?php foreach($pending_iuran as $pi): ?>
                                <tr>
                                    <form method="POST">
                                        <input type="hidden" name="id_iuran" value="<?= $pi['id_iuran'] ?>">
                                        <td class="fw-bold small"><?= htmlspecialchars($pi['nama_lengkap']) ?></td>
                                        <td class="small"><?= $nama_bulan[($pi['bulan'] - 1)] . " " . $pi['tahun'] ?></td>
                                        <td><button type="submit" name="verifikasi_iuran" class="btn btn-success btn-sm fw-bold"><i class="bi bi-check-lg"></i></button></td>
                                    </form>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
// Script Check All Checkbox
document.getElementById('checkAll').addEventListener('change', function(e) {
    document.querySelectorAll('.check-item').forEach(cb => cb.checked = e.target.checked);
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>