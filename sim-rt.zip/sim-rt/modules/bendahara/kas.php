<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('bendahara');
require_once __DIR__ . '/../../config/database.php';

// ==========================================
// LOGIC: Tambah Transaksi Kas Umum
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah_kas'])) {
    $stmt = $pdo->prepare("INSERT INTO transaksi_kas (jenis, kategori, keterangan, jumlah, metode_bayar, tanggal, dicatat_oleh) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$_POST['jenis'], $_POST['kategori'], $_POST['keterangan'], $_POST['jumlah'], $_POST['metode_bayar'], $_POST['tanggal'], $_SESSION['id_user']]);
    header("Location: kas.php?msg=Kas berhasil dicatat");
    exit;
}

// ==========================================
// QUERY: Statistik Keuangan
// ==========================================
 $kas_masuk = $pdo->query("SELECT SUM(jumlah) FROM transaksi_kas WHERE jenis='masuk'")->fetchColumn() ?? 0;
 $kas_keluar = $pdo->query("SELECT SUM(jumlah) FROM transaksi_kas WHERE jenis='keluar'")->fetchColumn() ?? 0;
 $saldo = $kas_masuk - $kas_keluar;

// Transaksi Terakhir
 $last_transaksi = $pdo->query("SELECT t.*, u.username FROM transaksi_kas t JOIN users u ON t.dicatat_oleh=u.id_user ORDER BY t.tanggal DESC, t.id_kas DESC LIMIT 7")->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<style>
    .gradient-green { background: linear-gradient(135deg, #198754 0%, #157347 100%); }
    .gradient-red { background: linear-gradient(135deg, #dc3545 0%, #bb2d3b 100%); }
    .gradient-blue { background: linear-gradient(135deg, #0d6efd 0%, #0b5ed7 100%); }
    .gradient-teal { background: linear-gradient(135deg, #20c9a0 0%, #1a9ea8 100%); }
    .card-modern { border: none; border-radius: 15px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); }
    .card-stat { border: none; border-radius: 15px; color: white; }
    .form-control:focus, .form-select:focus { border-color: #198754; box-shadow: 0 0 0 0.2rem rgba(25, 135, 84, 0.15); }
</style>

<div class="container-fluid">
    <h3 class="mt-4 mb-4"><i class="bi bi-cash-stack me-2 text-success"></i>Dashboard Keuangan Kas RT</h3>

    <?php if(isset($_GET['msg'])): ?>
        <div class="alert alert-success alert-dismissible fade show rounded-3 border-0 shadow-sm" role="alert">
            <i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($_GET['msg']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Statistik Cards -->
    <div class="row mb-4">
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="card card-stat gradient-green shadow text-center py-3">
                <i class="bi bi-arrow-down-circle-fill" style="font-size: 2rem; opacity: 0.8;"></i>
                <h2 class="mt-2 mb-0 fw-bold">Rp <?= number_format($kas_masuk, 0, ',', '.') ?></h2>
                <span>Total Pemasukan</span>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="card card-stat gradient-red shadow text-center py-3">
                <i class="bi bi-arrow-up-circle-fill" style="font-size: 2rem; opacity: 0.8;"></i>
                <h2 class="mt-2 mb-0 fw-bold">Rp <?= number_format($kas_keluar, 0, ',', '.') ?></h2>
                <span>Total Pengeluaran</span>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="card card-stat gradient-blue shadow text-center py-3">
                <i class="bi bi-wallet2" style="font-size: 2rem; opacity: 0.8;"></i>
                <h2 class="mt-2 mb-0 fw-bold">Rp <?= number_format($saldo, 0, ',', '.') ?></h2>
                <span>Saldo Kas Saat Ini</span>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="card card-stat gradient-teal shadow text-center py-3">
                <i class="bi bi-people-fill" style="font-size: 2rem; opacity: 0.8;"></i>
                <h2 class="mt-2 mb-0 fw-bold">
                    <?php 
                        $bln = date('n'); $thn = date('Y');
                        echo $pdo->query("SELECT COUNT(*) FROM pembayaran_iuran WHERE bulan=$bln AND tahun=$thn")->fetchColumn();
                    ?>
                </h2>
                <span>Warga Bayar Bulan Ini</span>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Form Input Kas Umum -->
        <div class="col-lg-5 mb-4">
            <div class="card card-modern">
                <div class="card-header bg-white border-0 pt-4 pb-0 px-4">
                    <h5 class="fw-bold text-success mb-0">Input Transaksi Kas</h5>
                    <small class="text-muted">Pemasukan/Pengeluaran Umum (Sumbangan, Kegiatan, dll)</small>
                </div>
                <div class="card-body px-4 pb-4">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-semibold small">Jenis Transaksi</label>
                            <select name="jenis" class="form-select" id="jenisKas" required>
                                <option value="masuk">Pemasukan</option>
                                <option value="keluar">Pengeluaran</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold small">Kategori</label>
                            <input type="text" name="kategori" class="form-control" placeholder="Contoh: Sumbangan, Perbaikan Jalan" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold small">Jumlah (Rp)</label>
                            <input type="number" name="jumlah" class="form-control" placeholder="100000" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold small">Metode Pembayaran</label>
                            <select name="metode_bayar" class="form-select">
                                <option value="Tunai">💵 Tunai</option>
                                <option value="Transfer Bank">🏦 Transfer Bank</option>
                                <option value="QRIS">📱 QRIS</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold small">Tanggal</label>
                            <input type="date" name="tanggal" class="form-control" value="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold small">Keterangan</label>
                            <textarea name="keterangan" class="form-control" rows="2" required></textarea>
                        </div>
                        <button type="submit" name="tambah_kas" class="btn btn-success w-100 shadow-sm fw-bold">
                            <i class="bi bi-plus-circle me-1"></i> Simpan Transaksi
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Riwayat Transaksi Terakhir -->
        <div class="col-lg-7 mb-4">
            <div class="card card-modern h-100">
                <div class="card-header bg-white border-0 pt-4 pb-0 px-4 d-flex justify-content-between">
                    <h5 class="fw-bold text-dark mb-0">Transaksi Terakhir</h5>
                    <a href="laporan.php" class="btn btn-sm btn-outline-success">Lihat Semua Laporan</a>
                </div>
                <div class="card-body px-4 pb-4">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Tanggal</th>
                                    <th>Kategori</th>
                                    <th>Metode</th>
                                    <th>Jumlah</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($last_transaksi as $t): ?>
                                <tr>
                                    <td class="small"><?= date('d M Y', strtotime($t['tanggal'])) ?></td>
                                    <td>
                                        <?= htmlspecialchars($t['kategori']) ?>
                                        <br><small class="text-muted"><?= htmlspecialchars($t['keterangan']) ?></small>
                                    </td>
                                    <td><span class="badge bg-light text-dark border"><?= $t['metode_bayar'] ?></span></td>
                                    <td class="fw-bold <?= $t['jenis'] == 'masuk' ? 'text-success' : 'text-danger' ?>">
                                        <?= $t['jenis'] == 'masuk' ? '+' : '-' ?> Rp <?= number_format($t['jumlah'], 0, ',', '.') ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>