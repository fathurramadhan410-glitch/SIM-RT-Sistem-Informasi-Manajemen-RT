<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('bendahara');
require_once __DIR__ . '/../../config/database.php';

 $nama_bulan_arr = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];

// ==========================================
// LOGIC: Export ke Excel
// ==========================================
if (isset($_GET['export'])) {
    $bln = $_GET['bulan'] ?? date('m');
    $thn = $_GET['tahun'] ?? date('Y');

    $stmt = $pdo->prepare("SELECT t.tanggal, t.jenis, t.kategori, t.keterangan, t.jumlah, t.metode_bayar, u.username FROM transaksi_kas t JOIN users u ON t.dicatat_oleh=u.id_user WHERE MONTH(t.tanggal)=? AND YEAR(t.tanggal)=? ORDER BY t.tanggal ASC");
    $stmt->execute([$bln, $thn]);
    $data_export = $stmt->fetchAll();

    $nama_bln_export = $nama_bulan_arr[($bln - 1)]; // Perbaikan: gunakan variabel dulu

    // Set header for Excel Download
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=Laporan_Kas_RT_$nama_bln_export_$thn.xls");
    
    echo "<h4>Laporan Kas RT - $nama_bln_export $thn</h4>";
    echo "<table border='1'>
            <tr style='background-color: #f2f2f2;'>
                <th>No</th><th>Tanggal</th><th>Jenis</th><th>Kategori</th><th>Keterangan</th><th>Metode</th><th>Jumlah (Rp)</th>
            </tr>";
    $no = 1;
    foreach ($data_export as $row) {
        echo "<tr>
                <td>".$no++."</td>
                <td>".date('d-m-Y', strtotime($row['tanggal']))."</td>
                <td>".ucfirst($row['jenis'])."</td>
                <td>".$row['kategori']."</td>
                <td>".$row['keterangan']."</td>
                <td>".$row['metode_bayar']."</td>
                <td>".number_format($row['jumlah'], 0, ',', '.')."</td>
              </tr>";
    }
    echo "</table>";
    exit;
}

// ==========================================
// LOGIC: Tampil Normal & Filter
// ==========================================
 $bulan_filter = $_GET['bulan'] ?? date('m');
 $tahun_filter = $_GET['tahun'] ?? date('Y');

 $stmt = $pdo->prepare("SELECT t.*, u.username FROM transaksi_kas t JOIN users u ON t.dicatat_oleh=u.id_user WHERE MONTH(t.tanggal)=? AND YEAR(t.tanggal)=? ORDER BY t.tanggal ASC");
 $stmt->execute([$bulan_filter, $tahun_filter]);
 $laporan = $stmt->fetchAll();

// Hitung total filter
 $total_masuk_filter = 0; $total_keluar_filter = 0;
foreach($laporan as $l) {
    if($l['jenis'] == 'masuk') $total_masuk_filter += $l['jumlah'];
    else $total_keluar_filter += $l['jumlah'];
}
 $saldo_filter = $total_masuk_filter - $total_keluar_filter;

require_once __DIR__ . '/../../includes/header.php';
?>

<style>
    .card-modern { border: none; border-radius: 15px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); }
    @media print {
        .no-print { display: none !important; }
        .card-modern { box-shadow: none; border: 1px solid #000; }
    }
</style>

<div class="container-fluid">
    <h3 class="mt-4 mb-4 no-print"><i class="bi bi-file-earmark-bar-graph me-2 text-success"></i>Laporan Keuangan & Export</h3>

    <!-- Filter & Export Buttons -->
    <div class="card card-modern mb-4 no-print">
        <div class="card-body py-3">
            <form method="GET" class="row g-3 align-items-end">
                <div class="col-md-3">
                    <label class="form-label fw-semibold small">Bulan</label>
                    <select name="bulan" class="form-select">
                        <?php for($i=1; $i<=12; $i++): ?>
                        <option value="<?= $i ?>" <?= $bulan_filter == $i ? 'selected' : '' ?>><?= $nama_bulan_arr[($i - 1)] ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-semibold small">Tahun</label>
                    <input type="number" name="tahun" class="form-control" value="<?= $tahun_filter ?>">
                </div>
                <div class="col-md-6 d-flex gap-2">
                    <button type="submit" class="btn btn-primary shadow-sm flex-grow-1"><i class="bi bi-search me-1"></i> Tampilkan</button>
                    <a href="?export=1&bulan=<?= $bulan_filter ?>&tahun=<?= $tahun_filter ?>" class="btn btn-success shadow-sm flex-grow-1"><i class="bi bi-file-earmark-excel me-1"></i> Export Excel</a>
                    <button type="button" onclick="window.print()" class="btn btn-danger shadow-sm flex-grow-1"><i class="bi bi-file-earmark-pdf me-1"></i> Cetak PDF</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Ringkasan Periode Ini -->
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card bg-success text-white shadow-sm border-0 rounded-3 py-3 text-center">
                <h5 class="mb-0">Pemasukan</h5>
                <h3 class="fw-bold mb-0">Rp <?= number_format($total_masuk_filter, 0, ',', '.') ?></h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-danger text-white shadow-sm border-0 rounded-3 py-3 text-center">
                <h5 class="mb-0">Pengeluaran</h5>
                <h3 class="fw-bold mb-0">Rp <?= number_format($total_keluar_filter, 0, ',', '.') ?></h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-dark text-white shadow-sm border-0 rounded-3 py-3 text-center">
                <h5 class="mb-0">Saldo Periode Ini</h5>
                <h3 class="fw-bold mb-0">Rp <?= number_format($saldo_filter, 0, ',', '.') ?></h3>
            </div>
        </div>
    </div>

    <!-- Tabel Laporan -->
    <div class="card card-modern shadow-sm border-0 rounded-3">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>Kategori</th>
                            <th>Keterangan</th>
                            <th>Metode</th>
                            <th>Pemasukan</th>
                            <th>Pengeluaran</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($laporan) > 0): $no=1; ?>
                            <?php foreach($laporan as $l): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td class="small"><?= date('d M Y', strtotime($l['tanggal'])) ?></td>
                                <td class="fw-bold"><?= htmlspecialchars($l['kategori']) ?></td>
                                <td class="small text-muted"><?= htmlspecialchars($l['keterangan']) ?></td>
                                <td><span class="badge bg-light text-dark border"><?= $l['metode_bayar'] ?></span></td>
                                <td class="fw-bold text-success"><?= $l['jenis'] == 'masuk' ? 'Rp '.number_format($l['jumlah'], 0, ',', '.') : '-' ?></td>
                                <td class="fw-bold text-danger"><?= $l['jenis'] == 'keluar' ? 'Rp '.number_format($l['jumlah'], 0, ',', '.') : '-' ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="7" class="text-center py-4 text-muted">Tidak ada transaksi pada periode ini.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>