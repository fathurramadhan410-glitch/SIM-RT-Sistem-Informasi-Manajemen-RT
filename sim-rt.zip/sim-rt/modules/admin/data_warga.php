<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('admin');
require_once __DIR__ . '/../../config/database.php';

// Daftar Opsi untuk Dropdown
 $ekonomi_options = ['Mampu', 'Kurang Mampu', 'Sangat Kurang Mampu'];
 $bansos_options = [
    'PKH (Program Keluarga Harapan)',
    'BPNT (Bantuan Pangan Non-Tunai)',
    'ATENSI (Asistensi Rehabilitasi Sosial)',
    'PBI-JK (Penerima Bantuan Iuran Jaminan Kesehatan)',
    'YAPI (Yatim Piatu)',
    'PKH Anak Sekolah (PKH Komponen Pendidikan)',
    'SR (Sekolah Rakyat)',
    'PIP (Program Indonesia Pintar)',
    'KIP (Kartu Indonesia Pintar)',
    'Lainnya'
];

// ==========================================
// LOGIC: PROSES CRUD DATA WARGA
// ==========================================

// 1. TAMBAH WARGA BARU
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah_warga'])) {
    $nik = trim($_POST['nik']);
    
    // Cek duplikat NIK
    $cek_nik = $pdo->prepare("SELECT id_warga FROM warga WHERE nik=?");
    $cek_nik->execute([$nik]);
    if ($cek_nik->fetch()) {
        header("Location: data_warga.php?msg=NIK sudah terdaftar di database!");
        exit;
    }

    $stmt = $pdo->prepare("INSERT INTO warga (nik, no_kk, nama_lengkap, jenis_kelamin, tempat_lahir, tanggal_lahir, alamat, rt, rw, agama, status_kawin, pekerjaan, pendidikan_terakhir, status_hubungan_kk, no_hp) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $nik, $_POST['no_kk'], $_POST['nama_lengkap'], $_POST['jenis_kelamin'], 
        $_POST['tempat_lahir'], $_POST['tanggal_lahir'], $_POST['alamat'], 
        $_POST['rt'], $_POST['rw'], $_POST['agama'], $_POST['status_kawin'], 
        $_POST['pekerjaan'], $_POST['pendidikan_terakhir'], $_POST['status_hubungan_kk'], $_POST['no_hp']
    ]);

    // Otomatis buatkan profil sosial beserta status ekonomi & bansos
    $id_warga_baru = $pdo->lastInsertId();
    $status_ekonomi_baru = $_POST['status_ekonomi'] ?? 'Mampu';
    $penerima_bansos_baru = $_POST['penerima_bansos'] ?? '0';
    $jenis_bansos_baru = $penerima_bansos_baru == '1' ? $_POST['jenis_bansos'] : null;

    $pdo->prepare("INSERT INTO profil_sosial_warga (id_warga, status_ekonomi, penerima_bansos, jenis_bansos) VALUES (?, ?, ?, ?)")
        ->execute([$id_warga_baru, $status_ekonomi_baru, $penerima_bansos_baru, $jenis_bansos_baru]);

    header("Location: data_warga.php?msg=Data warga berhasil ditambahkan!");
    exit;
}

// 2. EDIT WARGA
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_warga'])) {
    $stmt = $pdo->prepare("UPDATE warga SET nik=?, no_kk=?, nama_lengkap=?, jenis_kelamin=?, tempat_lahir=?, tanggal_lahir=?, alamat=?, rt=?, rw=?, agama=?, status_kawin=?, pekerjaan=?, pendidikan_terakhir=?, status_hubungan_kk=?, no_hp=? WHERE id_warga=?");
    $stmt->execute([
        $_POST['nik'], $_POST['no_kk'], $_POST['nama_lengkap'], $_POST['jenis_kelamin'], 
        $_POST['tempat_lahir'], $_POST['tanggal_lahir'], $_POST['alamat'], 
        $_POST['rt'], $_POST['rw'], $_POST['agama'], $_POST['status_kawin'], 
        $_POST['pekerjaan'], $_POST['pendidikan_terakhir'], $_POST['status_hubungan_kk'], $_POST['no_hp'], 
        $_POST['id_warga']
    ]);

    // Update profil sosial warga (status ekonomi & bansos)
    $status_ekonomi_edit = $_POST['status_ekonomi'] ?? 'Mampu';
    $penerima_bansos_edit = $_POST['penerima_bansos'] ?? '0';
    $jenis_bansos_edit = $penerima_bansos_edit == '1' ? $_POST['jenis_bansos'] : null;

    $stmt_ps = $pdo->prepare("UPDATE profil_sosial_warga SET status_ekonomi=?, penerima_bansos=?, jenis_bansos=? WHERE id_warga=?");
    $stmt_ps->execute([$status_ekonomi_edit, $penerima_bansos_edit, $jenis_bansos_edit, $_POST['id_warga']]);

    header("Location: data_warga.php?msg=Data warga berhasil diperbarui!");
    exit;
}

// 3. HAPUS WARGA
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['hapus_warga'])) {
    $stmt = $pdo->prepare("DELETE FROM warga WHERE id_warga=?");
    $stmt->execute([$_POST['id_warga']]);
    header("Location: data_warga.php?msg=Data warga beserta riwayat terkait telah dihapus!");
    exit;
}

// ==========================================
// QUERY: AMBIL DATA WARGA & PENCARIAN (HANYA KEPALA KELUARGA + JOIN PROFIL SOSIAL)
// ==========================================
 $search = $_GET['search'] ?? '';
 $query_str = "SELECT w.*, ps.status_ekonomi, ps.penerima_bansos, ps.jenis_bansos 
              FROM warga w 
              LEFT JOIN profil_sosial_warga ps ON w.id_warga = ps.id_warga 
              WHERE w.status_hubungan_kk = 'Kepala Keluarga'";

if (!empty($search)) {
    $stmt = $pdo->prepare($query_str . " AND (w.nama_lengkap LIKE ? OR w.nik LIKE ? OR w.no_kk LIKE ?) ORDER BY w.nama_lengkap ASC");
    $stmt->execute(["%$search%", "%$search%", "%$search%"]);
} else {
    $stmt = $pdo->query($query_str . " ORDER BY w.nama_lengkap ASC");
}
 $warga_list = $stmt->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<style>
    .card-modern { border: none; border-radius: 15px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); }
    .badge-l { background: #0d6efd; color: white; }
    .badge-p { background: #d63384; color: white; }
    .form-control:focus, .form-select:focus { border-color: #dc3545; box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.15); }
</style>

<div class="container-fluid">
    <h3 class="mt-4 mb-4"><i class="bi bi-people-fill me-2 text-danger"></i>Manajemen Data Warga</h3>

    <?php if(isset($_GET['msg'])): ?>
        <div class="alert alert-success alert-dismissible fade show rounded-3 border-0 shadow-sm" role="alert">
            <i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($_GET['msg']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="d-flex justify-content-between align-items-center mb-3">
        <form method="GET" class="d-flex" style="width: 300px;">
            <input type="text" name="search" class="form-control rounded-pill me-2" placeholder="Cari Nama / NIK / No KK..." value="<?= htmlspecialchars($search) ?>">
            <button type="submit" class="btn btn-outline-danger rounded-pill"><i class="bi bi-search"></i></button>
        </form>
        <button class="btn btn-danger shadow-sm rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#modalTambah">
            <i class="bi bi-person-plus-fill me-1"></i> Tambah Warga
        </button>
    </div>

    <div class="card card-modern shadow-sm border-0 rounded-3">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>No</th>
                            <th>No. KK</th>
                            <th>Nama Kepala Keluarga</th>
                            <th>NIK</th>
                            <th>RT / RW</th>
                            <th>Status Ekonomi</th>
                            <th>No. HP</th>
                            <th width="20%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($warga_list) > 0): $no=1; ?>
                            <?php foreach($warga_list as $w): 
                                // Logika warna badge status ekonomi
                                $status_ek = $w['status_ekonomi'] ?? 'Mampu';
                                $badge_color = 'bg-success'; // Default Mampu (Hijau)
                                if ($status_ek == 'Kurang Mampu') $badge_color = 'bg-warning text-dark'; // Kuning
                                if ($status_ek == 'Sangat Kurang Mampu') $badge_color = 'bg-danger'; // Merah
                            ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><span class="badge bg-secondary fs-6"><?= htmlspecialchars($w['no_kk']) ?></span></td>
                                <td class="fw-bold"><?= htmlspecialchars($w['nama_lengkap']) ?></td>
                                <td><?= $w['nik'] ?></td>
                                <td><?= $w['rt'] ?> / <?= $w['rw'] ?></td>
                                <td>
                                    <span class="badge <?= $badge_color ?> fs-6"><?= htmlspecialchars($status_ek) ?></span>
                                </td>
                                <td><?= $w['no_hp'] ?? '-' ?></td>
                                <td>
                                    <!-- Tombol Lihat Anggota Keluarga -->
                                    <a href="detail_keluarga.php?no_kk=<?= urlencode($w['no_kk']) ?>" class="btn btn-sm btn-info text-white" title="Lihat Anggota KK">
                                        <i class="bi bi-people-fill"></i> Lihat KK
                                    </a>
                                    <button class="btn btn-sm btn-outline-warning" data-bs-toggle="modal" data-bs-target="#modalEdit<?= $w['id_warga'] ?>"><i class="bi bi-pencil"></i></button>
                                    <button class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#modalHapus<?= $w['id_warga'] ?>"><i class="bi bi-trash"></i></button>
                                </td>
                            </tr>

                            <!-- Modal Edit -->
                            <div class="modal fade" id="modalEdit<?= $w['id_warga'] ?>" tabindex="-1">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <form method="POST">
                                            <input type="hidden" name="id_warga" value="<?= $w['id_warga'] ?>">
                                            <div class="modal-header bg-warning text-white">
                                                <h5 class="modal-title">Edit Data: <?= htmlspecialchars($w['nama_lengkap']) ?></h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-6 mb-3">
                                                        <label class="form-label fw-semibold small">NIK (16 Digit)</label>
                                                        <input type="text" name="nik" class="form-control" maxlength="16" value="<?= htmlspecialchars($w['nik']) ?>" required>
                                                    </div>
                                                    <div class="col-md-6 mb-3">
                                                        <label class="form-label fw-semibold small">No. KK (16 Digit)</label>
                                                        <input type="text" name="no_kk" class="form-control" maxlength="16" value="<?= htmlspecialchars($w['no_kk']) ?>" required>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-8 mb-3">
                                                        <label class="form-label fw-semibold small">Nama Lengkap</label>
                                                        <input type="text" name="nama_lengkap" class="form-control" value="<?= htmlspecialchars($w['nama_lengkap']) ?>" required>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label class="form-label fw-semibold small">Jenis Kelamin</label>
                                                        <select name="jenis_kelamin" class="form-select" required>
                                                            <option value="L" <?= $w['jenis_kelamin'] == 'L' ? 'selected' : '' ?>>Laki-laki</option>
                                                            <option value="P" <?= $w['jenis_kelamin'] == 'P' ? 'selected' : '' ?>>Perempuan</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-5 mb-3">
                                                        <label class="form-label fw-semibold small">Tempat Lahir</label>
                                                        <input type="text" name="tempat_lahir" class="form-control" value="<?= htmlspecialchars($w['tempat_lahir'] ?? '') ?>">
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label class="form-label fw-semibold small">Tanggal Lahir</label>
                                                        <input type="date" name="tanggal_lahir" class="form-control" value="<?= $w['tanggal_lahir'] ?>" required>
                                                    </div>
                                                    <div class="col-md-3 mb-3">
                                                        <label class="form-label fw-semibold small">Agama</label>
                                                        <select name="agama" class="form-select">
                                                            <?php $agama_list = ['Islam','Kristen','Katolik','Hindu','Buddha','Konghucu']; ?>
                                                            <?php foreach($agama_list as $a): ?>
                                                            <option value="<?= $a ?>" <?= ($w['agama'] ?? '') == $a ? 'selected' : '' ?>><?= $a ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label fw-semibold small">Alamat Lengkap</label>
                                                    <textarea name="alamat" class="form-control" rows="2" required><?= htmlspecialchars($w['alamat']) ?></textarea>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-3 mb-3">
                                                        <label class="form-label fw-semibold small">RT</label>
                                                        <input type="text" name="rt" class="form-control" value="<?= htmlspecialchars($w['rt']) ?>" required>
                                                    </div>
                                                    <div class="col-md-3 mb-3">
                                                        <label class="form-label fw-semibold small">RW</label>
                                                        <input type="text" name="rw" class="form-control" value="<?= htmlspecialchars($w['rw']) ?>" required>
                                                    </div>
                                                    <div class="col-md-3 mb-3">
                                                        <label class="form-label fw-semibold small">Status Perkawinan</label>
                                                        <select name="status_kawin" class="form-select">
                                                            <option value="Belum Kawin" <?= $w['status_kawin'] == 'Belum Kawin' ? 'selected' : '' ?>>Belum Kawin</option>
                                                            <option value="Kawin" <?= $w['status_kawin'] == 'Kawin' ? 'selected' : '' ?>>Kawin</option>
                                                            <option value="Cerai Hidup" <?= $w['status_kawin'] == 'Cerai Hidup' ? 'selected' : '' ?>>Cerai Hidup</option>
                                                            <option value="Cerai Mati" <?= $w['status_kawin'] == 'Cerai Mati' ? 'selected' : '' ?>>Cerai Mati</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-3 mb-3">
                                                        <label class="form-label fw-semibold small">Hub. Dalam KK</label>
                                                        <select name="status_hubungan_kk" class="form-select">
                                                            <option value="Kepala Keluarga" <?= $w['status_hubungan_kk'] == 'Kepala Keluarga' ? 'selected' : '' ?>>Kepala Keluarga</option>
                                                            <option value="Istri" <?= $w['status_hubungan_kk'] == 'Istri' ? 'selected' : '' ?>>Istri</option>
                                                            <option value="Anak" <?= $w['status_hubungan_kk'] == 'Anak' ? 'selected' : '' ?>>Anak</option>
                                                            <option value="Lainnya" <?= $w['status_hubungan_kk'] == 'Lainnya' ? 'selected' : '' ?>>Lainnya</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-4 mb-3">
                                                        <label class="form-label fw-semibold small">Pekerjaan</label>
                                                        <input type="text" name="pekerjaan" class="form-control" value="<?= htmlspecialchars($w['pekerjaan'] ?? '') ?>">
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label class="form-label fw-semibold small">Pendidikan Terakhir</label>
                                                        <select name="pendidikan_terakhir" class="form-select">
                                                            <?php $pend_list = ['Tidak Sekolah','SD','SMP','SMA','D1-D3','S1','S2','S3']; ?>
                                                            <?php foreach($pend_list as $p): ?>
                                                            <option value="<?= $p ?>" <?= ($w['pendidikan_terakhir'] ?? '') == $p ? 'selected' : '' ?>><?= $p ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label class="form-label fw-semibold small">No. HP</label>
                                                        <input type="text" name="no_hp" class="form-control" value="<?= htmlspecialchars($w['no_hp'] ?? '') ?>">
                                                    </div>
                                                </div>

                                                <hr class="my-4">
                                                <h6 class="fw-bold text-danger mb-3"><i class="bi bi-shield-plus me-2"></i>Data Sosial (Kepala Keluarga)</h6>
                                                
                                                <div class="row">
                                                    <div class="col-md-6 mb-3">
                                                        <label class="form-label fw-semibold small">Status Ekonomi</label>
                                                        <select name="status_ekonomi" class="form-select">
                                                            <?php foreach($ekonomi_options as $e): ?>
                                                            <option value="<?= $e ?>" <?= ($w['status_ekonomi'] ?? 'Mampu') == $e ? 'selected' : '' ?>><?= $e ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-6 mb-3">
                                                        <label class="form-label fw-semibold small">Penerima Bansos</label>
                                                        <select name="penerima_bansos" id="penerima_bansos_<?= $w['id_warga'] ?>" class="form-select" onchange="toggleBansosField(<?= $w['id_warga'] ?>)">
                                                            <option value="0" <?= ($w['penerima_bansos'] ?? 0) == 0 ? 'selected' : '' ?>>Tidak</option>
                                                            <option value="1" <?= ($w['penerima_bansos'] ?? 0) == 1 ? 'selected' : '' ?>>Ya</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="mb-3" id="jenis_bansos_wrap_<?= $w['id_warga'] ?>" style="display: <?= ($w['penerima_bansos'] ?? 0) == 1 ? 'block' : 'none' ?>;">
                                                    <label class="form-label fw-semibold small">Jenis Bansos</label>
                                                    <select name="jenis_bansos" class="form-select">
                                                        <option value="">-- Pilih Jenis Bansos --</option>
                                                        <?php foreach($bansos_options as $b): ?>
                                                            <option value="<?= $b ?>" <?= ($w['jenis_bansos'] ?? '') == $b ? 'selected' : '' ?>><?= $b ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>

                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                <button type="submit" name="edit_warga" class="btn btn-warning text-white">Simpan Perubahan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Modal Hapus -->
                            <div class="modal fade" id="modalHapus<?= $w['id_warga'] ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form method="POST">
                                            <input type="hidden" name="id_warga" value="<?= $w['id_warga'] ?>">
                                            <div class="modal-header bg-danger text-white">
                                                <h5 class="modal-title">Hapus Data Warga?</h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p>Anda yakin ingin menghapus data <b><?= htmlspecialchars($w['nama_lengkap']) ?></b> (NIK: <?= $w['nik'] ?>)?</p>
                                                <div class="alert alert-warning small mb-0">
                                                    <i class="bi bi-exclamation-triangle-fill me-1"></i>
                                                    <b>PERINGATAN:</b> Menghapus data warga akan otomatis menghapus akun user, riwayat iuran, dan pengajuan surat yang terkait dengannya (Sistem CASCADE).
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                <button type="submit" name="hapus_warga" class="btn btn-danger">Ya, Hapus Permanen</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="8" class="text-center py-4 text-muted">Tidak ada data Kepala Keluarga ditemukan.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah Warga -->
<div class="modal fade" id="modalTambah" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title"><i class="bi bi-person-plus-fill me-2"></i>Tambah Data Warga Baru</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold small">NIK (16 Digit)</label>
                            <input type="text" name="nik" class="form-control" maxlength="16" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold small">No. KK (16 Digit)</label>
                            <input type="text" name="no_kk" class="form-control" maxlength="16" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-8 mb-3">
                            <label class="form-label fw-semibold small">Nama Lengkap</label>
                            <input type="text" name="nama_lengkap" class="form-control" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold small">Jenis Kelamin</label>
                            <select name="jenis_kelamin" class="form-select" required>
                                <option value="L">Laki-laki</option>
                                <option value="P">Perempuan</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-5 mb-3">
                            <label class="form-label fw-semibold small">Tempat Lahir</label>
                            <input type="text" name="tempat_lahir" class="form-control">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold small">Tanggal Lahir</label>
                            <input type="date" name="tanggal_lahir" class="form-control" required>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label fw-semibold small">Agama</label>
                            <select name="agama" class="form-select">
                                <?php $agama_list = ['Islam','Kristen','Katolik','Hindu','Buddha','Konghucu']; ?>
                                <?php foreach($agama_list as $a): ?>
                                <option value="<?= $a ?>"><?= $a ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Alamat Lengkap</label>
                        <textarea name="alamat" class="form-control" rows="2" required></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <label class="form-label fw-semibold small">RT</label>
                            <input type="text" name="rt" class="form-control" value="017" required>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label fw-semibold small">RW</label>
                            <input type="text" name="rw" class="form-control" value="005" required>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label fw-semibold small">Status Perkawinan</label>
                            <select name="status_kawin" class="form-select">
                                <option value="Belum Kawin">Belum Kawin</option>
                                <option value="Kawin">Kawin</option>
                                <option value="Cerai Hidup">Cerai Hidup</option>
                                <option value="Cerai Mati">Cerai Mati</option>
                            </select>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label fw-semibold small">Hub. Dalam KK</label>
                            <select name="status_hubungan_kk" class="form-select">
                                <option value="Kepala Keluarga">Kepala Keluarga</option>
                                <option value="Istri">Istri</option>
                                <option value="Anak">Anak</option>
                                <option value="Lainnya">Lainnya</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold small">Pekerjaan</label>
                            <input type="text" name="pekerjaan" class="form-control">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold small">Pendidikan Terakhir</label>
                            <select name="pendidikan_terakhir" class="form-select">
                                <?php $pend_list = ['Tidak Sekolah','SD','SMP','SMA','D1-D3','S1','S2','S3']; ?>
                                <?php foreach($pend_list as $p): ?>
                                <option value="<?= $p ?>"><?= $p ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold small">No. HP</label>
                            <input type="text" name="no_hp" class="form-control">
                        </div>
                    </div>

                    <hr class="my-4">
                    <h6 class="fw-bold text-danger mb-3"><i class="bi bi-shield-plus me-2"></i>Data Sosial (Kepala Keluarga)</h6>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold small">Status Ekonomi</label>
                            <select name="status_ekonomi" class="form-select">
                                <?php foreach($ekonomi_options as $e): ?>
                                <option value="<?= $e ?>"><?= $e ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold small">Penerima Bansos</label>
                            <select name="penerima_bansos" id="penerima_bansos_tambah" class="form-select" onchange="toggleBansosField('tambah')">
                                <option value="0">Tidak</option>
                                <option value="1">Ya</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3" id="jenis_bansos_wrap_tambah" style="display: none;">
                        <label class="form-label fw-semibold small">Jenis Bansos</label>
                        <select name="jenis_bansos" class="form-select">
                            <option value="">-- Pilih Jenis Bansos --</option>
                            <?php foreach($bansos_options as $b): ?>
                            <option value="<?= $b ?>"><?= $b ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="tambah_warga" class="btn btn-danger text-white">Simpan Data Warga</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Fungsi untuk menampilkan/menyembunyikan input Jenis Bansos
function toggleBansosField(id) {
    var select = document.getElementById('penerima_bansos_' + id);
    var wrap = document.getElementById('jenis_bansos_wrap_' + id);
    if (select.value == '1') {
        wrap.style.display = 'block';
    } else {
        wrap.style.display = 'none';
    }
}
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>