<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('admin');
require_once __DIR__ . '/../../config/database.php';

// ==========================================
// LOGIC: Tambah User Baru
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah_user'])) {
    $username = trim($_POST['username']);
    $password = password_hash(trim($_POST['password']), PASSWORD_BCRYPT);
    $role = $_POST['role'];
    $id_warga = !empty($_POST['id_warga']) ? $_POST['id_warga'] : null;
    $status_aktif = $_POST['status_aktif'];

    $stmt = $pdo->prepare("INSERT INTO users (id_warga, username, password, role, status_aktif) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$id_warga, $username, $password, $role, $status_aktif]);
    header("Location: users.php?msg=Akun berhasil ditambahkan");
    exit;
}

// ==========================================
// LOGIC: Edit User
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_user'])) {
    $id_user = $_POST['id_user'];
    $username = trim($_POST['username']);
    $role = $_POST['role'];
    $status_aktif = $_POST['status_aktif'];

    // Jika password diisi, update password. Jika kosong, biarkan password lama
    if (!empty($_POST['password'])) {
        $password = password_hash(trim($_POST['password']), PASSWORD_BCRYPT);
        $stmt = $pdo->prepare("UPDATE users SET username=?, password=?, role=?, status_aktif=? WHERE id_user=?");
        $stmt->execute([$username, $password, $role, $status_aktif, $id_user]);
    } else {
        $stmt = $pdo->prepare("UPDATE users SET username=?, role=?, status_aktif=? WHERE id_user=?");
        $stmt->execute([$username, $role, $status_aktif, $id_user]);
    }
    header("Location: users.php?msg=Akun berhasil diperbarui");
    exit;
}

// ==========================================
// LOGIC: Hapus User
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['hapus_user'])) {
    $stmt = $pdo->prepare("DELETE FROM users WHERE id_user=?");
    $stmt->execute([$_POST['id_user']]);
    header("Location: users.php?msg=Akun berhasil dihapus");
    exit;
}

// ==========================================
// QUERY: Ambil Data
// ==========================================
 $users = $pdo->query("SELECT u.*, w.nama_lengkap FROM users u LEFT JOIN warga w ON u.id_warga = w.id_warga ORDER BY u.role ASC, u.id_user DESC")->fetchAll();
 $warga_list = $pdo->query("SELECT id_warga, nama_lengkap, nik FROM warga ORDER BY nama_lengkap ASC")->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<style>
    .card-modern { border: none; border-radius: 15px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); }
    .badge-admin { background: linear-gradient(135deg, #dc3545 0%, #bb2d3b 100%); color: white; }
    .badge-ketua_rt { background: linear-gradient(135deg, #0d6efd 0%, #0b5ed7 100%); color: white; }
    .badge-bendahara { background: linear-gradient(135deg, #198754 0%, #157347 100%); color: white; }
    .badge-warga { background: linear-gradient(135deg, #6f42c1 0%, #520dc2 100%); color: white; }
    .form-control:focus, .form-select:focus { border-color: #dc3545; box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.15); }
</style>

<div class="container-fluid">
    <h3 class="mt-4 mb-4"><i class="bi bi-people-fill me-2 text-danger"></i>Manajemen User & Akses</h3>

    <?php if(isset($_GET['msg'])): ?>
        <div class="alert alert-success alert-dismissible fade show rounded-3 border-0 shadow-sm" role="alert">
            <i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($_GET['msg']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="d-flex justify-content-end mb-3">
        <button class="btn btn-danger shadow-sm" data-bs-toggle="modal" data-bs-target="#modalTambah">
            <i class="bi bi-person-plus-fill me-1"></i> Tambah User Baru
        </button>
    </div>

    <div class="card card-modern shadow-sm border-0 rounded-3">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th width="5%">No</th>
                            <th>Username</th>
                            <th>Nama Terkait (Warga)</th>
                            <th>Role / Wewenang</th>
                            <th>Status</th>
                            <th>Login Terakhir</th>
                            <th width="15%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($users) > 0): $no=1; ?>
                            <?php foreach($users as $u): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td class="fw-bold">@<?= htmlspecialchars($u['username']) ?></td>
                                <td>
                                    <?php if($u['nama_lengkap']): ?>
                                        <span class="text-dark"><?= htmlspecialchars($u['nama_lengkap']) ?></span>
                                    <?php else: ?>
                                        <span class="text-muted fst-italic">Akun Sistem (Non-Warga)</span>
                                    <?php endif; ?>
                                </td>
                                <td><span class="badge badge-<?= $u['role'] ?> py-2 px-3 rounded-pill"><?= ucfirst(str_replace('_', ' ', $u['role'])) ?></span></td>
                                <td>
                                    <?php if($u['status_aktif'] == 1): ?>
                                        <span class="badge bg-success"><i class="bi bi-check-circle me-1"></i>Aktif</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary"><i class="bi bi-slash-circle me-1"></i>Nonaktif</span>
                                    <?php endif; ?>
                                </td>
                                <td class="small text-muted"><?= $u['last_login'] ? date('d M Y, H:i', strtotime($u['last_login'])) : 'Belum pernah' ?></td>
                                <td>
                                    <button class="btn btn-sm btn-outline-warning" data-bs-toggle="modal" data-bs-target="#modalEdit<?= $u['id_user'] ?>"><i class="bi bi-pencil"></i></button>
                                    <?php if($u['role'] !== 'admin'): // Admin utama tidak bisa dihapus ?>
                                    <button class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#modalHapus<?= $u['id_user'] ?>"><i class="bi bi-trash"></i></button>
                                    <?php endif; ?>
                                </td>
                            </tr>

                            <!-- Modal Edit -->
                            <div class="modal fade" id="modalEdit<?= $u['id_user'] ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form method="POST">
                                            <input type="hidden" name="id_user" value="<?= $u['id_user'] ?>">
                                            <div class="modal-header bg-warning text-white">
                                                <h5 class="modal-title">Edit User: @<?= htmlspecialchars($u['username']) ?></h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label class="form-label fw-semibold">Username</label>
                                                    <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($u['username']) ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label fw-semibold">Password Baru <small class="text-muted">(Kosongkan jika tidak ingin ganti)</small></label>
                                                    <input type="password" name="password" class="form-control" placeholder="••••••••">
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label fw-semibold">Role / Wewenang</label>
                                                    <select name="role" class="form-select" required>
                                                        <option value="admin" <?= $u['role']=='admin'?'selected':'' ?>>Admin</option>
                                                        <option value="ketua_rt" <?= $u['role']=='ketua_rt'?'selected':'' ?>>Ketua RT</option>
                                                        <option value="bendahara" <?= $u['role']=='bendahara'?'selected':'' ?>>Bendahara</option>
                                                        <option value="warga" <?= $u['role']=='warga'?'selected':'' ?>>Warga</option>
                                                    </select>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label fw-semibold">Status Akun</label>
                                                    <select name="status_aktif" class="form-select" required>
                                                        <option value="1" <?= $u['status_aktif']==1?'selected':'' ?>>Aktif</option>
                                                        <option value="0" <?= $u['status_aktif']==0?'selected':'' ?>>Nonaktif (Blokir)</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                <button type="submit" name="edit_user" class="btn btn-warning text-white">Simpan Perubahan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Modal Hapus -->
                            <div class="modal fade" id="modalHapus<?= $u['id_user'] ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form method="POST">
                                            <input type="hidden" name="id_user" value="<?= $u['id_user'] ?>">
                                            <div class="modal-header bg-danger text-white">
                                                <h5 class="modal-title">Hapus Akun?</h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p>Anda yakin ingin menghapus akun <b>@<?= htmlspecialchars($u['username']) ?></b>?</p>
                                                <p class="text-muted small">Semua riwayat aktivitas akun ini mungkin juga akan terhapus.</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                <button type="submit" name="hapus_user" class="btn btn-danger">Ya, Hapus</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="7" class="text-center py-4 text-muted">Belum ada data user.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah User -->
<div class="modal fade" id="modalTambah" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title">Tambah User Baru</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Username</label>
                        <input type="text" name="username" class="form-control" required autocomplete="off">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Password</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Role / Wewenang</label>
                        <select name="role" class="form-select" required>
                            <option value="admin">Admin</option>
                            <option value="ketua_rt">Ketua RT</option>
                            <option value="bendahara">Bendahara</option>
                            <option value="warga">Warga</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Hubungkan dengan Data Warga <small class="text-muted">(Opsional, jika role Warga wajib diisi)</small></label>
                        <select name="id_warga" class="form-select">
                            <option value="">-- Tidak Terikat Warga (Admin/RT/Bendahara) --</option>
                            <?php foreach($warga_list as $w): ?>
                            <option value="<?= $w['id_warga'] ?>"><?= htmlspecialchars($w['nama_lengkap']) ?> (NIK: <?= $w['nik'] ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Status</label>
                        <select name="status_aktif" class="form-select" required>
                            <option value="1">Aktif</option>
                            <option value="0">Nonaktif</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="tambah_user" class="btn btn-danger text-white">Buat Akun</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>