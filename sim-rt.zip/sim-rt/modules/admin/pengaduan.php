<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('admin');
require_once __DIR__ . '/../../config/database.php';

 $stmt = $pdo->query("SELECT p.*, w.nama_lengkap FROM pengaduan p JOIN warga w ON p.id_warga=w.id_warga ORDER BY p.tanggal_aduan DESC");
 $aduan = $stmt->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="container-fluid">
    <h3 class="mt-4 mb-4"><i class="bi bi-chat-dots me-2 text-danger"></i>Layanan Pengaduan Warga (Admin)</h3>

    <div class="card card-modern shadow border-0 rounded-3">
        <div class="card-body p-0">
            <?php if(count($aduan) > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Pelapor</th>
                            <th>Kategori</th>
                            <th>Isi Aduan</th>
                            <th>Tanggal</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($aduan as $a): ?>
                        <tr>
                            <td class="fw-bold"><?= htmlspecialchars($a['nama_lengkap']) ?></td>
                            <td><span class="badge bg-secondary"><?= $a['kategori'] ?></span></td>
                            <td class="small" style="max-width: 250px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="<?= htmlspecialchars($a['isi_aduan']) ?>">
                                <?= htmlspecialchars($a['isi_aduan']) ?>
                            </td>
                            <td class="small text-muted"><?= date('d M Y', strtotime($a['tanggal_aduan'])) ?></td>
                            <td>
                                <?php 
                                    $badge = 'bg-warning text-dark'; 
                                    if($a['status']=='diproses') $badge='bg-info text-dark'; 
                                    if($a['status']=='selesai') $badge='bg-success'; 
                                ?>
                                <span class="badge <?= $badge ?>"><?= ucfirst($a['status']) ?></span>
                            </td>
                            <td>
                                <!-- Arahkan ke halaman proses milik RT, karena Admin juga berhak -->
                                <a href="../rt/proses_aduan.php?id=<?= $a['id_pengaduan'] ?>" class="btn btn-sm btn-outline-danger">
                                    <i class="bi bi-eye me-1"></i> Proses / Balas
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
                <div class="text-center p-5 text-muted">Belum ada pengaduan masuk.</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>