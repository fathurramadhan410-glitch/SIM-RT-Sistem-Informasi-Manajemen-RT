<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('admin');
require_once __DIR__ . '/../../config/database.php';

 $no_kk = $_GET['no_kk'] ?? '';

if (empty($no_kk)) {
    header("Location: data_warga.php?msg=No KK tidak ditemukan!");
    exit;
}

// LOGIC: TAMBAH ANGGOTA KELUARGA BARU KE KK INI
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah_anggota'])) {
    $nik = trim($_POST['nik']);
    
    $cek_nik = $pdo->prepare("SELECT id_warga FROM warga WHERE nik=?");
    $cek_nik->execute([$nik]);
    if ($cek_nik->fetch()) {
        header("Location: detail_keluarga.php?no_kk=$no_kk&msg=NIK sudah terdaftar di database!");
        exit;
    }

    $stmt_kepala = $pdo->prepare("SELECT alamat, rt, rw FROM warga WHERE no_kk = ? AND status_hubungan_kk = 'Kepala Keluarga'");
    $stmt_kepala->execute([$no_kk]);
    $kepala = $stmt_kepala->fetch();

    $stmt = $pdo->prepare("INSERT INTO warga (nik, no_kk, nama_lengkap, jenis_kelamin, tempat_lahir, tanggal_lahir, alamat, rt, rw, agama, status_kawin, pekerjaan, pendidikan_terakhir, status_hubungan_kk, no_hp) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $nik, $no_kk, $_POST['nama_lengkap'], $_POST['jenis_kelamin'], 
        $_POST['tempat_lahir'], $_POST['tanggal_lahir'], $kepala['alamat'], 
        $kepala['rt'], $kepala['rw'], $_POST['agama'], $_POST['status_kawin'], 
        $_POST['pekerjaan'], $_POST['pendidikan_terakhir'], $_POST['status_hubungan_kk'], $_POST['no_hp']
    ]);

    $id_warga_baru = $pdo->lastInsertId();
    $pdo->prepare("INSERT INTO profil_sosial_warga (id_warga) VALUES (?)")->execute([$id_warga_baru]);

    header("Location: detail_keluarga.php?no_kk=$no_kk&msg=Anggota keluarga berhasil ditambahkan!");
    exit;
}

// LOGIC: EDIT ANGGOTA KELUARGA
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_anggota'])) {
    $id_warga = $_POST['id_warga'];
    
    // Update tabel warga
    $stmt = $pdo->prepare("UPDATE warga SET nik=?, nama_lengkap=?, jenis_kelamin=?, tempat_lahir=?, tanggal_lahir=?, agama=?, status_kawin=?, pekerjaan=?, pendidikan_terakhir=?, status_hubungan_kk=?, no_hp=? WHERE id_warga=?");
    $stmt->execute([
        $_POST['nik'], $_POST['nama_lengkap'], $_POST['jenis_kelamin'], 
        $_POST['tempat_lahir'], $_POST['tanggal_lahir'], $_POST['agama'], 
        $_POST['status_kawin'], $_POST['pekerjaan'], $_POST['pendidikan_terakhir'], 
        $_POST['status_hubungan_kk'], $_POST['no_hp'], $id_warga
    ]);

    // Update tabel profil_sosial_warga
     $penerima_bansos = ($_POST['penerima_bansos'] == '1') ? 1 : 0;
    $jenis_bansos = $penerima_bansos ? $_POST['jenis_bansos'] : null;

    $stmt_ps = $pdo->prepare("UPDATE profil_sosial_warga SET status_disabilitas=?, penerima_bansos=?, jenis_bansos=? WHERE id_warga=?");
    $stmt_ps->execute([
        $_POST['status_disabilitas'], $penerima_bansos, $jenis_bansos, $id_warga
    ]);

    header("Location: detail_keluarga.php?no_kk=$no_kk&msg=Data anggota berhasil diperbarui!");
    exit;
}

// LOGIC: HAPUS ANGGOTA KELUARGA
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['hapus_anggota'])) {
    $id_hapus = $_POST['id_warga'];
    $cek_kepala = $pdo->prepare("SELECT status_hubungan_kk FROM warga WHERE id_warga=?");
    $cek_kepala->execute([$id_hapus]);
    $data = $cek_kepala->fetch();

    if ($data && $data['status_hubungan_kk'] == 'Kepala Keluarga') {
        header("Location: detail_keluarga.php?no_kk=$no_kk&msg=Tidak bisa menghapus Kepala Keluarga dari sini!");
        exit;
    }

    $stmt = $pdo->prepare("DELETE FROM warga WHERE id_warga=?");
    $stmt->execute([$id_hapus]);
    header("Location: detail_keluarga.php?no_kk=$no_kk&msg=Anggota keluarga berhasil dihapus!");
    exit;
}

// QUERY: AMBIL SEMUA ANGGOTA DARI KK INI + JOIN PROFIL SOSIAL
 $stmt = $pdo->prepare("SELECT w.*, ps.penerima_bansos, ps.jenis_bansos, ps.status_disabilitas 
                       FROM warga w 
                       LEFT JOIN profil_sosial_warga ps ON w.id_warga = ps.id_warga 
                       WHERE w.no_kk=? 
                       ORDER BY FIELD(w.status_hubungan_kk, 'Kepala Keluarga', 'Istri', 'Anak', 'Lainnya'), w.tanggal_lahir ASC");
 $stmt->execute([$no_kk]);
 $anggota_list = $stmt->fetchAll();

 $kepala_info = $anggota_list[0] ?? null;

// Daftar Opsi untuk Dropdown
 $bansos_options = [
    'PKH (Program Keluarga Harapan)',
    'BPNT (Bantuan Pangan Non-Tunai)',
    'ATENSI (Asistensi Rehabilitasi Sosial)',
    'PBI-JK (Penerima Bantuan Iuran Jaminan Kesehatan)',
    'YAPI (Yatim Piatu)',
    'PKH Anak Sekolah (PKH Komponen Pendidikan)',
    'SR (Sekolah Rakyat)',
    'PIP (Program Indonesia Pintar)',
    'KIP (Kartu Indonesia Pintar)',
    'Lainnya'
];

require_once __DIR__ . '/../../includes/header.php';
?>

<style>
    .card-modern { border: none; border-radius: 15px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); }
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="mt-4 mb-0"><i class="bi bi-house-door-fill me-2 text-danger"></i>Detail Kartu Keluarga</h3>
        <a href="data_warga.php" class="btn btn-outline-secondary rounded-pill"><i class="bi bi-arrow-left"></i> Kembali ke Data Warga</a>
    </div>

    <?php if(isset($_GET['msg'])): ?>
        <div class="alert alert-success alert-dismissible fade show rounded-3 border-0 shadow-sm" role="alert">
            <i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($_GET['msg']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="alert alert-primary border-0 rounded-3 shadow-sm mb-4">
        <h5 class="mb-1 fw-bold">No. KK: <?= htmlspecialchars($no_kk) ?></h5>
        <p class="mb-0 text-muted">Kepala Keluarga: <b><?= htmlspecialchars($kepala_info['nama_lengkap'] ?? 'Tidak Ditemukan') ?></b> | Alamat: <?= htmlspecialchars($kepala_info['alamat'] ?? '-') ?> (RT <?= $kepala_info['rt'] ?? '-' ?>/RW <?= $kepala_info['rw'] ?? '-' ?>)</p>
    </div>

    <div class="d-flex justify-content-end mb-3">
        <button class="btn btn-danger shadow-sm rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#modalTambahAnggota">
            <i class="bi bi-person-plus-fill me-1"></i> Tambah Anggota Keluarga
        </button>
    </div>

    <div class="card card-modern shadow-sm border-0 rounded-3">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>No</th>
                            <th>NIK</th>
                            <th>Nama Lengkap</th>
                            <th>L/P</th>
                            <th>Tempat, Tgl Lahir</th>
                            <th>Status Hubungan</th>
                            <th>Penerima Bansos</th>
                            <th>Disabilitas</th>
                            <th width="10%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($anggota_list) > 0): $no=1; ?>
                            <?php foreach($anggota_list as $w): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td class="fw-bold"><?= $w['nik'] ?></td>
                                <td><?= htmlspecialchars($w['nama_lengkap']) ?></td>
                                <td>
    <?php if($w['jenis_kelamin'] == 'Laki-laki'): ?>
        <span class="badge bg-primary">Laki-laki</span>
    <?php else: ?>
        <span class="badge bg-danger">Perempuan</span>
    <?php endif; ?>
</td>
                                <td class="small"><?= htmlspecialchars($w['tempat_lahir'] ?? '-') ?>, <?= date('d-m-Y', strtotime($w['tanggal_lahir'])) ?></td>
                                <td>
                                    <?php if($w['status_hubungan_kk'] == 'Kepala Keluarga'): ?>
                                        <span class="badge bg-danger"><?= $w['status_hubungan_kk'] ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-light text-dark border"><?= $w['status_hubungan_kk'] ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($w['penerima_bansos'] == 1): ?>
                                        <span class="badge bg-success"><?= htmlspecialchars($w['jenis_bansos'] ?? 'Bansos') ?></span>
                                    <?php else: ?>
                                        <span class="text-muted small">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if(!empty($w['status_disabilitas']) && $w['status_disabilitas'] != 'Tidak Ada'): ?>
                                        <span class="badge bg-warning text-dark"><?= htmlspecialchars($w['status_disabilitas']) ?></span>
                                    <?php else: ?>
                                        <span class="text-muted small">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-warning mb-1" data-bs-toggle="modal" data-bs-target="#modalEditAnggota<?= $w['id_warga'] ?>" title="Edit Data"><i class="bi bi-pencil"></i></button>
                                    <?php if($w['status_hubungan_kk'] != 'Kepala Keluarga'): ?>
                                    <form method="POST" onsubmit="return confirm('Yakin hapus anggota ini?');" class="d-inline">
                                        <input type="hidden" name="id_warga" value="<?= $w['id_warga'] ?>">
                                        <button type="submit" name="hapus_anggota" class="btn btn-sm btn-outline-danger mb-1" title="Hapus Anggota"><i class="bi bi-trash"></i></button>
                                    </form>
                                    <?php endif; ?>
                                </td>
                            </tr>

                            <!-- Modal Edit Anggota -->
                            <div class="modal fade" id="modalEditAnggota<?= $w['id_warga'] ?>" tabindex="-1">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <form method="POST">
                                            <input type="hidden" name="id_warga" value="<?= $w['id_warga'] ?>">
                                            <div class="modal-header bg-warning text-white">
                                                <h5 class="modal-title"><i class="bi bi-pencil-square me-2"></i>Edit Data: <?= htmlspecialchars($w['nama_lengkap']) ?></h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-8 mb-3">
                                                        <label class="form-label fw-semibold small">NIK (16 Digit)</label>
                                                        <input type="text" name="nik" class="form-control" maxlength="16" value="<?= htmlspecialchars($w['nik']) ?>" required>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label class="form-label fw-semibold small">Hubungan Dalam KK</label>
                                                        <select name="status_hubungan_kk" class="form-select" required>
                                                            <option value="Kepala Keluarga" <?= $w['status_hubungan_kk'] == 'Kepala Keluarga' ? 'selected' : '' ?>>Kepala Keluarga</option>
                                                            <option value="Istri" <?= $w['status_hubungan_kk'] == 'Istri' ? 'selected' : '' ?>>Istri</option>
                                                            <option value="Anak" <?= $w['status_hubungan_kk'] == 'Anak' ? 'selected' : '' ?>>Anak</option>
                                                            <option value="Lainnya" <?= $w['status_hubungan_kk'] == 'Lainnya' ? 'selected' : '' ?>>Lainnya</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-8 mb-3">
                                                        <label class="form-label fw-semibold small">Nama Lengkap</label>
                                                        <input type="text" name="nama_lengkap" class="form-control" value="<?= htmlspecialchars($w['nama_lengkap']) ?>" required>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label class="form-label fw-semibold small">Jenis Kelamin</label>
                                                        <select name="jenis_kelamin" class="form-select" required>
                                                            <option value="L" <?= $w['jenis_kelamin'] == 'L' ? 'selected' : '' ?>>Laki-laki</option>
                                                            <option value="P" <?= $w['jenis_kelamin'] == 'P' ? 'selected' : '' ?>>Perempuan</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-8 mb-3">
                                                        <label class="form-label fw-semibold small">Tempat Lahir</label>
                                                        <input type="text" name="tempat_lahir" class="form-control" value="<?= htmlspecialchars($w['tempat_lahir'] ?? '') ?>">
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label class="form-label fw-semibold small">Tanggal Lahir</label>
                                                        <input type="date" name="tanggal_lahir" class="form-control" value="<?= $w['tanggal_lahir'] ?>" required>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-4 mb-3">
                                                        <label class="form-label fw-semibold small">Agama</label>
                                                        <select name="agama" class="form-select">
                                                            <?php $agama_list = ['Islam','Kristen','Katolik','Hindu','Buddha','Konghucu']; ?>
                                                            <?php foreach($agama_list as $a): ?>
                                                            <option value="<?= $a ?>" <?= ($w['agama'] ?? '') == $a ? 'selected' : '' ?>><?= $a ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label class="form-label fw-semibold small">Status Perkawinan</label>
                                                        <select name="status_kawin" class="form-select">
                                                            <option value="Belum Kawin" <?= $w['status_kawin'] == 'Belum Kawin' ? 'selected' : '' ?>>Belum Kawin</option>
                                                            <option value="Kawin" <?= $w['status_kawin'] == 'Kawin' ? 'selected' : '' ?>>Kawin</option>
                                                            <option value="Cerai Hidup" <?= $w['status_kawin'] == 'Cerai Hidup' ? 'selected' : '' ?>>Cerai Hidup</option>
                                                            <option value="Cerai Mati" <?= $w['status_kawin'] == 'Cerai Mati' ? 'selected' : '' ?>>Cerai Mati</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label class="form-label fw-semibold small">Pendidikan Terakhir</label>
                                                        <select name="pendidikan_terakhir" class="form-select">
                                                            <?php $pend_list = ['Tidak Sekolah','SD','SMP','SMA','D1-D3','S1','S2','S3']; ?>
                                                            <?php foreach($pend_list as $p): ?>
                                                            <option value="<?= $p ?>" <?= ($w['pendidikan_terakhir'] ?? '') == $p ? 'selected' : '' ?>><?= $p ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-8 mb-3">
                                                        <label class="form-label fw-semibold small">Pekerjaan</label>
                                                        <input type="text" name="pekerjaan" class="form-control" value="<?= htmlspecialchars($w['pekerjaan'] ?? '') ?>">
                                                    </div>
                                                    <div class="col-md-4 mb-3">
                                                        <label class="form-label fw-semibold small">No. HP</label>
                                                        <input type="text" name="no_hp" class="form-control" value="<?= htmlspecialchars($w['no_hp'] ?? '') ?>">
                                                    </div>
                                                </div>

                                                <hr class="my-4">
                                                <h6 class="fw-bold text-danger mb-3"><i class="bi bi-shield-plus me-2"></i>Data Sosial (Bansos & Disabilitas)</h6>
                                                
                                                <div class="row">
                                                    <div class="col-md-6 mb-3">
                                                        <label class="form-label fw-semibold small">Status Disabilitas</label>
                                                        <select name="status_disabilitas" class="form-select">
                                                            <?php $dis_list = ['Tidak Ada','Fisik','Netra','Rungu/Wicara','Mental','Ganda']; ?>
                                                            <?php foreach($dis_list as $d): ?>
                                                            <option value="<?= $d ?>" <?= ($w['status_disabilitas'] ?? 'Tidak Ada') == $d ? 'selected' : '' ?>><?= $d ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-6 mb-3">
                                                        <label class="form-label fw-semibold small">Penerima Bansos</label>
                                                        <select name="penerima_bansos" id="penerima_bansos_<?= $w['id_warga'] ?>" class="form-select" onchange="toggleBansosField(<?= $w['id_warga'] ?>)">
                                                            <option value="0" <?= ($w['penerima_bansos'] ?? 0) == 0 ? 'selected' : '' ?>>Tidak</option>
                                                            <option value="1" <?= ($w['penerima_bansos'] ?? 0) == 1 ? 'selected' : '' ?>>Ya</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="mb-3" id="jenis_bansos_wrap_<?= $w['id_warga'] ?>" style="display: <?= ($w['penerima_bansos'] ?? 0) == 1 ? 'block' : 'none' ?>;">
                                                    <label class="form-label fw-semibold small">Jenis Bansos</label>
                                                    <select name="jenis_bansos" class="form-select">
                                                        <option value="">-- Pilih Jenis Bansos --</option>
                                                        <?php foreach($bansos_options as $b): ?>
                                                            <option value="<?= $b ?>" <?= ($w['jenis_bansos'] ?? '') == $b ? 'selected' : '' ?>><?= $b ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>

                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                <button type="submit" name="edit_anggota" class="btn btn-warning text-white"><i class="bi bi-save me-1"></i> Simpan Perubahan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="9" class="text-center py-4 text-muted">Data KK tidak ditemukan.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah Anggota Keluarga -->
<div class="modal fade" id="modalTambahAnggota" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title"><i class="bi bi-person-plus-fill me-2"></i>Tambah Anggota Keluarga (KK: <?= $no_kk ?>)</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-8 mb-3">
                            <label class="form-label fw-semibold small">NIK (16 Digit)</label>
                            <input type="text" name="nik" class="form-control" maxlength="16" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold small">Hubungan Dalam KK</label>
                            <select name="status_hubungan_kk" class="form-select" required>
                                <option value="Istri">Istri</option>
                                <option value="Anak">Anak</option>
                                <option value="Lainnya">Lainnya</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-8 mb-3">
                            <label class="form-label fw-semibold small">Nama Lengkap</label>
                            <input type="text" name="nama_lengkap" class="form-control" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold small">Jenis Kelamin</label>
                            <select name="jenis_kelamin" class="form-select" required>
                                <option value="L">Laki-laki</option>
                                <option value="P">Perempuan</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-8 mb-3">
                            <label class="form-label fw-semibold small">Tempat Lahir</label>
                            <input type="text" name="tempat_lahir" class="form-control">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold small">Tanggal Lahir</label>
                            <input type="date" name="tanggal_lahir" class="form-control" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold small">Agama</label>
                            <select name="agama" class="form-select">
                                <?php $agama_list = ['Islam','Kristen','Katolik','Hindu','Buddha','Konghucu']; ?>
                                <?php foreach($agama_list as $a): ?>
                                <option value="<?= $a ?>"><?= $a ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold small">Status Perkawinan</label>
                            <select name="status_kawin" class="form-select">
                                <option value="Belum Kawin">Belum Kawin</option>
                                <option value="Kawin">Kawin</option>
                                <option value="Cerai Hidup">Cerai Hidup</option>
                                <option value="Cerai Mati">Cerai Mati</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold small">Pendidikan Terakhir</label>
                            <select name="pendidikan_terakhir" class="form-select">
                                <?php $pend_list = ['Tidak Sekolah','SD','SMP','SMA','D1-D3','S1','S2','S3']; ?>
                                <?php foreach($pend_list as $p): ?>
                                <option value="<?= $p ?>"><?= $p ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-8 mb-3">
                            <label class="form-label fw-semibold small">Pekerjaan</label>
                            <input type="text" name="pekerjaan" class="form-control">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold small">No. HP</label>
                            <input type="text" name="no_hp" class="form-control">
                        </div>
                    </div>
                    <div class="alert alert-info small">
                        <i class="bi bi-info-circle"></i> Alamat, RT, dan RW akan otomatis sama dengan Kepala Keluarga.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="tambah_anggota" class="btn btn-danger text-white">Simpan Anggota</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Fungsi untuk menampilkan/menyembunyikan input Jenis Bansos
function toggleBansosField(id_warga) {
    var select = document.getElementById('penerima_bansos_' + id_warga);
    var wrap = document.getElementById('jenis_bansos_wrap_' + id_warga);
    if (select.value == '1') {
        wrap.style.display = 'block';
    } else {
        wrap.style.display = 'none';
    }
}
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>