<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('warga');
require_once __DIR__ . '/../../config/database.php';

 $id_warga = $_SESSION['id_warga'];

// Logic: Kirim Aduan
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['kirim_aduan'])) {
    $stmt = $pdo->prepare("INSERT INTO pengaduan (id_warga, kategori, isi_aduan) VALUES (?, ?, ?)");
    $stmt->execute([$id_warga, $_POST['kategori'], $_POST['isi_aduan']]);
    header("Location: pengaduan.php?msg=berhasil");
    exit;
}

// Ambil Riwayat Aduan
 $aduan = $pdo->prepare("SELECT * FROM pengaduan WHERE id_warga=? ORDER BY tanggal_aduan DESC");
 $aduan->execute([$id_warga]);
 $data_aduan = $aduan->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<style>
    .gradient-pink { background: linear-gradient(135deg, #e83e8c 0%, #c7356f 100%); }
    .card-modern { border: none; border-radius: 15px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); }
    
    /* Desain Timeline */
    .timeline-item { position: relative; padding-left: 30px; margin-bottom: 30px; border-left: 2px solid #e9ecef; }
    .timeline-item::before { content: ''; position: absolute; left: -7px; top: 0; width: 12px; height: 12px; border-radius: 50%; background: #adb5bd; }
    .timeline-item.status-baru::before { background: #ffc107; border: 2px solid #fff; box-shadow: 0 0 0 2px #ffc107; }
    .timeline-item.status-diproses::before { background: #0dcaf0; border: 2px solid #fff; box-shadow: 0 0 0 2px #0dcaf0; }
    .timeline-item.status-selesai::before { background: #198754; border: 2px solid #fff; box-shadow: 0 0 0 2px #198754; }

    /* Desain Bubble Aduan Warga */
    .aduan-bubble {
        background: #f8f9fa; 
        border-radius: 0 15px 15px 15px; 
        padding: 15px; 
        border: 1px solid #e9ecef;
    }

    /* Desain Bubble Tanggapan RT */
    .tanggapan-bubble {
        position: relative;
        background: #e8f4fd; /* Warna biru muda agar khas balasan admin */
        border-radius: 15px 0 15px 15px;
        padding: 15px;
        margin-top: 10px;
        margin-left: 20px;
        border: 1px solid #bee5eb;
    }
    .tanggapan-bubble::before {
        content: '';
        position: absolute;
        top: -10px;
        left: 15px;
        border-width: 0 10px 10px 10px;
        border-style: solid;
        border-color: transparent transparent #bee5eb transparent;
    }

    .form-control:focus, .form-select:focus { border-color: #e83e8c; box-shadow: 0 0 0 0.2rem rgba(232, 62, 140, 0.15); }
</style>

<div class="container-fluid">
    <h3 class="mt-4 mb-4"><i class="bi bi-megaphone-fill me-2" style="color: #e83e8c;"></i>Layanan Pengaduan</h3>

    <?php if(isset($_GET['msg'])): ?>
        <div class="alert alert-success alert-dismissible fade show rounded-3 border-0 shadow-sm" role="alert">
            <i class="bi bi-check-circle me-2"></i>Laporan aduan berhasil dikirim! Pengurus RT akan segera menindaklanjuti.
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <!-- Form Aduan -->
        <div class="col-lg-5 mb-4">
            <div class="card card-modern">
                <div class="card-header bg-white border-0 pt-4 pb-0 px-4">
                    <h5 class="fw-bold mb-0" style="color: #e83e8c;">Buat Laporan Baru</h5>
                </div>
                <div class="card-body px-4 pb-4">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-semibold small">Kategori Masalah</label>
                            <select name="kategori" class="form-select" required>
                                <option value="">-- Pilih Kategori --</option>
                                <option value="Infrastruktur">🛣️ Infrastruktur (Jalan, Saluran Air)</option>
                                <option value="Keamanan">🚨 Keamanan & Ketertiban</option>
                                <option value="Sosial">🤝 Sosial & Benturan Warga</option>
                                <option value="Lainnya">📝 Lainnya</option>
                            </select>
                        </div>
                        <div class="mb-4">
                            <label class="form-label fw-semibold small">Detail Aduan</label>
                            <textarea name="isi_aduan" class="form-control" rows="5" placeholder="Jelaskan kronologi masalah secara detail..." required></textarea>
                        </div>
                        <button type="submit" name="kirim_aduan" class="btn w-100 text-white shadow-sm" style="background-color: #e83e8c;">
                            <i class="bi bi-send-fill me-1"></i> Kirim Aduan
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Riwayat Aduan (Timeline & Chat Bubble) -->
        <div class="col-lg-7 mb-4">
            <div class="card card-modern h-100">
                <div class="card-header bg-white border-0 pt-4 pb-0 px-4">
                    <h5 class="fw-bold text-dark mb-0"><i class="bi bi-chat-left-text-fill me-2"></i>Riwayat & Tanggapan Aduan</h5>
                </div>
                <div class="card-body px-4 pb-4 overflow-auto" style="max-height: 600px;">
                    <?php if(count($data_aduan) > 0): ?>
                        <?php foreach($data_aduan as $a): ?>
                        <div class="timeline-item status-<?= $a['status'] ?>">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <span class="badge bg-secondary"><?= $a['kategori'] ?></span>
                                <small class="text-muted"><?= date('d M Y, H:i', strtotime($a['tanggal_aduan'])) ?></small>
                            </div>
                            
                            <!-- Bubble Aduan Warga -->
                            <div class="aduan-bubble">
                                <p class="mb-1 text-dark" style="text-align: justify;"><?= nl2br(htmlspecialchars($a['isi_aduan'])) ?></p>
                            </div>

                            <!-- Status & Bubble Tanggapan RT -->
                            <?php if($a['status'] == 'baru'): ?>
                                <div class="mt-2">
                                    <span class="badge bg-warning text-dark shadow-sm"><i class="bi bi-hourglass-split me-1"></i>Menunggu Tanggapan RT</span>
                                </div>
                            <?php elseif(empty($a['tanggapan'])): ?>
                                <div class="mt-2">
                                    <span class="badge bg-info text-dark shadow-sm"><i class="bi bi-arrow-repeat me-1"></i>Sedang Diproses</span>
                                </div>
                            <?php else: ?>
                                <!-- Jika ada tanggapan, tampilkan dalam Bubble Biru Muda -->
                                <div class="tanggapan-bubble shadow-sm">
                                    <div class="d-flex align-items-center mb-2">
                                        <div class="rounded-circle bg-primary d-flex align-items-center justify-content-center text-white me-2" style="width: 25px; height: 25px; font-size: 0.7rem;">
                                            RT
                                        </div>
                                        <span class="fw-bold text-primary small">Tanggapan Pengurus RT</span>
                                        <?php if($a['status'] == 'selesai'): ?>
                                            <span class="badge bg-success ms-auto small"><i class="bi bi-check-circle-fill me-1"></i>Selesai</span>
                                        <?php else: ?>
                                            <span class="badge bg-info text-dark ms-auto small"><i class="bi bi-arrow-repeat me-1"></i>Diproses</span>
                                        <?php endif; ?>
                                    </div>
                                    <p class="mb-0 text-dark small" style="text-align: justify;">
                                        <?= nl2br(htmlspecialchars($a['tanggapan'])) ?>
                                    </p>
                                </div>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="text-center py-5 text-muted">
                            <i class="bi bi-chat-square-heart" style="font-size: 3rem; opacity: 0.3;"></i>
                            <h6 class="mt-3">Anda belum pernah mengirimkan aduan.</h6>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>