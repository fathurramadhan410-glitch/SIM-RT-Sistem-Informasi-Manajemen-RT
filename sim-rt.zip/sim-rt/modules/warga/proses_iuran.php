<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('warga');
require_once __DIR__ . '/../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_warga = $_SESSION['id_warga'];
    $bulan = $_POST['bulan'] ?? null;
    $tahun = $_POST['tahun'] ?? date('Y');
    $metode_bayar = $_POST['metode_bayar'] ?? null;
    
    $set_iuran = $pdo->query("SELECT nominal_iuran FROM pengaturan WHERE id_setting=1")->fetchColumn();

    // Cek apakah ada record tagihan untuk bulan & tahun ini
    $cek = $pdo->prepare("SELECT id_iuran, status_bayar FROM pembayaran_iuran WHERE id_warga=? AND bulan=? AND tahun=?");
    $cek->execute([$id_warga, $bulan, $tahun]);
    $sudah_ada = $cek->fetch();

    if ($sudah_ada) {
        if ($sudah_ada['status_bayar'] == 'lunas') {
            header("Location: riwayat_iuran.php?msg=Anda sudah membayar iuran bulan tersebut!");
            exit;
        } elseif ($sudah_ada['status_bayar'] == 'pending') {
            header("Location: riwayat_iuran.php?msg=Pembayaran untuk bulan ini sudah dikirim, menunggu konfirmasi Bendahara.");
            exit;
        } elseif ($sudah_ada['status_bayar'] == 'belum_bayar') {
            // Update tagihan yang belum bayar menjadi pending
            $stmt = $pdo->prepare("UPDATE pembayaran_iuran SET status_bayar='pending', metode_bayar=?, tanggal_bayar=CURDATE(), dicatat_oleh=? WHERE id_iuran=?");
            $stmt->execute([$metode_bayar, $_SESSION['id_user'], $sudah_ada['id_iuran']]);
            header("Location: riwayat_iuran.php?msg=Pembayaran berhasil dikirim! Menunggu konfirmasi Bendahara RT.");
            exit;
        }
    } else {
        // Jika ternyata bendahara belum generate tagihan, warga tetap bisa buat sendiri
        $stmt = $pdo->prepare("INSERT INTO pembayaran_iuran (id_warga, bulan, tahun, jumlah_bayar, tanggal_bayar, metode_bayar, status_bayar, dicatat_oleh) VALUES (?, ?, ?, ?, CURDATE(), ?, 'pending', ?)");
        $stmt->execute([$id_warga, $bulan, $tahun, $set_iuran, $metode_bayar, $_SESSION['id_user']]);
        header("Location: riwayat_iuran.php?msg=Pembayaran berhasil dikirim! Menunggu konfirmasi Bendahara RT.");
        exit;
    }
}
?>