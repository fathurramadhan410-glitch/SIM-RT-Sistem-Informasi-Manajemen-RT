<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('warga');
require_once __DIR__ . '/../../config/database.php';

 $id_warga = $_SESSION['id_warga'];
 $nama_bulan = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];

 $set_iuran = $pdo->query("SELECT nominal_iuran FROM pengaturan WHERE id_setting=1")->fetchColumn();

// ==========================================
// LOGIC: Filter Tahun & Query Data
// ==========================================
 $tahun_ini = date('Y');
 $filter_tahun = isset($_GET['tahun']) ? intval($_GET['tahun']) : $tahun_ini;

// Total terverifikasi berdasarkan tahun yang difilter
 $stmt_total = $pdo->prepare("SELECT SUM(jumlah_bayar) as total FROM pembayaran_iuran WHERE id_warga=? AND tahun=? AND status_bayar='lunas'");
 $stmt_total->execute([$id_warga, $filter_tahun]);
 $grand_total = $stmt_total->fetch()['total'] ?? 0;

// Ambil data iuran (status & metode) untuk tahun yang difilter
 $stmt_paid = $pdo->prepare("SELECT bulan, status_bayar, metode_bayar FROM pembayaran_iuran WHERE id_warga=? AND tahun=?");
 $stmt_paid->execute([$id_warga, $filter_tahun]);
 $paid_months = [];
while ($row = $stmt_paid->fetch()) {
    $paid_months[$row['bulan']] = $row;
}

// Tentukan batas bulan untuk loop tabel (LOGICA BARU)
if ($filter_tahun > $tahun_ini) {
    $max_bulan = 0; // Tahun depan belum ada tagihan
} elseif ($filter_tahun == $tahun_ini) {
    $max_bulan = date('n'); // Tahun ini, tampilkan sampai bulan sekarang
} else {
    // Tahun lalu: Hanya tampilkan bulan jika ada data tagihan/pembayaran di tahun tersebut.
    // Jika tidak ada data sama sekali di tahun lalu, maka $max_bulan = 0 (kosong).
    if (!empty($paid_months)) {
        $max_bulan = max(array_keys($paid_months));
    } else {
        $max_bulan = 0;
    }
}

require_once __DIR__ . '/../../includes/header.php';
?>

<style>
    .gradient-teal { background: linear-gradient(135deg, #20c9a0 0%, #1a9ea8 100%); }
    .gradient-orange { background: linear-gradient(135deg, #fd7e14 0%, #e8590c 100%); }
    .card-modern { border: none; border-radius: 15px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); }
    .card-stat { border: none; border-radius: 15px; color: white; padding: 20px 0; }
    .pulse-animation { animation: pulse 2s infinite; }
    @keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.7; } 100% { opacity: 1; } }
</style>

<div class="container-fluid">
    <h3 class="mt-4 mb-4"><i class="bi bi-cash-coin me-2" style="color: #20c9a0;"></i>Riwayat & Tagihan Iuran</h3>

    <?php if(isset($_GET['msg'])): ?>
        <div class="alert alert-success alert-dismissible fade show rounded-3 border-0 shadow-sm" role="alert">
            <i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($_GET['msg']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Statistik Cards -->
    <div class="row mb-4">
        <div class="col-md-4 mb-3">
            <div class="card card-stat gradient-teal shadow text-center">
                <i class="bi bi-wallet2" style="font-size: 2rem; opacity: 0.8;"></i>
                <h2 class="mt-2 mb-0 fw-bold">Rp <?= number_format($grand_total, 0, ',', '.') ?></h2>
                <span>Total Terverifikasi (Tahun <?= $filter_tahun ?>)</span>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="card card-stat gradient-orange shadow text-center">
                <i class="bi bi-receipt-cutoff" style="font-size: 2rem; opacity: 0.8;"></i>
                <h2 class="mt-2 mb-0 fw-bold">Rp <?= number_format($set_iuran, 0, ',', '.') ?></h2>
                <span>Tagihan Per Bulan</span>
            </div>
        </div>
    </div>

    <!-- Filter Tahun -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <form method="GET" class="d-flex align-items-center gap-2">
            <label class="fw-bold mb-0 text-muted small"><i class="bi bi-calendar3 me-1"></i>Lihat Tahun:</label>
            <input type="number" name="tahun" class="form-control form-control-sm text-center fw-bold" style="width: 100px;" value="<?= $filter_tahun ?>" min="2020" max="<?= $tahun_ini + 1 ?>">
            <button type="submit" class="btn btn-sm btn-outline-teal border" style="color: #20c9a0; border-color: #20c9a0;"><i class="bi bi-arrow-right-circle"></i></button>
        </form>
    </div>

    <!-- Tabel Tagihan -->
    <div class="card card-modern shadow-sm mb-4">
        <div class="card-header bg-white border-0 pt-4 pb-0 px-4">
            <h5 class="fw-bold text-dark mb-0"><i class="bi bi-calendar-check me-2"></i>Status Tagihan Tahun <?= $filter_tahun ?></h5>
            <small class="text-muted">Tagihan hanya akan muncul jika Bendahara RT telah meng-generate tagihan pada bulan tersebut.</small>
        </div>
        <div class="card-body p-4">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Bulan</th>
                            <th>Nominal</th>
                            <th>Status</th>
                            <th>Metode Bayar</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $belum_bayar_count = 0; ?>
                        <?php for($i=1; $i<=$max_bulan; $i++): 
                            $data_bulan = $paid_months[$i] ?? null;
                            $status_bulan_ini = $data_bulan['status_bayar'] ?? null;
                            $metode_bulan_ini = $data_bulan['metode_bayar'] ?? null;
                        ?>
                            <?php if($status_bulan_ini === 'lunas'): ?>
                            <tr>
                                <td class="fw-bold"><?= $nama_bulan[($i - 1)] ?></td>
                                <td>Rp <?= number_format($set_iuran, 0, ',', '.') ?></td>
                                <td><span class="badge bg-success py-2 px-3 rounded-pill"><i class="bi bi-check-circle-fill me-1"></i>LUNAS</span></td>
                                <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($metode_bulan_ini) ?></span></td>
                                <td><span class="text-muted small">Selesai</span></td>
                            </tr>
                            <?php elseif($status_bulan_ini === 'pending'): ?>
                            <tr class="table-warning">
                                <td class="fw-bold"><?= $nama_bulan[($i - 1)] ?></td>
                                <td>Rp <?= number_format($set_iuran, 0, ',', '.') ?></td>
                                <td><span class="badge bg-warning text-dark py-2 px-3 rounded-pill pulse-animation"><i class="bi bi-hourglass-split me-1"></i>PENDING</span></td>
                                <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($metode_bulan_ini) ?></span></td>
                                <td><small class="text-muted fst-italic">Menunggu Bendahara RT</small></td>
                            </tr>
                            <?php elseif($status_bulan_ini === 'belum_bayar'): 
                                // Hanya dihitung sebagai tunggakan jika Bendahara SUDAH generate tagihannya
                                $belum_bayar_count++; 
                            ?>
                            <tr class="table-danger bg-opacity-10">
                                <td class="fw-bold"><?= $nama_bulan[($i - 1)] ?></td>
                                <td class="fw-bold text-danger">Rp <?= number_format($set_iuran, 0, ',', '.') ?></td>
                                <td><span class="badge bg-danger py-2 px-3 rounded-pill"><i class="bi bi-exclamation-triangle-fill me-1"></i>BELUM BAYAR</span></td>
                                <td><span class="text-muted">-</span></td>
                                <td>
                                    <button class="btn btn-sm btn-success shadow-sm" data-bs-toggle="modal" data-bs-target="#bayarModal" data-bulan="<?= $i ?>" data-nama="<?= $nama_bulan[($i - 1)] ?>">
                                        <i class="bi bi-credit-card me-1"></i> Bayar
                                    </button>
                                </td>
                            </tr>
                            <?php else: ?>
                            <!-- Jika Bendahara BELUM generate tagihan -->
                            <tr class="table-light">
                                <td class="fw-bold text-muted"><?= $nama_bulan[($i - 1)] ?></td>
                                <td class="text-muted">Rp <?= number_format($set_iuran, 0, ',', '.') ?></td>
                                <td><span class="badge bg-secondary py-2 px-3 rounded-pill"><i class="bi bi-clock-history me-1"></i>BELUM DITAGIH</span></td>
                                <td><span class="text-muted">-</span></td>
                                <td><small class="text-muted fst-italic">Menunggu Bendahara RT</small></td>
                            </tr>
                            <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if($max_bulan === 0): ?>
                            <tr><td colspan="5" class="text-center py-4 text-muted">Belum ada tagihan untuk tahun ini.</td></tr>
                        <?php endif; ?>

                    </tbody>
                    <?php if($max_bulan > 0): ?>
                    <tfoot class="table-light">
                        <tr>
                            <th colspan="2" class="text-end">Total Tunggakan Tahun <?= $filter_tahun ?></th>
                            <th class="text-danger fs-5">Rp <?= number_format($belum_bayar_count * $set_iuran, 0, ',', '.') ?></th>
                            <th colspan="2"></th>
                        </tr>
                    </tfoot>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Pembayaran Digital -->
<div class="modal fade" id="bayarModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form action="proses_iuran.php" method="POST">
                <input type="hidden" name="bulan" id="inputBulan">
                <!-- Tahun disesuaikan dengan tahun yang sedang difilter/dilihat warga -->
                <input type="hidden" name="tahun" id="inputTahun" value="<?= $filter_tahun ?>"> 
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title"><i class="bi bi-credit-card-fill me-2"></i>Konfirmasi Pembayaran</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <h5 class="mb-3">Iuran Bulan: <span class="text-success fw-bold" id="labelBulan"></span> <span id="labelTahun" class="text-muted"><?= $filter_tahun ?></span></h5>
                    <h4 class="mb-4">Nominal: <span class="text-danger fw-bold">Rp <?= number_format($set_iuran, 0, ',', '.') ?></span></h4>
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold">Pilih Metode Pembayaran:</label>
                        <select name="metode_bayar" class="form-select" id="metodeBayar" required>
                            <option value="">-- Pilih Metode --</option>
                            <option value="Transfer Bank">🏦 Transfer Bank</option>
                            <option value="QRIS">📱 Scan QRIS</option>
                            <option value="Tunai">💵 Bayar Tunai ke Bendahara</option>
                        </select>
                    </div>

                    <!-- Info Rekening -->
                    <div id="infoTransfer" class="alert alert-info d-none border-start border-4 border-info">
                        <h6 class="fw-bold mb-1">Silakan Transfer ke Rekening RT:</h6>
                        <p class="mb-0 fs-5 fw-bold text-primary">BCA - 1234567890 a/n Bendahara RT</p>
                        <small class="text-muted">*Pastikan nominal sesuai dengan tagihan</small>
                    </div>

                    <!-- Info QRIS -->
                    <div id="infoQris" class="alert alert-warning d-none border-start border-4 border-warning text-center">
                        <h6 class="fw-bold mb-2">Scan QR Code RT di bawah ini:</h6>
                        <div class="bg-white p-2 d-inline-block rounded shadow-sm mb-2">
                            <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=QRIS_RT17_BASIRIH_SELATAN" alt="QRIS Placeholder" style="width: 150px; height: 150px;">
                        </div>
                        <br><small class="text-muted">*Gunakan aplikasi E-Wallet atau M-Banking Anda</small>
                    </div>

                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" required id="cekKonfirmasi">
                        <label class="form-check-label small fw-semibold text-danger" for="cekKonfirmasi">
                            Saya menyatakan sudah melakukan pembayaran sesuai nominal dan metode yang dipilih.
                        </label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-success fw-bold"><i class="bi bi-send-check me-1"></i> Kirim Bukti Bayar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Script untuk Modal Pembayaran
var bayarModal = document.getElementById('bayarModal');
bayarModal.addEventListener('show.bs.modal', function (event) {
    var button = event.relatedTarget;
    var bulan = button.getAttribute('data-bulan');
    var namaBulan = button.getAttribute('data-nama');
    
    document.getElementById('inputBulan').value = bulan;
    document.getElementById('labelBulan').textContent = namaBulan;
});

// Script untuk Show/Hide Info Rekening / QRIS
document.getElementById('metodeBayar').addEventListener('change', function() {
    document.getElementById('infoTransfer').classList.add('d-none');
    document.getElementById('infoQris').classList.add('d-none');
    
    if(this.value === 'Transfer Bank') document.getElementById('infoTransfer').classList.remove('d-none');
    if(this.value === 'QRIS') document.getElementById('infoQris').classList.remove('d-none');
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>