<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('warga');
require_once __DIR__ . '/../../config/database.php';

 $id_warga = $_SESSION['id_warga'];

// Logic: Tambah Pengajuan Surat
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajukan_surat'])) {
    $stmt = $pdo->prepare("INSERT INTO pengajuan_surat (id_warga, jenis_surat, keperluan) VALUES (?, ?, ?)");
    $stmt->execute([$id_warga, $_POST['jenis_surat'], $_POST['keperluan']]);
    header("Location: ajukan_surat.php?msg=berhasil");
    exit;
}

// Ambil Data Warga (Untuk template cetak)
 $warga = $pdo->prepare("SELECT * FROM warga WHERE id_warga=?");
 $warga->execute([$id_warga]);
 $data_warga = $warga->fetch();

// Ambil Riwayat Surat
 $riwayat = $pdo->prepare("SELECT * FROM pengajuan_surat WHERE id_warga=? ORDER BY tanggal_ajuan DESC");
 $riwayat->execute([$id_warga]);
 $data_riwayat = $riwayat->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<style>
    .gradient-indigo { background: linear-gradient(135deg, #6610f2 0%, #520dc2 100%); }
    .card-modern { border: none; border-radius: 15px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); transition: transform 0.2s; }
    .card-modern:hover { transform: translateY(-3px); box-shadow: 0 8px 25px rgba(0,0,0,0.1); }
    .badge-pending { background-color: #ffc107; color: #000; }
    .badge-disetujui { background-color: #198754; color: #fff; }
    .badge-ditolak { background-color: #dc3545; color: #fff; }

    /* CSS Khusus Cetak Print Profesional */
    @media print {
        @page { 
            size: A4; 
            margin: 2cm 2.5cm 2cm 2.5cm; /* Margin standar surat resmi */
        }
        body { 
            -webkit-print-color-adjust: exact !important; 
            print-color-adjust: exact !important; 
            margin: 0; 
            padding: 0;
        }
        body * { visibility: hidden; }
        #print-area, #print-area * { visibility: visible; }
        #print-area { 
            position: absolute; 
            left: 0; 
            top: 0; 
            width: 100%; 
            box-shadow: none; 
            border: none; 
            display: block !important;
        }
        .no-print { display: none !important; }
        
        /* Format Isi Surat (12pt) */
        .surat-body, .surat-body p, .surat-body b, .surat-body div, .surat-body span {
            font-family: 'Times New Roman', Times, serif !important;
            font-size: 12pt !important;
            line-height: 1.5 !important;
            color: #000 !important;
        }
        /* Format Kop & Judul Surat (14pt) */
        .surat-body h3, .surat-body h4, .surat-body h5 {
            font-family: 'Times New Roman', Times, serif !important;
            font-size: 14pt !important;
            line-height: 1.5 !important;
            color: #000 !important;
        }
        .surat-body {
            text-align: justify !important;
        }
        .kop-garis-tebal { border-bottom: 3px solid #000 !important; margin-bottom: 2px; }
        .kop-garis-tipis { border-bottom: 1px solid #000 !important; margin-bottom: 20px; }
    }
</style>

<div class="container-fluid no-print">
    <h3 class="mt-4 mb-4"><i class="bi bi-file-earmark-plus-fill me-2" style="color: #6610f2;"></i>Layanan Persuratan</h3>

    <?php if(isset($_GET['msg'])): ?>
        <div class="alert alert-success alert-dismissible fade show rounded-3 border-0 shadow-sm" role="alert">
            <i class="bi bi-check-circle me-2"></i>Pengajuan surat berhasil dikirim! Menunggu validasi Ketua RT.
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <!-- Form Ajukan Surat -->
        <div class="col-lg-5 mb-4">
            <div class="card card-modern">
                <div class="card-header bg-white border-0 pt-4 pb-0 px-4">
                    <h5 class="fw-bold text-indigo mb-0" style="color: #6610f2;">Formulir Pengajuan Baru</h5>
                </div>
                <div class="card-body px-4 pb-4">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-semibold small">Jenis Surat</label>
                            <select name="jenis_surat" class="form-select" required>
                                <option value="">-- Pilih Jenis Surat --</option>
                                <option value="Pengantar KTP">1. Surat Pengantar KTP</option>
                                <option value="Pengantar Pindah">2. Surat Pengantar Pindah</option>
                                <option value="Keterangan Domisili">3. Surat Keterangan Domisili</option>
                                <option value="Keterangan Usaha">4. Surat Keterangan Usaha</option>
                                <option value="Keterangan Tidak Mampu">5. Surat Keterangan Tidak Mampu</option>
                                <option value="Pengantar SKCK">6. Surat Pengantar SKCK</option>
                                <option value="Pengantar Kematian">7. Surat Pengantar Kematian</option>
                                <option value="Rekomendasi">8. Surat Rekomendasi</option>
                            </select>
                        </div>
                        <div class="mb-4">
                            <label class="form-label fw-semibold small">Keperluan</label>
                            <textarea name="keperluan" class="form-control" rows="4" placeholder="Jelaskan keperluan surat ini..." required></textarea>
                        </div>
                        <button type="submit" name="ajukan_surat" class="btn w-100 text-white shadow-sm" style="background-color: #6610f2;">
                            <i class="bi bi-send-fill me-1"></i> Kirim Pengajuan
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Riwayat Pengajuan -->
        <div class="col-lg-7 mb-4">
            <div class="card card-modern h-100">
                <div class="card-header bg-white border-0 pt-4 pb-0 px-4">
                    <h5 class="fw-bold text-dark mb-0"><i class="bi bi-clock-history me-2"></i>Riwayat & Status Surat</h5>
                </div>
                <div class="card-body px-4 pb-4">
                    <?php if(count($data_riwayat) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Tanggal</th>
                                    <th>Jenis</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($data_riwayat as $ds): ?>
                                <tr>
                                    <td class="small text-muted"><?= date('d M Y', strtotime($ds['tanggal_ajuan'])) ?></td>
                                    <td class="fw-bold"><?= $ds['jenis_surat'] ?></td>
                                    <td>
                                        <span class="badge badge-<?= $ds['status'] ?>"><?= ucfirst($ds['status']) ?></span>
                                        <?php if($ds['status'] == 'ditolak'): ?>
                                            <br><small class="text-danger" title="<?= htmlspecialchars($ds['catatan_rt']) ?>">Alasan: <?= htmlspecialchars($ds['catatan_rt']) ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($ds['status'] == 'disetujui'): ?>
                                            <button class="btn btn-sm btn-outline-primary btn-cetak" 
                                                data-judul="SURAT <?= strtoupper($ds['jenis_surat']) ?>"
                                                data-nomor="<?= $ds['nomor_surat'] ?>"
                                                data-jenis="<?= htmlspecialchars($ds['jenis_surat']) ?>"
                                                data-keperluan="<?= htmlspecialchars($ds['keperluan']) ?>">
                                                <i class="bi bi-printer me-1"></i>Cetak
                                            </button>
                                        <?php else: ?>
                                            <span class="text-muted small">-</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                        <div class="text-center py-5 text-muted">
                            <i class="bi bi-inbox" style="font-size: 3rem; opacity: 0.3;"></i>
                            <h6 class="mt-3">Belum ada riwayat pengajuan.</h6>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- AREA CETAK SURAT PROFESIONAL (A4) -->
<div id="print-area" style="display:none; width: 100%;">
    <div class="surat-body" style="font-family: 'Times New Roman', serif; font-size: 12pt; line-height: 1.5; color: #000;">
        
        <!-- KOP SURAT (Font 14pt) -->
        <div style="text-align: center; margin-bottom: 20px;">
            <h4 style="margin:0; font-weight:bold; letter-spacing: 1px; font-size: 14pt;">RUKUN TETANGGA 17</h4>
            <h5 style="margin:0; font-weight:bold; font-size: 14pt;">KELURAHAN BASIRIH SELATAN</h5>
            <p style="margin:0; font-size: 12pt;">JL. Tembus Mantuil Basirih Ulu No.01 - Pos Induk RT.17</p>
            <div class="kop-garis-tebal" style="border-bottom: 3px solid #000; margin-top: 8px;"></div>
            <div class="kop-garis-tipis" style="border-bottom: 1px solid #000; margin-bottom: 15px;"></div>
            
            <!-- JUDUL SURAT (Font 14pt) -->
            <h3 style="margin:0; font-weight:bold; text-decoration: underline; letter-spacing: 2px; font-size: 14pt;" id="print-judul"></h3>
        </div>

        <!-- NOMOR SURAT & TANGGAL -->
        <div style="display: flex; justify-content: space-between; margin-bottom: 20px; width: 100%;">
            <div style="width: 50%;">
                Nomor : <b id="print-nomor"></b><br>
                Lampiran : -
            </div>
            <div style="width: 50%; text-align: right;" id="print-tempat-tanggal"></div>
        </div>

        <!-- ISI SURAT -->
        <p style="margin-bottom: 15px;">Yang bertanda tangan di bawah ini, Ketua Rukun Tetangga 17 Kelurahan Basirih Selatan, Kecamatan Banjarmasin Barat, dengan ini menerangkan bahwa:</p>
        
        <div style="display: flex; margin-bottom: 20px;">
            <div style="width: 25%;">
                <p style="margin:0;">Nama Lengkap</p>
                <p style="margin:0;">NIK</p>
                <p style="margin:0;">Tempat/Tgl Lahir</p>
                <p style="margin:0;">Jenis Kelamin</p>
                <p style="margin:0;">Pekerjaan</p>
                <p style="margin:0;">Alamat</p>
            </div>
            <div style="width: 3%;">
                <p style="margin:0;">:</p>
                <p style="margin:0;">:</p>
                <p style="margin:0;">:</p>
                <p style="margin:0;">:</p>
                <p style="margin:0;">:</p>
                <p style="margin:0;">:</p>
            </div>
            <div style="width: 72%;">
                <p style="margin:0; font-weight:bold;" id="print-nama"></p>
                <p style="margin:0;" id="print-nik"></p>
                <p style="margin:0;" id="print-ttl"></p>
                <p style="margin:0;" id="print-jk"></p>
                <p style="margin:0;" id="print-pekerjaan"></p>
                <p style="margin:0;" id="print-alamat"></p>
            </div>
        </div>

        <div id="print-isi-dinamis" style="text-align: justify;"></div>

        <p style="text-align: justify; margin-top: 15px;">Demikian surat keterangan ini dibuat dengan sebenarnya, untuk dapat dipergunakan sebagaimana mestinya. Atas perhatian dan kerja samanya, kami ucapkan terima kasih.</p>

        <!-- TANDA TANGAN DIGITAL (QR CODE) - LAYOUT SEJAJAR -->
        <div style="display: flex; justify-content: flex-end; margin-top: 30px;">
            <div style="width: 350px;">
                <p id="print-tanggal-ttd" style="margin: 0; text-align: left;"></p>
                <p style="margin: 0 0 30px 0; text-align: left;">Ketua RT 17 Kelurahan Basirih Selatan,</p>
                
                <!-- Div QR Code & Keterangan (QR Diperbesar menjadi 90x90) -->
                <div style="display: flex; justify-content: flex-start; align-items: center; margin-bottom: 5px;">
                    <img id="print-qrcode" src="" alt="QR TTD Digital" style="width: 90px; height: 90px; border: 1px solid #000; margin-right: 10px;">
                    <div style="font-size: 8pt; max-width: 130px; line-height: 1.2;">
                        <i>*Scan QR Code ini untuk verifikasi tanda tangan digital & keaslian surat.</i>
                    </div>
                </div>

                <!-- Nama & NIP (White-space nowrap agar gelar tidak turun ke bawah) -->
                <p style="font-weight: bold; margin: 0; text-decoration: underline; white-space: nowrap;">Fathur Ramadhan, S.Tr.Kom., M.Kom.</p>
                <p style="margin: 0;">NIP. 083823248324</p>
            </div>
        </div>
    </div>
</div>

<!-- Script Cetak Profesional -->
<script>
    // Data statis Warga dari PHP ke JS
    const wargaData = {
        nama: "<?= htmlspecialchars($data_warga['nama_lengkap']) ?>",
        nik: "<?= $data_warga['nik'] ?>",
        ttl: "<?= htmlspecialchars($data_warga['tempat_lahir'] ?? '-') ?>, <?= date('d-m-Y', strtotime($data_warga['tanggal_lahir'])) ?>",
        jk: "<?= $data_warga['jenis_kelamin'] ?? 'Laki-laki' ?>",
        pekerjaan: "<?= htmlspecialchars($data_warga['pekerjaan'] ?? '-') ?>",
        alamat: "RT <?= $data_warga['rt'] ?> RW <?= $data_warga['rw'] ?>, <?= htmlspecialchars($data_warga['alamat']) ?>"
    };

    // Array Nama Bulan untuk Tanggal Otomatis
    const bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
    const today = new Date();
    const tglSekarang = `Banjarmasin, ${today.getDate()} ${bulan[today.getMonth()]} ${today.getFullYear()}`;

    // Event Listener untuk tombol cetak
    document.querySelectorAll('.btn-cetak').forEach(btn => {
        btn.addEventListener('click', function() {
            const judul = this.getAttribute('data-judul');
            const nomor = this.getAttribute('data-nomor');
            const jenis = this.getAttribute('data-jenis');
            const keperluan = this.getAttribute('data-keperluan');

            // Inject Kop & Nomor
            document.getElementById('print-judul').innerText = judul;
            document.getElementById('print-nomor').innerText = nomor;
            document.getElementById('print-tempat-tanggal').innerText = tglSekarang;
            document.getElementById('print-tanggal-ttd').innerText = tglSekarang;

            // Inject Data Warga
            document.getElementById('print-nama').innerText = wargaData.nama;
            document.getElementById('print-nik').innerText = wargaData.nik;
            document.getElementById('print-ttl').innerText = wargaData.ttl;
            document.getElementById('print-jk').innerText = wargaData.jk;
            document.getElementById('print-pekerjaan').innerText = wargaData.pekerjaan;
            document.getElementById('print-alamat').innerText = wargaData.alamat;

            // Buat Paragraf Isi Dinamis (Sangat Informatif & Padat)
            let isiDinamis = "";
            if(jenis.includes("Domisili")) {
                isiDinamis = `<p>Bahwa berdasarkan keterangan yang bersangkutan, hasil pengecekan administrasi kependudukan, serta verifikasi lapangan yang telah kami lakukan, nama tersebut di atas adalah benar warga kami yang berdomisili dan tinggal tetap di alamat sebagaimana tercantum di atas. Yang bersangkutan telah menetap di wilayah administrasi RT 17 Kelurahan Basirih Selatan dan tercatat dalam buku register warga setempat.</p>
                <p>Bahwa selama menetap di wilayah kami, yang bersangkutan tidak memiliki kendala atau masalah administrasi kependudukan, serta dinyatakan aktif sebagai bagian dari anggota masyarakat RT 17. Surat keterangan domisili ini diterbitkan untuk membuktikan keberadaan dan tempat tinggal yang bersangkutan secara sah dan resmi.</p>
                <p>Surat keterangan ini dibuat untuk keperluan <b>${keperluan}</b>. Dalam menerbitkan surat ini, pihak pengurus RT 17 telah memastikan kebenaran data dan tidak terdapat unsur pemalsuan maupun paksaan dari pihak mana pun.</p>`;
            } else if (jenis.includes("Usaha")) {
                isiDinamis = `<p>Bahwa berdasarkan pengamatan langsung dan keterangan dari warga sekitar, nama tersebut di atas adalah benar warga kami yang memiliki, menjalankan, dan mengelola kegiatan usaha di lingkungan RT 17 Kelurahan Basirih Selatan. Kegiatan usaha yang dijalankan oleh yang bersangkutan tercatat aktif, berjalan dengan baik, dan telah memberikan dampak positif bagi perekonomian warga sekitar.</p>
                <p>Bahwa selama menjalankan usahanya, yang bersangkutan tidak pernah terlibat dalam perselisihan hukum, tidak menerima keluhan dari warga sekitar terkait dampak lingkungan atau gangguan ketertiban, dan selalu mematuhi peraturan perundang-undangan yang berlaku.</p>
                <p>Surat keterangan usaha ini dibuat untuk melengkapi persyaratan administrasi yang berkaitan dengan keperluan <b>${keperluan}</b>. Dengan diterbitkannya surat ini, pihak RT 17 memberikan rekomendasi dan pengesahan bahwa usaha yang dijalankan oleh yang bersangkutan adalah sah dan dapat dipertanggungjawabkan.</p>`;
            } else if (jenis.includes("Tidak Mampu")) {
                isiDinamis = `<p>Bahwa nama tersebut di atas adalah benar warga kami yang berdomisili di alamat tersebut. Berdasarkan pengetahuan kami selaku pengurus RT 17, hasil survei lapangan, serta kondisi sosial ekonomi yang terlihat sehari-hari, yang bersangkutan termasuk dalam kategori keluarga yang kurang mampu secara ekonomi.</p>
                <p>Bahwa ketidakmampuan ekonomi tersebut dibuktikan dengan kondisi tempat tinggal yang tidak memadai, serta tingkat penghasilan harian yang pas-pasan dan tidak mencukupi untuk memenuhi kebutuhan dasar hidup sehari-hari keluarga. Oleh karena itu, yang bersangkutan sangat membutuhkan bantuan dan dukungan dari berbagai pihak.</p>
                <p>Surat keterangan ini dibuat untuk dipergunakan dalam mengurus keperluan <b>${keperluan}</b>. Surat ini diterbitkan tanpa adanya unsur pemalsuan data, dan dapat dipertanggungjawabkan kebenarannya secara hukum dan administrasi pemerintahan.</p>`;
            } else if (jenis.includes("SKCK")) {
                isiDinamis = `<p>Bahwa nama tersebut di atas adalah benar warga RT 17 Kelurahan Basirih Selatan yang berdomisili pada alamat tersebut. Berdasarkan catatan administrasi RT dan keterangan dari tokoh masyarakat setempat, yang bersangkutan dikenal sebagai pribadi yang berkelakuan baik, sopan santun, dan mematuhi peraturan perundang-undangan yang berlaku di lingkungan masyarakat.</p>
                <p>Bahwa selama menetap di wilayah kami, yang bersangkutan belum pernah melakukan tindakan pidana, tidak sedang dalam proses persidangan, tidak terlibat dalam kegiatan yang melanggar hukum, serta tidak pernah menimbulkan gangguan terhadap keamanan dan ketertiban masyarakat (Kamtibmas).</p>
                <p>Surat pengantar ini dibuat untuk keperluan pembuatan atau perpanjangan Surat Keterangan Catatan Kepolisian (SKCK) guna memenuhi persyaratan <b>${keperluan}</b>. Dengan adanya surat ini, pihak RT 17 merekomendasikan agar permohonan yang bersangkutan dapat diproses sebagaimana mestinya.</p>`;
            } else if (jenis.includes("Kematian")) {
                isiDinamis = `<p>Bahwa nama tersebut di atas adalah benar warga kami yang sebelumnya berdomisili di alamat tersebut. Dengan segala kerendahan hati, kami selaku pengurus RT 17 menerangkan bahwa yang bersangkutan telah menghadap Sang Pencipta (meninggal dunia).</p>
                <p>Bahwa kejadian tersebut telah kami catat dalam buku register kematian di lingkungan RT 17, dan telah diketahui serta disaksikan oleh warga sekitar tempat tinggalnya. Dengan meninggalnya yang bersangkutan, status administrasi kependudukannya perlu diperbarui.</p>
                <p>Surat pengantar ini dibuat untuk keperluan mengurus administrasi <b>${keperluan}</b> di instansi terkait. Demikian surat ini dibuat dengan sebenarnya untuk dipergunakan sebagaimana mestinya.</p>`;
            } else if (jenis.includes("Pindah")) {
                isiDinamis = `<p>Bahwa nama tersebut di atas adalah benar warga kami yang sebelumnya berdomisili di alamat tersebut. Yang bersangkutan mengajukan permohonan dan menyatakan ketegasan untuk pindah domisili keluar dari wilayah administrasi RT 17 Kelurahan Basirih Selatan.</p>
                <p>Bahwa selama tinggal di wilayah kami, yang bersangkutan tercatat sebagai warga yang berkelakuan baik, tidak meninggalkan tanggungan utang piutang kepada warga sekitar, serta tidak memiliki masalah hukum atau administrasi yang belum terselesaikan.</p>
                <p>Surat pengantar ini dibuat untuk keperluan mengurus administrasi <b>${keperluan}</b> di wilayah domisili barunya. Demikian surat ini dibuat dengan sebenarnya untuk dipergunakan sebagaimana mestinya.</p>`;
            } else { // KTP & Rekomendasi
                isiDinamis = `<p>Bahwa nama tersebut di atas adalah benar warga RT 17 Kelurahan Basirih Selatan yang berdomisili pada alamat sebagaimana tercantum di atas. Yang bersangkutan merupakan bagian dari warga kami yang memiliki identitas dan data kependudukan yang jelas.</p>
                <p>Bahwa selama ini yang bersangkutan aktif berpartisipasi dalam kegiatan lingkungan, diketahui berkelakuan baik, dan tidak memiliki kendala administrasi yang merugikan pihak mana pun.</p>
                <p>Surat pengantar ini dibuat untuk keperluan <b>${keperluan}</b>. Demikian surat ini dibuat dengan sebenarnya untuk dipergunakan sebagaimana mestinya.</p>`;
            }
            document.getElementById('print-isi-dinamis').innerHTML = isiDinamis;

            // GENERATE QR CODE TTD DIGITAL
            const verifikasiText = `SURAT RESMI RT 17 KELURAHAN BASIRIH SELATAN\n\nJenis Surat: ${jenis}\nNomor Surat: ${nomor}\nPemohon: ${wargaData.nama}\nTanggal Diterbitkan: ${tglSekarang}\n\nDitetapkan dan ditandatangani secara digital oleh:\nFathur Ramadhan, S.Tr.Kom., M.Kom. (Ketua RT 17)\nNIP. 083823248324\n\nStatus: RESMI DAN SAH MENURUT HUKUM ADAT DAN ADMINISTRASI RT.`;
            
            // Menggunakan API qrserver untuk generate QR Code secara dinamis
            const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(verifikasiText)}`;
            document.getElementById('print-qrcode').src = qrUrl;

            // Tampilkan area print lalu panggil dialog print
            document.getElementById('print-area').style.display = 'block';
            
            // Tunggu gambar QR code selesai dimuat sebelum print
            const qrImg = document.getElementById('print-qrcode');
            qrImg.onload = function() {
                // Simpan judul asli halaman
                const originalTitle = document.title;
                // Ubah judul halaman agar menjadi nama file saat di-save as PDF (Spasi diganti underscore)
                document.title = `Surat_${jenis.replace(/\s+/g, '_')}_${wargaData.nama.replace(/\s+/g, '_')}`;

                window.print();

                // Kembalikan judul halaman ke semula setelah dialog print ditutup
                document.title = originalTitle;
                document.getElementById('print-area').style.display = 'none';
            };
            
            // Fallback jika gambar gagal dimuat
            qrImg.onerror = function() {
                const originalTitle = document.title;
                document.title = `Surat_${jenis.replace(/\s+/g, '_')}_${wargaData.nama.replace(/\s+/g, '_')}`;
                
                window.print();
                
                document.title = originalTitle;
                document.getElementById('print-area').style.display = 'none';
            };
        });
    });
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>