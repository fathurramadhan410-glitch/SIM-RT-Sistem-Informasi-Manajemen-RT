<?php
require_once __DIR__ . '/../../includes/auth.php';
requireRole('warga');
require_once __DIR__ . '/../../config/database.php';

 $id_warga = $_SESSION['id_warga'];

// ==========================================
// LOGIC: Proses Form (Ajukan Surat & Aduan)
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['ajukan_surat'])) {
        $stmt = $pdo->prepare("INSERT INTO pengajuan_surat (id_warga, jenis_surat, keperluan) VALUES (?, ?, ?)");
        $stmt->execute([$id_warga, $_POST['jenis_surat'], $_POST['keperluan']]);
        $msg = "✅ Pengajuan surat berhasil dikirim! Silakan menunggu validasi Ketua RT.";
    } 
    elseif (isset($_POST['kirim_aduan'])) {
        $stmt = $pdo->prepare("INSERT INTO pengaduan (id_warga, kategori, isi_aduan) VALUES (?, ?, ?)");
        $stmt->execute([$id_warga, $_POST['kategori'], $_POST['isi_aduan']]);
        $msg = "✅ Laporan pengaduan berhasil dikirim! Pengurus RT akan segera menindaklanjuti.";
    }
    // Redirect agar form tidak resubmit
    header("Location: dashboard.php?msg=" . urlencode($msg));
    exit;
}

// ==========================================
// QUERY: Ambil Data Pribadi & Statistik
// ==========================================
// Cek iuran bulan ini
 $bulan_ini = date('n'); $tahun_ini = date('Y');
 $cek_iuran = $pdo->prepare("SELECT id_iuran FROM pembayaran_iuran WHERE id_warga=? AND bulan=? AND tahun=?");
 $cek_iuran->execute([$id_warga, $bulan_ini, $tahun_ini]);
 $status_iuran = $cek_iuran->fetch() ? 'LUNAS' : 'BELUM BAYAR';

// Hitung surat pending & selesai
 $surat_pending = $pdo->prepare("SELECT COUNT(*) FROM pengajuan_surat WHERE id_warga=? AND status='pending'");
 $surat_pending->execute([$id_warga]);
 $total_pending = $surat_pending->fetchColumn();

 $surat_selesai = $pdo->prepare("SELECT COUNT(*) FROM pengajuan_surat WHERE id_warga=? AND status='disetujui'");
 $surat_selesai->execute([$id_warga]);
 $total_selesai = $surat_selesai->fetchColumn();

// Ambil 5 riwayat surat terakhir
 $riwayat_surat = $pdo->prepare("SELECT * FROM pengajuan_surat WHERE id_warga=? ORDER BY tanggal_ajuan DESC LIMIT 5");
 $riwayat_surat->execute([$id_warga]);
 $data_surat = $riwayat_surat->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<!-- Custom CSS Modern Warga -->
<style>
    body { background-color: #f8f9fa; }
    .gradient-indigo { background: linear-gradient(135deg, #6610f2 0%, #520dc2 100%); }
    .gradient-teal   { background: linear-gradient(135deg, #20c9a0 0%, #1a9ea8 100%); }
    .gradient-orange { background: linear-gradient(135deg, #fd7e14 0%, #e8590c 100%); }
    .gradient-pink   { background: linear-gradient(135deg, #e83e8c 0%, #c7356f 100%); }
    .card-modern { border: none; border-radius: 15px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); transition: transform 0.2s; }
    .card-modern:hover { transform: translateY(-3px); box-shadow: 0 8px 25px rgba(0,0,0,0.1); }
    .card-stat-warga { border: none; border-radius: 15px; color: white; padding: 20px 0; }
    .form-control:focus, .form-select:focus { border-color: #6610f2; box-shadow: 0 0 0 0.2rem rgba(102, 16, 242, 0.15); }
    .clock-display { font-family: 'Segoe UI', sans-serif; font-weight: 300; letter-spacing: 2px; }
</style>

<div class="container-fluid">

    <!-- Welcome Banner & Real-Time Clock -->
    <div class="row mb-4 align-items-center bg-white p-4 rounded-3 shadow-sm card-modern">
        <div class="col-md-7">
            <h2 class="fw-bold text-dark mb-1">Halo, <?= htmlspecialchars($_SESSION['nama_lengkap']); ?> 👋</h2>
            <p class="text-muted mb-0">Selamat datang di portal layanan RT Anda. Gunakan layanan di bawah ini dengan mudah.</p>
        </div>
        <div class="col-md-5 text-md-end mt-3 mt-md-0">
            <div class="text-muted text-uppercase small" id="day-date-year-warga"></div>
            <h2 class="fw-bold text-indigo clock-display" id="realtime-clock-warga" style="font-size: 2.5rem; color: #6610f2;"></h2>
        </div>
    </div>

    <!-- Notifikasi -->
    <?php if(isset($_GET['msg'])): ?>
        <div class="alert alert-success alert-dismissible fade show rounded-3 border-0 shadow-sm" role="alert">
            <?= htmlspecialchars($_GET['msg']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Status Cards -->
    <div class="row mb-4">
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="card card-stat-warga gradient-indigo shadow text-center">
                <i class="bi bi-hourglass-split" style="font-size: 2rem; opacity: 0.8;"></i>
                <h1 class="mt-2 mb-0 fw-bold"><?= $total_pending ?></h1>
                <span>Surat Pending</span>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="card card-stat-warga gradient-teal shadow text-center">
                <i class="bi bi-check-circle-fill" style="font-size: 2rem; opacity: 0.8;"></i>
                <h1 class="mt-2 mb-0 fw-bold"><?= $total_selesai ?></h1>
                <span>Surat Selesai</span>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="card card-stat-warga gradient-<?= $status_iuran == 'LUNAS' ? 'teal' : 'orange' ?> shadow text-center">
                <i class="bi bi-<?= $status_iuran == 'LUNAS' ? 'check2-square' : 'exclamation-triangle' ?>" style="font-size: 2rem; opacity: 0.8;"></i>
                <h4 class="mt-2 mb-0 fw-bold text-uppercase"><?= $status_iuran ?></h4>
                <span>Iuran Bulan Ini</span>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="card card-stat-warga gradient-pink shadow text-center">
                <i class="bi bi-chat-heart-fill" style="font-size: 2rem; opacity: 0.8;"></i>
                <h4 class="mt-2 mb-0 fw-bold">Aktif</h4>
                <span>Status Akun</span>
            </div>
        </div>
    </div>

    <div class="row">
        
        <!-- Kolom Kiri: Form Layanan Cepat -->
        <div class="col-lg-5 mb-4">
            
            <!-- Form Ajukan Surat -->
            <div class="card card-modern mb-4">
                <div class="card-header bg-transparent border-0 pt-4 pb-0 px-4">
                    <h5 class="fw-bold text-indigo mb-0"><i class="bi bi-file-earmark-plus-fill me-2"></i>Ajukan Surat Baru</h5>
                    <small class="text-muted">Data akan otomatis masuk ke validasi Ketua RT</small>
                </div>
                <div class="card-body px-4 pb-4">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-semibold small">Jenis Surat</label>
                            <select name="jenis_surat" class="form-select" required>
                                <option value="">-- Pilih Jenis --</option>
                                <option value="Domisili">Keterangan Domisili</option>
                                <option value="SKTM">Keterangan Tidak Mampu (SKTM)</option>
                                <option value="Pengantar Usaha">Pengantar Izin Usaha</option>
                                <option value="Kelahiran">Keterangan Kelahiran</option>
                                <option value="Kematian">Keterangan Kematian</option>
                                <option value="Lainnya">Lainnya</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold small">Keperluan / Keterangan</label>
                            <textarea name="keperluan" class="form-control" rows="3" placeholder="Contoh: Untuk mendaftar bantuan BLT" required></textarea>
                        </div>
                        <button type="submit" name="ajukan_surat" class="btn btn-indigo w-100 text-white shadow-sm" style="background-color: #6610f2;">
                            <i class="bi bi-send-fill me-1"></i> Kirim Pengajuan
                        </button>
                    </form>
                </div>
            </div>

            <!-- Form Layanan Pengaduan -->
            <div class="card card-modern">
                <div class="card-header bg-transparent border-0 pt-4 pb-0 px-4">
                    <h5 class="fw-bold text-pink mb-0" style="color: #e83e8c;"><i class="bi bi-megaphone-fill me-2"></i>Layanan Pengaduan</h5>
                    <small class="text-muted">Sampaikan keluhan terkait lingkungan RT</small>
                </div>
                <div class="card-body px-4 pb-4">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-semibold small">Kategori Aduan</label>
                            <select name="kategori" class="form-select" required>
                                <option value="">-- Pilih Kategori --</option>
                                <option value="Infrastruktur">Infrastruktur (Jalan, Saluran)</option>
                                <option value="Keamanan">Keamanan & Ketertiban</option>
                                <option value="Sosial">Sosial & Benturan Warga</option>
                                <option value="Lainnya">Lainnya</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold small">Detail Aduan</label>
                            <textarea name="isi_aduan" class="form-control" rows="3" placeholder="Jelaskan masalah yang terjadi..." required></textarea>
                        </div>
                        <button type="submit" name="kirim_aduan" class="btn btn-pink w-100 text-white shadow-sm" style="background-color: #e83e8c;">
                            <i class="bi bi-send-fill me-1"></i> Kirim Aduan
                        </button>
                    </form>
                </div>
            </div>

        </div>

        <!-- Kolom Kanan: Riwayat Pengajuan Surat -->
        <div class="col-lg-7 mb-4">
            <div class="card card-modern h-100">
                <div class="card-header bg-transparent border-0 pt-4 pb-0 px-4 d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="fw-bold text-dark mb-0"><i class="bi bi-clock-history me-2"></i>Riwayat Pengajuan Surat</h5>
                        <small class="text-muted">Pantau status surat Anda di sini</small>
                    </div>
                </div>
                <div class="card-body px-4 pb-4">
                    <?php if(count($data_surat) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Tanggal</th>
                                    <th>Jenis Surat</th>
                                    <th>Keperluan</th>
                                    <th>Status</th>
                                    <th>Nomor Surat</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($data_surat as $ds): ?>
                                <tr>
                                    <td class="small text-muted"><?= date('d M Y', strtotime($ds['tanggal_ajuan'])) ?></td>
                                    <td class="fw-bold"><?= $ds['jenis_surat'] ?></td>
                                    <td class="small" style="max-width: 150px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="<?= htmlspecialchars($ds['keperluan']) ?>">
                                        <?= htmlspecialchars($ds['keperluan']) ?>
                                    </td>
                                    <td>
                                        <?php 
                                            $badge = 'bg-warning text-dark'; 
                                            if($ds['status']=='disetujui') $badge='bg-success'; 
                                            if($ds['status']=='ditolak') $badge='bg-danger'; 
                                        ?>
                                        <span class="badge <?= $badge ?>"><?= ucfirst($ds['status']) ?></span>
                                    </td>
                                    <td class="fw-bold text-primary small"><?= $ds['nomor_surat'] ?? '-' ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                        <div class="text-center py-5 text-muted">
                            <i class="bi bi-inbox" style="font-size: 3rem; opacity: 0.3;"></i>
                            <h6 class="mt-3">Anda belum pernah mengajukan surat.</h6>
                            <p>Gunakan form di samping kiri untuk memulai pengajuan.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- Script Real-Time Clock Warga -->
<script>
    function updateClockWarga() {
        const now = new Date();
        const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
        const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
        
        const dayName = days[now.getDay()];
        const date = now.getDate();
        const monthName = months[now.getMonth()];
        const year = now.getFullYear();
        
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        const seconds = String(now.getSeconds()).padStart(2, '0');

        document.getElementById('day-date-year-warga').textContent = `${dayName}, ${date} ${monthName} ${year}`;
        document.getElementById('realtime-clock-warga').textContent = `${hours}:${minutes}:${seconds} WIB`;
    }
    
    updateClockWarga();
    setInterval(updateClockWarga, 1000);
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>