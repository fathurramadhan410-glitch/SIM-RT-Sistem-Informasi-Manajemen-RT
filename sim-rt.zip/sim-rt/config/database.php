<?php
 $host = 'localhost';
 $dbname = 'sim-rt';
 $user = 'root';
 $pass = ''; // Kosongkan jika di XAMPP default tidak ada password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass);
    // Set mode error PDO ke Exception untuk penanganan error yang rapi
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Set fetch mode default ke Associative Array
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Jika koneksi gagal, hentikan program dan tampilkan pesan error
    die("Koneksi database gagal: " . $e->getMessage());
}